using System.ComponentModel.DataAnnotations;

namespace MergeSafeServer.Models
{
    public class UserProfile
    {
        public int Id { get; set; }

        [Display(Name = "User ID")]
        public string? UserId { get; set; }

        [Required]
        [Display(Name = "Full Name")]
        public string FullName { get; set; } = string.Empty;

        [Display(Name = "Address")]
        public string? Address { get; set; }

        [Display(Name = "Phone")]
        public string? Phone { get; set; }

        [Display(Name = "User Type")]
        public string UserType { get; set; } = "viewer";

        [Display(Name = "Highway ID")]
        public string? HighwayId { get; set; }

        [Display(Name = "Highway Name")]
        public string? HighwayName { get; set; }

        // Stored as comma-separated string
        [Display(Name = "Device IDs")]
        public string? DeviceIdsRaw { get; set; }

        // Stored as comma-separated string
        [Display(Name = "Device Names")]
        public string? DeviceNamesRaw { get; set; }

        [Display(Name = "Notes")]
        public string? Notes { get; set; }

        [Display(Name = "Active")]
        public bool IsActive { get; set; } = true;

        // Demo password (not for production use)
        [Display(Name = "Password")]
        public string? Password { get; set; }

        public DateTime CreatedDate { get; set; } = DateTime.UtcNow;
        public DateTime UpdatedDate { get; set; } = DateTime.UtcNow;
    }
}
