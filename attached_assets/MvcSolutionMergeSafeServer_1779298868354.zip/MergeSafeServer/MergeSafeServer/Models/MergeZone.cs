using System.ComponentModel.DataAnnotations;

namespace MergeSafeServer.Models
{
    public class MergeZone
    {
        public int Id { get; set; }

        [Required]
        [Display(Name = "Highway ID")]
        public string HighwayId { get; set; } = string.Empty;

        [Required]
        [Display(Name = "Zone Name")]
        public string ZoneName { get; set; } = string.Empty;

        [Required]
        [Display(Name = "Zone ID")]
        public string ZoneId { get; set; } = string.Empty;

        [Display(Name = "Mile Marker")]
        public double? MileMarker { get; set; }

        [Display(Name = "Latitude")]
        public double? Latitude { get; set; }

        [Display(Name = "Longitude")]
        public double? Longitude { get; set; }

        [Display(Name = "Status")]
        public string Status { get; set; } = "active";

        [Display(Name = "Geofence Radius (m)")]
        public double GeofenceRadius { get; set; } = 500;

        public DateTime CreatedDate { get; set; } = DateTime.UtcNow;
        public DateTime UpdatedDate { get; set; } = DateTime.UtcNow;

        // Navigation
        public List<SwitchServer> SwitchServers { get; set; } = new();
        public List<SensorDevice> SensorDevices { get; set; } = new();
        public List<VehicleEvent> VehicleEvents { get; set; } = new();
        public List<TriangulationConfig> TriangulationConfigs { get; set; } = new();
    }
}
