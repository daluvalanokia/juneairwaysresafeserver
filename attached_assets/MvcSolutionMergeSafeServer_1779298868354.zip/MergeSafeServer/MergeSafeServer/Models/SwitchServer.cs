using System.ComponentModel.DataAnnotations;

namespace MergeSafeServer.Models
{
    public class SwitchServer
    {
        public int Id { get; set; }

        [Required]
        [Display(Name = "Zone ID")]
        public string ZoneId { get; set; } = string.Empty;

        [Display(Name = "Highway ID")]
        public string? HighwayId { get; set; }

        [Required]
        [Display(Name = "Server Name")]
        public string ServerName { get; set; } = string.Empty;

        [Required]
        [Display(Name = "Server ID")]
        public string ServerId { get; set; } = string.Empty;

        [Display(Name = "IP Address")]
        public string? IpAddress { get; set; }

        [Display(Name = "Port")]
        public int Port { get; set; } = 8080;

        [Display(Name = "Status")]
        public string Status { get; set; } = "online";

        [Display(Name = "CPU %")]
        public double CpuPercent { get; set; } = 0;

        [Display(Name = "Memory %")]
        public double MemoryPercent { get; set; } = 0;

        [Display(Name = "Uptime (seconds)")]
        public long UptimeSeconds { get; set; } = 0;

        [Display(Name = "Last Heartbeat")]
        public DateTime? LastHeartbeat { get; set; }

        [Display(Name = "Firmware Version")]
        public string? FirmwareVersion { get; set; }

        public DateTime CreatedDate { get; set; } = DateTime.UtcNow;
        public DateTime UpdatedDate { get; set; } = DateTime.UtcNow;
    }
}
