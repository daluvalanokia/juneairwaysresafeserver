using System.ComponentModel.DataAnnotations;

namespace MergeSafeServer.Models
{
    public class SensorDevice
    {
        public int Id { get; set; }

        [Required]
        [Display(Name = "Zone ID")]
        public string ZoneId { get; set; } = string.Empty;

        [Display(Name = "Highway ID")]
        public string? HighwayId { get; set; }

        [Display(Name = "Server ID")]
        public string? ServerId { get; set; }

        [Required]
        [Display(Name = "Device Name")]
        public string DeviceName { get; set; } = string.Empty;

        [Required]
        [Display(Name = "Device ID")]
        public string DeviceId { get; set; } = string.Empty;

        [Required]
        [Display(Name = "Device Type")]
        public string DeviceType { get; set; } = "camera";

        [Display(Name = "Source Type")]
        public string SourceType { get; set; } = "physical";

        [Display(Name = "Device Height (m)")]
        public double? DeviceHeight { get; set; }

        [Display(Name = "Mile Marker")]
        public double? MileMarker { get; set; }

        [Display(Name = "Location Comment")]
        public string? LocationComment { get; set; }

        [Display(Name = "Latitude")]
        public double? Latitude { get; set; }

        [Display(Name = "Longitude")]
        public double? Longitude { get; set; }

        [Display(Name = "Status")]
        public string Status { get; set; } = "online";

        [Display(Name = "Last Seen")]
        public DateTime? LastSeen { get; set; }

        [Display(Name = "Firmware Version")]
        public string? FirmwareVersion { get; set; }

        [Display(Name = "Notes")]
        public string? Notes { get; set; }

        public DateTime CreatedDate { get; set; } = DateTime.UtcNow;
        public DateTime UpdatedDate { get; set; } = DateTime.UtcNow;
    }
}
