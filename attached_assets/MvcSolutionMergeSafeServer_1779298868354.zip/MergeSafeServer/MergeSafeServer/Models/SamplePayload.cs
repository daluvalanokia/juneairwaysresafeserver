using System.ComponentModel.DataAnnotations;

namespace MergeSafeServer.Models
{
    public class SamplePayload
    {
        public int Id { get; set; }

        [Required]
        [Display(Name = "Source Type")]
        public string SourceType { get; set; } = "physical";

        [Required]
        [Display(Name = "Format Config ID")]
        public int FormatConfigId { get; set; }

        [Display(Name = "Format Name")]
        public string? FormatName { get; set; }

        [Required]
        [Display(Name = "Payload (JSON)")]
        public string Payload { get; set; } = string.Empty;

        [Display(Name = "Is Valid")]
        public bool IsValid { get; set; } = true;

        [Display(Name = "Label")]
        public string? Label { get; set; }

        public DateTime CreatedDate { get; set; } = DateTime.UtcNow;
        public DateTime UpdatedDate { get; set; } = DateTime.UtcNow;

        public InputFormatConfig? FormatConfig { get; set; }
    }
}
