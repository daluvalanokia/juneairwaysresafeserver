using System.ComponentModel.DataAnnotations;

namespace MergeSafeServer.Models
{
    public class InputFormatConfig
    {
        public int Id { get; set; }

        [Required]
        [Display(Name = "Source Type")]
        public string SourceType { get; set; } = "physical";

        [Required]
        [Display(Name = "Format Name")]
        public string FormatName { get; set; } = string.Empty;

        [Display(Name = "Source ID")]
        public string? SourceId { get; set; }

        [Display(Name = "Input Source")]
        public string? InputSource { get; set; }

        [Display(Name = "Description")]
        public string? Description { get; set; }

        // Stored as comma-separated string
        [Display(Name = "Enabled Fields")]
        public string? EnabledFieldsRaw { get; set; }

        // Stored as JSON array string
        [Display(Name = "Custom Fields (JSON)")]
        public string? CustomFieldsJson { get; set; }

        public DateTime CreatedDate { get; set; } = DateTime.UtcNow;
        public DateTime UpdatedDate { get; set; } = DateTime.UtcNow;

        public List<SamplePayload> SamplePayloads { get; set; } = new();
    }
}
