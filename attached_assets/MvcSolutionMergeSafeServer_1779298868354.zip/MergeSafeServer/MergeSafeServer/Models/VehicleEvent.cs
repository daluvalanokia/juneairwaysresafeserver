using System.ComponentModel.DataAnnotations;

namespace MergeSafeServer.Models
{
    public class VehicleEvent
    {
        public int Id { get; set; }

        [Required]
        [Display(Name = "Zone ID")]
        public string ZoneId { get; set; } = string.Empty;

        [Display(Name = "Highway ID")]
        public string? HighwayId { get; set; }

        [Display(Name = "Server ID")]
        public string? ServerId { get; set; }

        [Display(Name = "Device ID")]
        public string? DeviceId { get; set; }

        [Required]
        [Display(Name = "Event Type")]
        public string EventType { get; set; } = "detection";

        [Display(Name = "Vehicle ID")]
        public string? VehicleId { get; set; }

        [Display(Name = "Speed (mph)")]
        public double? SpeedMph { get; set; }

        [Display(Name = "Latitude")]
        public double? Latitude { get; set; }

        [Display(Name = "Longitude")]
        public double? Longitude { get; set; }

        [Display(Name = "Confidence")]
        public double? Confidence { get; set; }

        [Display(Name = "Timestamp")]
        public DateTime? Timestamp { get; set; }

        [Display(Name = "Raw Data")]
        public string? RawData { get; set; }

        public DateTime CreatedDate { get; set; } = DateTime.UtcNow;
        public DateTime UpdatedDate { get; set; } = DateTime.UtcNow;
    }
}
