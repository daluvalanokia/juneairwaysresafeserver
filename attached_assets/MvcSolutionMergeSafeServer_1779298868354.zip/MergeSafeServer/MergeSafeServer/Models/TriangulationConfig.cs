using System.ComponentModel.DataAnnotations;

namespace MergeSafeServer.Models
{
    public class TriangulationConfig
    {
        public int Id { get; set; }

        [Required]
        [Display(Name = "Zone ID")]
        public string ZoneId { get; set; } = string.Empty;

        [Display(Name = "Highway ID")]
        public string? HighwayId { get; set; }

        [Display(Name = "Geofence Radius (m)")]
        public double GeofenceRadius { get; set; } = 500;

        // Switch 1
        [Display(Name = "Switch 1 Label")]
        public string Switch1Label { get; set; } = "Switch A";
        [Display(Name = "Switch 1 Server ID")]
        public string? Switch1ServerId { get; set; }
        [Display(Name = "Switch 1 Latitude")]
        public double? Switch1Lat { get; set; }
        [Display(Name = "Switch 1 Longitude")]
        public double? Switch1Lon { get; set; }

        // Switch 2
        [Display(Name = "Switch 2 Label")]
        public string Switch2Label { get; set; } = "Switch B";
        [Display(Name = "Switch 2 Server ID")]
        public string? Switch2ServerId { get; set; }
        [Display(Name = "Switch 2 Latitude")]
        public double? Switch2Lat { get; set; }
        [Display(Name = "Switch 2 Longitude")]
        public double? Switch2Lon { get; set; }

        // Switch 3
        [Display(Name = "Switch 3 Label")]
        public string Switch3Label { get; set; } = "Switch C";
        [Display(Name = "Switch 3 Server ID")]
        public string? Switch3ServerId { get; set; }
        [Display(Name = "Switch 3 Latitude")]
        public double? Switch3Lat { get; set; }
        [Display(Name = "Switch 3 Longitude")]
        public double? Switch3Lon { get; set; }

        [Display(Name = "Is Active")]
        public bool IsActive { get; set; } = true;

        public DateTime CreatedDate { get; set; } = DateTime.UtcNow;
        public DateTime UpdatedDate { get; set; } = DateTime.UtcNow;
    }
}
