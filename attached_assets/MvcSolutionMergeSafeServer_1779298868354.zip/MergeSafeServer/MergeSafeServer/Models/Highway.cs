using System.ComponentModel.DataAnnotations;

namespace MergeSafeServer.Models
{
    public class Highway
    {
        public int Id { get; set; }

        [Required]
        [Display(Name = "Highway Name")]
        public string Name { get; set; } = string.Empty;

        [Required]
        [Display(Name = "Highway ID")]
        public string HighwayId { get; set; } = string.Empty;

        [Display(Name = "Description")]
        public string? Description { get; set; }

        [Display(Name = "State / Region")]
        public string? State { get; set; }

        [Display(Name = "Active")]
        public bool IsActive { get; set; } = true;

        public DateTime CreatedDate { get; set; } = DateTime.UtcNow;
        public DateTime UpdatedDate { get; set; } = DateTime.UtcNow;

        // Navigation
        public List<MergeZone> MergeZones { get; set; } = new();
        public List<SwitchServer> SwitchServers { get; set; } = new();
        public List<SensorDevice> SensorDevices { get; set; } = new();
        public List<UserProfile> UserProfiles { get; set; } = new();
    }
}
