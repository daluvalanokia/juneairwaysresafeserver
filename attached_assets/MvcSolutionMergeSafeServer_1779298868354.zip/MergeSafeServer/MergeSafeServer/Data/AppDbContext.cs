using Microsoft.EntityFrameworkCore;
using MergeSafeServer.Models;

namespace MergeSafeServer.Data
{
    public class AppDbContext : DbContext
    {
        public AppDbContext(DbContextOptions<AppDbContext> options) : base(options) { }

        public DbSet<Highway> Highways => Set<Highway>();
        public DbSet<MergeZone> MergeZones => Set<MergeZone>();
        public DbSet<SwitchServer> SwitchServers => Set<SwitchServer>();
        public DbSet<SensorDevice> SensorDevices => Set<SensorDevice>();
        public DbSet<TriangulationConfig> TriangulationConfigs => Set<TriangulationConfig>();
        public DbSet<VehicleEvent> VehicleEvents => Set<VehicleEvent>();
        public DbSet<InputFormatConfig> InputFormatConfigs => Set<InputFormatConfig>();
        public DbSet<SamplePayload> SamplePayloads => Set<SamplePayload>();
        public DbSet<UserProfile> UserProfiles => Set<UserProfile>();

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            // Seed a default highway
            modelBuilder.Entity<Highway>().HasData(new Highway
            {
                Id = 1,
                Name = "Interstate 20",
                HighwayId = "I20",
                State = "TX",
                Description = "Default highway — edit in Settings",
                IsActive = true,
                CreatedDate = new DateTime(2026, 1, 1),
                UpdatedDate = new DateTime(2026, 1, 1)
            });
        }
    }
}
