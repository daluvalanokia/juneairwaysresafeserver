using MergeSafeServer.Models;

namespace MergeSafeServer.ViewModels
{
    public class SensorViewModel
    {
        public List<SensorDevice> Sensors { get; set; } = new();
        public List<Highway> Highways { get; set; } = new();
        public string? SelectedHighwayId { get; set; }
        public string? FilterType { get; set; }
        public SensorDevice Form { get; set; } = new();
        public bool IsEditing { get; set; } = false;
    }
}
