using MergeSafeServer.Models;

namespace MergeSafeServer.ViewModels
{
    public class EventsViewModel
    {
        public List<VehicleEvent> Events { get; set; } = new();
        public List<Highway> Highways { get; set; } = new();
        public string? SelectedHighwayId { get; set; }
        public string? FilterType { get; set; }
    }
}
