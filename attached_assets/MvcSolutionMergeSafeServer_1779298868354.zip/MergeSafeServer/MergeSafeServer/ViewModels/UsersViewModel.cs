using MergeSafeServer.Models;

namespace MergeSafeServer.ViewModels
{
    public class UsersViewModel
    {
        public List<UserProfile> Users { get; set; } = new();
        public List<Highway> Highways { get; set; } = new();
        public List<SensorDevice> Devices { get; set; } = new();
        public UserProfile Form { get; set; } = new();
        public bool IsEditing { get; set; } = false;
        public string? Search { get; set; }
    }
}
