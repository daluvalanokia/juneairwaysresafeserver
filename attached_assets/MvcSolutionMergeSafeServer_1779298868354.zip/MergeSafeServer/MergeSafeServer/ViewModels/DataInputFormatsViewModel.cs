using MergeSafeServer.Models;

namespace MergeSafeServer.ViewModels
{
    public class DataInputFormatsViewModel
    {
        public List<InputFormatConfig> PhysicalConfigs { get; set; } = new();
        public List<InputFormatConfig> SatelliteConfigs { get; set; } = new();
        public List<InputFormatConfig> TelecomConfigs { get; set; } = new();
        public List<InputFormatConfig> TrackerConfigs { get; set; } = new();
        public List<SamplePayload> SavedPayloads { get; set; } = new();
        public InputFormatConfig Form { get; set; } = new();
        public bool IsEditing { get; set; } = false;
        public string ActiveTab { get; set; } = "physical";
    }
}
