using MergeSafeServer.Models;

namespace MergeSafeServer.ViewModels
{
    public class MergeZoneViewModel
    {
        public List<MergeZone> Zones { get; set; } = new();
        public List<Highway> Highways { get; set; } = new();
        public string? SelectedHighwayId { get; set; }
        public MergeZone Form { get; set; } = new();
        public bool IsEditing { get; set; } = false;
    }
}
