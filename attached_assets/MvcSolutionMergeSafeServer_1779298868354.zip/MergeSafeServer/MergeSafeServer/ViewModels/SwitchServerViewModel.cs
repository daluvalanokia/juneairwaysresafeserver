using MergeSafeServer.Models;

namespace MergeSafeServer.ViewModels
{
    public class SwitchServerViewModel
    {
        public List<SwitchServer> Servers { get; set; } = new();
        public List<Highway> Highways { get; set; } = new();
        public string? SelectedHighwayId { get; set; }
        public SwitchServer Form { get; set; } = new();
        public bool IsEditing { get; set; } = false;
    }
}
