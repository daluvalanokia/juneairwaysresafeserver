using MergeSafeServer.Models;

namespace MergeSafeServer.ViewModels
{
    public class SettingsViewModel
    {
        public List<Highway> Highways { get; set; } = new();
        public Highway Form { get; set; } = new();
        public bool IsEditing { get; set; } = false;
        public string TomTomApiKey { get; set; } = string.Empty;
        public bool KeySaved { get; set; } = false;
    }
}
