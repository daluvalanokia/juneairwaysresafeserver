using MergeSafeServer.Models;

namespace MergeSafeServer.ViewModels
{
    public class TriangulationViewModel
    {
        public List<TriangulationConfig> Configs { get; set; } = new();
        public List<Highway> Highways { get; set; } = new();
        public string? SelectedHighwayId { get; set; }
        public TriangulationConfig Form { get; set; } = new();
        public bool IsEditing { get; set; } = false;
    }
}
