// MergeSafeServer — site.js

// Mobile sidebar toggle
document.addEventListener('DOMContentLoaded', function () {
    var toggle = document.getElementById('sidebarToggle');
    var sidebar = document.querySelector('.mss-sidebar');
    if (toggle && sidebar) {
        toggle.addEventListener('click', function () {
            sidebar.classList.toggle('open');
        });
        // Close when clicking outside on mobile
        document.addEventListener('click', function (e) {
            if (window.innerWidth < 768 && sidebar.classList.contains('open')) {
                if (!sidebar.contains(e.target) && e.target !== toggle) {
                    sidebar.classList.remove('open');
                }
            }
        });
    }

    // Auto-dismiss alerts after 4s
    setTimeout(function () {
        document.querySelectorAll('.alert.alert-success').forEach(function (el) {
            var bsAlert = new bootstrap.Alert(el);
            bsAlert.close();
        });
    }, 4000);

    // Activate Bootstrap tooltips
    document.querySelectorAll('[data-bs-toggle="tooltip"]').forEach(function (el) {
        new bootstrap.Tooltip(el);
    });
});

// Live clock in topbar (optional)
function startLiveClock(elementId) {
    function tick() {
        var el = document.getElementById(elementId);
        if (!el) return;
        var now = new Date();
        el.textContent = now.toLocaleTimeString();
    }
    tick();
    setInterval(tick, 1000);
}
