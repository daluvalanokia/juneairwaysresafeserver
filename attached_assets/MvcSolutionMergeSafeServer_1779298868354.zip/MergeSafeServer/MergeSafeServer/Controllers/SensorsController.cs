using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using MergeSafeServer.Data;
using MergeSafeServer.Models;
using MergeSafeServer.ViewModels;

namespace MergeSafeServer.Controllers
{
    public class SensorsController : Controller
    {
        private readonly AppDbContext _db;
        public SensorsController(AppDbContext db) { _db = db; }

        public async Task<IActionResult> Index(string? highwayId, string? filterType)
        {
            var highways = await _db.Highways.OrderBy(h => h.Name).ToListAsync();
            highwayId ??= HttpContext.Session.GetString("HighwayId") ?? highways.FirstOrDefault()?.HighwayId;
            var q = _db.SensorDevices.AsQueryable();
            if (!string.IsNullOrEmpty(highwayId)) q = q.Where(s => s.HighwayId == highwayId);
            if (!string.IsNullOrEmpty(filterType) && filterType != "all") q = q.Where(s => s.DeviceType == filterType);
            return View(new SensorViewModel
            {
                Sensors = await q.OrderByDescending(s => s.CreatedDate).ToListAsync(),
                Highways = highways,
                SelectedHighwayId = highwayId,
                FilterType = filterType ?? "all",
                Form = new SensorDevice { HighwayId = highwayId ?? "", DeviceType = "camera", SourceType = "physical", Status = "online" }
            });
        }

        [HttpPost, ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(SensorDevice form)
        {
            form.CreatedDate = form.UpdatedDate = DateTime.UtcNow;
            _db.SensorDevices.Add(form);
            await _db.SaveChangesAsync();
            TempData["Success"] = "Sensor device added.";
            return RedirectToAction(nameof(Index), new { highwayId = form.HighwayId });
        }

        [HttpPost, ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(SensorDevice form)
        {
            var e = await _db.SensorDevices.FindAsync(form.Id);
            if (e == null) return NotFound();
            e.DeviceName = form.DeviceName; e.DeviceId = form.DeviceId;
            e.ZoneId = form.ZoneId; e.HighwayId = form.HighwayId;
            e.ServerId = form.ServerId; e.DeviceType = form.DeviceType;
            e.SourceType = form.SourceType; e.DeviceHeight = form.DeviceHeight;
            e.MileMarker = form.MileMarker; e.LocationComment = form.LocationComment;
            e.Latitude = form.Latitude; e.Longitude = form.Longitude;
            e.Status = form.Status; e.FirmwareVersion = form.FirmwareVersion; e.Notes = form.Notes;
            e.UpdatedDate = DateTime.UtcNow;
            await _db.SaveChangesAsync();
            TempData["Success"] = "Sensor device updated.";
            return RedirectToAction(nameof(Index), new { highwayId = form.HighwayId });
        }

        [HttpPost, ValidateAntiForgeryToken]
        public async Task<IActionResult> Delete(int id, string? highwayId)
        {
            var s = await _db.SensorDevices.FindAsync(id);
            if (s != null) { _db.SensorDevices.Remove(s); await _db.SaveChangesAsync(); TempData["Success"] = "Deleted."; }
            return RedirectToAction(nameof(Index), new { highwayId });
        }
    }
}
