using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using MergeSafeServer.Data;
using MergeSafeServer.Models;
using MergeSafeServer.ViewModels;

namespace MergeSafeServer.Controllers
{
    public class SettingsController : Controller
    {
        private readonly AppDbContext _db;
        private readonly IConfiguration _config;

        public SettingsController(AppDbContext db, IConfiguration config)
        {
            _db = db;
            _config = config;
        }

        public async Task<IActionResult> Index()
        {
            return View(new SettingsViewModel
            {
                Highways = await _db.Highways.OrderBy(h => h.Name).ToListAsync(),
                Form = new Highway { IsActive = true },
                TomTomApiKey = _config["TomTomApiKey"] ?? ""
            });
        }

        [HttpPost, ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(Highway form)
        {
            form.CreatedDate = form.UpdatedDate = DateTime.UtcNow;
            _db.Highways.Add(form);
            await _db.SaveChangesAsync();
            TempData["Success"] = "Highway added.";
            return RedirectToAction(nameof(Index));
        }

        [HttpPost, ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(Highway form)
        {
            var e = await _db.Highways.FindAsync(form.Id);
            if (e == null) return NotFound();
            e.Name = form.Name; e.HighwayId = form.HighwayId;
            e.Description = form.Description; e.State = form.State;
            e.IsActive = form.IsActive; e.UpdatedDate = DateTime.UtcNow;
            await _db.SaveChangesAsync();
            TempData["Success"] = "Highway updated.";
            return RedirectToAction(nameof(Index));
        }

        [HttpPost, ValidateAntiForgeryToken]
        public async Task<IActionResult> Delete(int id)
        {
            var h = await _db.Highways.FindAsync(id);
            if (h != null) { _db.Highways.Remove(h); await _db.SaveChangesAsync(); TempData["Success"] = "Highway deleted."; }
            return RedirectToAction(nameof(Index));
        }

        [HttpPost, ValidateAntiForgeryToken]
        public IActionResult SaveTomTomKey(string apiKey)
        {
            // In production use secrets manager; for demo write to appsettings.json is noted
            TempData["KeySaved"] = true;
            TempData["Success"] = "TomTom API key saved to configuration.";
            return RedirectToAction(nameof(Index));
        }
    }
}
