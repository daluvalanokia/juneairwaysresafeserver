using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using MergeSafeServer.Data;
using MergeSafeServer.Models;
using MergeSafeServer.ViewModels;

namespace MergeSafeServer.Controllers
{
    public class EventsController : Controller
    {
        private readonly AppDbContext _db;
        public EventsController(AppDbContext db) { _db = db; }

        public async Task<IActionResult> Index(string? highwayId, string? filterType)
        {
            var highways = await _db.Highways.OrderBy(h => h.Name).ToListAsync();
            highwayId ??= HttpContext.Session.GetString("HighwayId") ?? highways.FirstOrDefault()?.HighwayId;
            var q = _db.VehicleEvents.AsQueryable();
            if (!string.IsNullOrEmpty(highwayId)) q = q.Where(e => e.HighwayId == highwayId);
            if (!string.IsNullOrEmpty(filterType) && filterType != "all") q = q.Where(e => e.EventType == filterType);
            return View(new EventsViewModel
            {
                Events = await q.OrderByDescending(e => e.CreatedDate).Take(100).ToListAsync(),
                Highways = highways,
                SelectedHighwayId = highwayId,
                FilterType = filterType ?? "all"
            });
        }

        // API-style endpoint for simulation / demo event injection
        [HttpPost, ValidateAntiForgeryToken]
        public async Task<IActionResult> InjectDemo(string zoneId, string highwayId, string eventType, double speedMph)
        {
            var ev = new VehicleEvent
            {
                ZoneId = zoneId, HighwayId = highwayId,
                EventType = eventType, SpeedMph = speedMph,
                VehicleId = $"VEH-{Random.Shared.Next(1000, 9999)}",
                DeviceId = $"CAM-{Random.Shared.Next(100, 999)}",
                Latitude = 32.7767 + (Random.Shared.NextDouble() - 0.5) * 0.2,
                Longitude = -96.7970 + (Random.Shared.NextDouble() - 0.5) * 0.2,
                Confidence = Random.Shared.Next(70, 100),
                Timestamp = DateTime.UtcNow,
                CreatedDate = DateTime.UtcNow,
                UpdatedDate = DateTime.UtcNow
            };
            _db.VehicleEvents.Add(ev);
            await _db.SaveChangesAsync();
            TempData["Success"] = $"Demo event [{eventType}] injected.";
            return RedirectToAction(nameof(Index), new { highwayId });
        }
    }
}
