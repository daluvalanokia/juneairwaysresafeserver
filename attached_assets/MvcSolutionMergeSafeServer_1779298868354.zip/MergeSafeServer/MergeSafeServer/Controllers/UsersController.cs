using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using MergeSafeServer.Data;
using MergeSafeServer.Models;
using MergeSafeServer.ViewModels;

namespace MergeSafeServer.Controllers
{
    public class UsersController : Controller
    {
        private readonly AppDbContext _db;
        public UsersController(AppDbContext db) { _db = db; }

        public async Task<IActionResult> Index(string? search)
        {
            var usersQ = _db.UserProfiles.AsQueryable();
            if (!string.IsNullOrWhiteSpace(search))
                usersQ = usersQ.Where(u => u.FullName.Contains(search) || (u.UserId != null && u.UserId.Contains(search)));

            return View(new UsersViewModel
            {
                Users = await usersQ.OrderByDescending(u => u.CreatedDate).ToListAsync(),
                Highways = await _db.Highways.OrderBy(h => h.Name).ToListAsync(),
                Devices = await _db.SensorDevices.OrderBy(d => d.DeviceName).ToListAsync(),
                Form = new UserProfile { IsActive = true, UserType = "viewer" },
                Search = search
            });
        }

        [HttpPost, ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(UserProfile form, string[]? selectedDeviceIds, string[]? selectedDeviceNames)
        {
            form.DeviceIdsRaw = selectedDeviceIds != null ? string.Join(",", selectedDeviceIds) : null;
            form.DeviceNamesRaw = selectedDeviceNames != null ? string.Join(",", selectedDeviceNames) : null;
            form.CreatedDate = form.UpdatedDate = DateTime.UtcNow;
            _db.UserProfiles.Add(form);
            await _db.SaveChangesAsync();
            TempData["Success"] = "User profile created.";
            return RedirectToAction(nameof(Index));
        }

        [HttpPost, ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(UserProfile form, string[]? selectedDeviceIds, string[]? selectedDeviceNames)
        {
            var e = await _db.UserProfiles.FindAsync(form.Id);
            if (e == null) return NotFound();
            e.UserId = form.UserId; e.FullName = form.FullName;
            e.Address = form.Address; e.Phone = form.Phone;
            e.UserType = form.UserType; e.HighwayId = form.HighwayId;
            e.HighwayName = form.HighwayName; e.Notes = form.Notes;
            e.IsActive = form.IsActive; e.Password = form.Password;
            e.DeviceIdsRaw = selectedDeviceIds != null ? string.Join(",", selectedDeviceIds) : null;
            e.DeviceNamesRaw = selectedDeviceNames != null ? string.Join(",", selectedDeviceNames) : null;
            e.UpdatedDate = DateTime.UtcNow;
            await _db.SaveChangesAsync();
            TempData["Success"] = "User profile updated.";
            return RedirectToAction(nameof(Index));
        }

        [HttpPost, ValidateAntiForgeryToken]
        public async Task<IActionResult> Delete(int id)
        {
            var u = await _db.UserProfiles.FindAsync(id);
            if (u != null) { _db.UserProfiles.Remove(u); await _db.SaveChangesAsync(); TempData["Success"] = "User deleted."; }
            return RedirectToAction(nameof(Index));
        }
    }
}
