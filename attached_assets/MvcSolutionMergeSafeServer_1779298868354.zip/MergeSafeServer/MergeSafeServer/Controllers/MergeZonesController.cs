using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using MergeSafeServer.Data;
using MergeSafeServer.Models;
using MergeSafeServer.ViewModels;

namespace MergeSafeServer.Controllers
{
    public class MergeZonesController : Controller
    {
        private readonly AppDbContext _db;

        public MergeZonesController(AppDbContext db)
        {
            _db = db;
        }

        public async Task<IActionResult> Index(string? highwayId)
        {
            var highways = await _db.Highways.OrderBy(h => h.Name).ToListAsync();
            highwayId ??= HttpContext.Session.GetString("HighwayId") ?? highways.FirstOrDefault()?.HighwayId;

            var zonesQ = _db.MergeZones.AsQueryable();
            if (!string.IsNullOrEmpty(highwayId))
                zonesQ = zonesQ.Where(z => z.HighwayId == highwayId);

            var vm = new MergeZoneViewModel
            {
                Zones = await zonesQ.OrderByDescending(z => z.CreatedDate).ToListAsync(),
                Highways = highways,
                SelectedHighwayId = highwayId,
                Form = new MergeZone { HighwayId = highwayId ?? string.Empty, GeofenceRadius = 500, Status = "active" }
            };
            return View(vm);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(MergeZone form)
        {
            if (!ModelState.IsValid)
                return RedirectToAction(nameof(Index), new { highwayId = form.HighwayId });

            form.CreatedDate = DateTime.UtcNow;
            form.UpdatedDate = DateTime.UtcNow;
            _db.MergeZones.Add(form);
            await _db.SaveChangesAsync();
            TempData["Success"] = "Merge zone created successfully.";
            return RedirectToAction(nameof(Index), new { highwayId = form.HighwayId });
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(MergeZone form)
        {
            var existing = await _db.MergeZones.FindAsync(form.Id);
            if (existing == null) return NotFound();

            existing.ZoneName = form.ZoneName;
            existing.ZoneId = form.ZoneId;
            existing.HighwayId = form.HighwayId;
            existing.MileMarker = form.MileMarker;
            existing.Latitude = form.Latitude;
            existing.Longitude = form.Longitude;
            existing.Status = form.Status;
            existing.GeofenceRadius = form.GeofenceRadius;
            existing.UpdatedDate = DateTime.UtcNow;

            await _db.SaveChangesAsync();
            TempData["Success"] = "Merge zone updated.";
            return RedirectToAction(nameof(Index), new { highwayId = form.HighwayId });
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Delete(int id, string? highwayId)
        {
            var zone = await _db.MergeZones.FindAsync(id);
            if (zone != null)
            {
                _db.MergeZones.Remove(zone);
                await _db.SaveChangesAsync();
                TempData["Success"] = "Merge zone deleted.";
            }
            return RedirectToAction(nameof(Index), new { highwayId });
        }
    }
}
