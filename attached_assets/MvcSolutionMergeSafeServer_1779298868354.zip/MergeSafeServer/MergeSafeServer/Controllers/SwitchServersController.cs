using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using MergeSafeServer.Data;
using MergeSafeServer.Models;
using MergeSafeServer.ViewModels;

namespace MergeSafeServer.Controllers
{
    public class SwitchServersController : Controller
    {
        private readonly AppDbContext _db;
        public SwitchServersController(AppDbContext db) { _db = db; }

        public async Task<IActionResult> Index(string? highwayId)
        {
            var highways = await _db.Highways.OrderBy(h => h.Name).ToListAsync();
            highwayId ??= HttpContext.Session.GetString("HighwayId") ?? highways.FirstOrDefault()?.HighwayId;
            var q = _db.SwitchServers.AsQueryable();
            if (!string.IsNullOrEmpty(highwayId)) q = q.Where(s => s.HighwayId == highwayId);
            return View(new SwitchServerViewModel
            {
                Servers = await q.OrderByDescending(s => s.CreatedDate).ToListAsync(),
                Highways = highways,
                SelectedHighwayId = highwayId,
                Form = new SwitchServer { HighwayId = highwayId ?? "", Port = 8080, Status = "online" }
            });
        }

        [HttpPost, ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(SwitchServer form)
        {
            form.CreatedDate = form.UpdatedDate = DateTime.UtcNow;
            _db.SwitchServers.Add(form);
            await _db.SaveChangesAsync();
            TempData["Success"] = "Switch server added.";
            return RedirectToAction(nameof(Index), new { highwayId = form.HighwayId });
        }

        [HttpPost, ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(SwitchServer form)
        {
            var e = await _db.SwitchServers.FindAsync(form.Id);
            if (e == null) return NotFound();
            e.ServerName = form.ServerName; e.ServerId = form.ServerId;
            e.ZoneId = form.ZoneId; e.HighwayId = form.HighwayId;
            e.IpAddress = form.IpAddress; e.Port = form.Port;
            e.Status = form.Status; e.FirmwareVersion = form.FirmwareVersion;
            e.UpdatedDate = DateTime.UtcNow;
            await _db.SaveChangesAsync();
            TempData["Success"] = "Switch server updated.";
            return RedirectToAction(nameof(Index), new { highwayId = form.HighwayId });
        }

        [HttpPost, ValidateAntiForgeryToken]
        public async Task<IActionResult> Delete(int id, string? highwayId)
        {
            var s = await _db.SwitchServers.FindAsync(id);
            if (s != null) { _db.SwitchServers.Remove(s); await _db.SaveChangesAsync(); TempData["Success"] = "Deleted."; }
            return RedirectToAction(nameof(Index), new { highwayId });
        }
    }
}
