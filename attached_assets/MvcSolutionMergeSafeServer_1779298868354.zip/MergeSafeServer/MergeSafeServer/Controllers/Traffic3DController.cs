using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using MergeSafeServer.Data;

namespace MergeSafeServer.Controllers
{
    public class Traffic3DController : Controller
    {
        private readonly AppDbContext _db;
        private readonly IConfiguration _config;
        public Traffic3DController(AppDbContext db, IConfiguration config) { _db = db; _config = config; }

        public async Task<IActionResult> Index(string? highwayId)
        {
            var highways = await _db.Highways.OrderBy(h => h.Name).ToListAsync();
            highwayId ??= HttpContext.Session.GetString("HighwayId") ?? highways.FirstOrDefault()?.HighwayId;
            var sensors = await _db.SensorDevices
                .Where(s => highwayId == null || s.HighwayId == highwayId)
                .ToListAsync();
            var zones = await _db.MergeZones
                .Where(z => highwayId == null || z.HighwayId == highwayId)
                .ToListAsync();
            ViewBag.Highways = highways;
            ViewBag.SelectedHighwayId = highwayId;
            ViewBag.Sensors = sensors;
            ViewBag.Zones = zones;
            ViewBag.HasTomTomKey = !string.IsNullOrEmpty(_config["TomTomApiKey"]);
            return View();
        }
    }
}
