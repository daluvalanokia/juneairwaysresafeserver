using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using MergeSafeServer.Data;
using MergeSafeServer.ViewModels;

namespace MergeSafeServer.Controllers
{
    public class PortalController : Controller
    {
        private readonly AppDbContext _db;

        public PortalController(AppDbContext db)
        {
            _db = db;
        }

        public async Task<IActionResult> Index()
        {
            // If already logged in, redirect to dashboard
            if (HttpContext.Session.GetString("UserId") != null)
                return RedirectToAction("Index", "Dashboard");

            var vm = new PortalViewModel
            {
                Highways = await _db.Highways.Where(h => h.IsActive).ToListAsync()
            };
            return View(vm);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Login(string userId, string password, string highwayId)
        {
            var highways = await _db.Highways.Where(h => h.IsActive).ToListAsync();

            if (string.IsNullOrWhiteSpace(userId) || string.IsNullOrWhiteSpace(highwayId))
            {
                return View("Index", new PortalViewModel
                {
                    Highways = highways,
                    Error = "User ID and Interstate are required.",
                    SelectedHighwayId = highwayId
                });
            }

            var profiles = await _db.UserProfiles
                .Where(p => p.HighwayId == highwayId && p.IsActive)
                .ToListAsync();

            var match = profiles.FirstOrDefault(p =>
                string.Equals(p.UserId, userId.Trim(), StringComparison.OrdinalIgnoreCase));

            if (match == null)
            {
                return View("Index", new PortalViewModel
                {
                    Highways = highways,
                    Error = "User ID not found for the selected interstate.",
                    SelectedHighwayId = highwayId
                });
            }

            // Password check — if blank password on record, any value passes (demo mode)
            if (!string.IsNullOrEmpty(match.Password) && match.Password != password)
            {
                return View("Index", new PortalViewModel
                {
                    Highways = highways,
                    Error = "Incorrect password.",
                    SelectedHighwayId = highwayId
                });
            }

            HttpContext.Session.SetString("UserId", match.UserId ?? match.Id.ToString());
            HttpContext.Session.SetString("UserFullName", match.FullName);
            HttpContext.Session.SetString("UserType", match.UserType);
            HttpContext.Session.SetString("HighwayId", highwayId);

            return RedirectToAction("Index", "Dashboard");
        }

        public IActionResult Logout()
        {
            HttpContext.Session.Clear();
            return RedirectToAction("Index", "Portal");
        }
    }
}
