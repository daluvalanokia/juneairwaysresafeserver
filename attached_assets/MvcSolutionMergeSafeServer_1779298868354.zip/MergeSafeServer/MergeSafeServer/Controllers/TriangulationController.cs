using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using MergeSafeServer.Data;
using MergeSafeServer.Models;
using MergeSafeServer.ViewModels;

namespace MergeSafeServer.Controllers
{
    public class TriangulationController : Controller
    {
        private readonly AppDbContext _db;
        public TriangulationController(AppDbContext db) { _db = db; }

        public async Task<IActionResult> Index(string? highwayId)
        {
            var highways = await _db.Highways.OrderBy(h => h.Name).ToListAsync();
            highwayId ??= HttpContext.Session.GetString("HighwayId") ?? highways.FirstOrDefault()?.HighwayId;
            var q = _db.TriangulationConfigs.AsQueryable();
            if (!string.IsNullOrEmpty(highwayId)) q = q.Where(c => c.HighwayId == highwayId);
            return View(new TriangulationViewModel
            {
                Configs = await q.OrderByDescending(c => c.CreatedDate).ToListAsync(),
                Highways = highways,
                SelectedHighwayId = highwayId,
                Form = new TriangulationConfig
                {
                    HighwayId = highwayId ?? "",
                    GeofenceRadius = 500, IsActive = true,
                    Switch1Label = "Switch A", Switch2Label = "Switch B", Switch3Label = "Switch C"
                }
            });
        }

        [HttpPost, ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(TriangulationConfig form)
        {
            form.CreatedDate = form.UpdatedDate = DateTime.UtcNow;
            _db.TriangulationConfigs.Add(form);
            await _db.SaveChangesAsync();
            TempData["Success"] = "Triangulation config added.";
            return RedirectToAction(nameof(Index), new { highwayId = form.HighwayId });
        }

        [HttpPost, ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(TriangulationConfig form)
        {
            var e = await _db.TriangulationConfigs.FindAsync(form.Id);
            if (e == null) return NotFound();
            e.ZoneId = form.ZoneId; e.HighwayId = form.HighwayId;
            e.GeofenceRadius = form.GeofenceRadius; e.IsActive = form.IsActive;
            e.Switch1Label = form.Switch1Label; e.Switch1ServerId = form.Switch1ServerId;
            e.Switch1Lat = form.Switch1Lat; e.Switch1Lon = form.Switch1Lon;
            e.Switch2Label = form.Switch2Label; e.Switch2ServerId = form.Switch2ServerId;
            e.Switch2Lat = form.Switch2Lat; e.Switch2Lon = form.Switch2Lon;
            e.Switch3Label = form.Switch3Label; e.Switch3ServerId = form.Switch3ServerId;
            e.Switch3Lat = form.Switch3Lat; e.Switch3Lon = form.Switch3Lon;
            e.UpdatedDate = DateTime.UtcNow;
            await _db.SaveChangesAsync();
            TempData["Success"] = "Triangulation config updated.";
            return RedirectToAction(nameof(Index), new { highwayId = form.HighwayId });
        }

        [HttpPost, ValidateAntiForgeryToken]
        public async Task<IActionResult> Delete(int id, string? highwayId)
        {
            var c = await _db.TriangulationConfigs.FindAsync(id);
            if (c != null) { _db.TriangulationConfigs.Remove(c); await _db.SaveChangesAsync(); TempData["Success"] = "Deleted."; }
            return RedirectToAction(nameof(Index), new { highwayId });
        }
    }
}
