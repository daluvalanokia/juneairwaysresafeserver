using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using MergeSafeServer.Data;
using MergeSafeServer.ViewModels;

namespace MergeSafeServer.Controllers
{
    public class DashboardController : Controller
    {
        private readonly AppDbContext _db;

        public DashboardController(AppDbContext db)
        {
            _db = db;
        }

        public async Task<IActionResult> Index(string? highwayId)
        {
            var highways = await _db.Highways.OrderBy(h => h.Name).ToListAsync();
            highwayId ??= HttpContext.Session.GetString("HighwayId") ?? highways.FirstOrDefault()?.HighwayId;

            IQueryable<MergeSafeServer.Models.MergeZone> zonesQ = _db.MergeZones;
            IQueryable<MergeSafeServer.Models.SwitchServer> serversQ = _db.SwitchServers;
            IQueryable<MergeSafeServer.Models.SensorDevice> sensorsQ = _db.SensorDevices;
            IQueryable<MergeSafeServer.Models.VehicleEvent> eventsQ = _db.VehicleEvents;

            if (!string.IsNullOrEmpty(highwayId))
            {
                zonesQ = zonesQ.Where(z => z.HighwayId == highwayId);
                serversQ = serversQ.Where(s => s.HighwayId == highwayId);
                sensorsQ = sensorsQ.Where(s => s.HighwayId == highwayId);
                eventsQ = eventsQ.Where(e => e.HighwayId == highwayId);
            }

            var vm = new DashboardViewModel
            {
                Highways = highways,
                SelectedHighwayId = highwayId,
                Zones = await zonesQ.ToListAsync(),
                Servers = await serversQ.ToListAsync(),
                Sensors = await sensorsQ.ToListAsync(),
                RecentEvents = await eventsQ.OrderByDescending(e => e.CreatedDate).Take(20).ToListAsync()
            };

            return View(vm);
        }
    }
}
