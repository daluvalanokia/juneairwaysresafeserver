using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using MergeSafeServer.Data;
using MergeSafeServer.Models;
using MergeSafeServer.ViewModels;
using System.Text.Json;

namespace MergeSafeServer.Controllers
{
    public class DataInputFormatsController : Controller
    {
        private readonly AppDbContext _db;
        public DataInputFormatsController(AppDbContext db) { _db = db; }

        static readonly string[] COMMON_FIELDS = {
            "make","model","date","time","timestamp","coordinates","latitude","longitude",
            "speed","speed_mph","direction_degrees","firmware_version","status","vehicle_id",
            "tag_id","signal_strength_dbm","vehicle_type","traffic_density_percent","average_speed_mph"
        };

        public async Task<IActionResult> Index(string activeTab = "physical")
        {
            var all = await _db.InputFormatConfigs.OrderByDescending(c => c.CreatedDate).ToListAsync();
            var payloads = await _db.SamplePayloads.Include(p => p.FormatConfig).OrderByDescending(p => p.CreatedDate).ToListAsync();
            return View(new DataInputFormatsViewModel
            {
                PhysicalConfigs = all.Where(c => c.SourceType == "physical").ToList(),
                SatelliteConfigs = all.Where(c => c.SourceType == "satellite").ToList(),
                TelecomConfigs = all.Where(c => c.SourceType == "telecom").ToList(),
                TrackerConfigs = all.Where(c => c.SourceType == "tracker").ToList(),
                SavedPayloads = payloads,
                ActiveTab = activeTab,
                Form = new InputFormatConfig { SourceType = activeTab }
            });
        }

        [HttpPost, ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(InputFormatConfig form, string[]? enabledFields, string[]? customFieldNames, string[]? customFieldTypes)
        {
            form.EnabledFieldsRaw = enabledFields != null ? string.Join(",", enabledFields) : null;
            if (customFieldNames != null && customFieldNames.Length > 0)
            {
                var customs = customFieldNames.Select((name, i) => new { name, type = customFieldTypes?.ElementAtOrDefault(i) ?? "string" })
                    .Where(x => !string.IsNullOrWhiteSpace(x.name)).ToList();
                form.CustomFieldsJson = JsonSerializer.Serialize(customs);
            }
            form.CreatedDate = form.UpdatedDate = DateTime.UtcNow;
            _db.InputFormatConfigs.Add(form);
            await _db.SaveChangesAsync();
            TempData["Success"] = "Format configuration created.";
            return RedirectToAction(nameof(Index), new { activeTab = form.SourceType });
        }

        [HttpPost, ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(InputFormatConfig form, string[]? enabledFields, string[]? customFieldNames, string[]? customFieldTypes)
        {
            var e = await _db.InputFormatConfigs.FindAsync(form.Id);
            if (e == null) return NotFound();
            e.FormatName = form.FormatName; e.SourceId = form.SourceId;
            e.InputSource = form.InputSource; e.Description = form.Description;
            e.SourceType = form.SourceType;
            e.EnabledFieldsRaw = enabledFields != null ? string.Join(",", enabledFields) : null;
            if (customFieldNames != null && customFieldNames.Length > 0)
            {
                var customs = customFieldNames.Select((name, i) => new { name, type = customFieldTypes?.ElementAtOrDefault(i) ?? "string" })
                    .Where(x => !string.IsNullOrWhiteSpace(x.name)).ToList();
                e.CustomFieldsJson = JsonSerializer.Serialize(customs);
            }
            e.UpdatedDate = DateTime.UtcNow;
            await _db.SaveChangesAsync();
            TempData["Success"] = "Format updated.";
            return RedirectToAction(nameof(Index), new { activeTab = form.SourceType });
        }

        [HttpPost, ValidateAntiForgeryToken]
        public async Task<IActionResult> Delete(int id, string? activeTab)
        {
            var c = await _db.InputFormatConfigs.FindAsync(id);
            if (c != null) { _db.InputFormatConfigs.Remove(c); await _db.SaveChangesAsync(); TempData["Success"] = "Deleted."; }
            return RedirectToAction(nameof(Index), new { activeTab });
        }

        [HttpPost, ValidateAntiForgeryToken]
        public async Task<IActionResult> GeneratePayload(int configId)
        {
            var config = await _db.InputFormatConfigs.FindAsync(configId);
            if (config == null) return NotFound();
            var fields = config.EnabledFieldsRaw?.Split(',', StringSplitOptions.RemoveEmptyEntries) ?? Array.Empty<string>();
            var payload = GenerateSamplePayload(config.SourceType, fields);
            var sp = new SamplePayload
            {
                SourceType = config.SourceType, FormatConfigId = config.Id,
                FormatName = config.FormatName, Payload = JsonSerializer.Serialize(payload, new JsonSerializerOptions { WriteIndented = true }),
                IsValid = true, Label = config.FormatName,
                CreatedDate = DateTime.UtcNow, UpdatedDate = DateTime.UtcNow
            };
            _db.SamplePayloads.Add(sp);
            await _db.SaveChangesAsync();
            TempData["Success"] = "Sample payload generated and saved.";
            return RedirectToAction(nameof(Index), new { activeTab = config.SourceType });
        }

        [HttpPost, ValidateAntiForgeryToken]
        public async Task<IActionResult> DeletePayload(int id, string? activeTab)
        {
            var p = await _db.SamplePayloads.FindAsync(id);
            if (p != null) { _db.SamplePayloads.Remove(p); await _db.SaveChangesAsync(); TempData["Success"] = "Payload deleted."; }
            return RedirectToAction(nameof(Index), new { activeTab });
        }

        private static Dictionary<string, object?> GenerateSamplePayload(string sourceType, string[] fields)
        {
            var rng = Random.Shared;
            var baseId = sourceType switch
            {
                "satellite" => $"SAT-{rng.Next(1000, 9999)}",
                "telecom"   => $"TEL-{rng.Next(1000, 9999)}",
                "tracker"   => $"TRK-{rng.Next(1000, 9999)}",
                _           => $"SEN-{rng.Next(1000, 9999)}"
            };
            var data = new Dictionary<string, object?> { ["source_id"] = baseId };
            var now = DateTime.UtcNow;
            foreach (var f in fields)
            {
                data[f] = f switch
                {
                    "timestamp"               => now.ToString("o"),
                    "date"                    => now.ToString("yyyy-MM-dd"),
                    "time"                    => now.ToString("HH:mm:ss"),
                    "latitude"                => Math.Round(32.7767 + (rng.NextDouble() - 0.5) * 0.2, 6),
                    "longitude"               => Math.Round(-96.7970 + (rng.NextDouble() - 0.5) * 0.2, 6),
                    "coordinates"             => $"{Math.Round(32.7767 + (rng.NextDouble() - 0.5) * 0.2, 6)},{Math.Round(-96.797 + (rng.NextDouble() - 0.5) * 0.2, 6)}",
                    "speed"                   => rng.Next(20, 100),
                    "speed_mph"               => rng.Next(20, 100),
                    "direction_degrees"       => rng.Next(0, 360),
                    "status"                  => new[] { "active", "idle", "alert" }[rng.Next(3)],
                    "vehicle_id"              => $"VEH-{rng.Next(10000, 99999)}",
                    "vehicle_type"            => new[] { "sedan", "truck", "suv", "motorcycle" }[rng.Next(4)],
                    "tag_id"                  => $"TAG-{rng.Next(10000, 99999)}",
                    "signal_strength_dbm"     => rng.Next(-90, -40),
                    "firmware_version"        => $"2.{rng.Next(0, 9)}.{rng.Next(0, 99)}",
                    "traffic_density_percent" => rng.Next(5, 95),
                    "average_speed_mph"       => rng.Next(30, 75),
                    "make"                    => new[] { "Toyota", "Ford", "GM", "Honda" }[rng.Next(4)],
                    "model"                   => new[] { "Camry", "F-150", "Silverado", "Civic" }[rng.Next(4)],
                    _                         => $"sample_{f}"
                };
            }
            return new Dictionary<string, object?> { ["source_type"] = sourceType, ["data"] = data, ["generated_at"] = now.ToString("o") };
        }
    }
}
