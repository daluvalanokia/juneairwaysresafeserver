using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using MergeSafeServer.Data;
using MergeSafeServer.Models;
using System.Text.Json;

namespace MergeSafeServer.Controllers
{
    /// <summary>
    /// REST API endpoints for external sensor / device integrations.
    /// Base route: /api
    /// </summary>
    [Route("api")]
    [ApiController]
    public class ApiController : ControllerBase
    {
        private readonly AppDbContext _db;
        private readonly ILogger<ApiController> _logger;

        public ApiController(AppDbContext db, ILogger<ApiController> logger)
        {
            _db = db;
            _logger = logger;
        }

        // ── Health check ─────────────────────────────────────────────────
        // GET /api/health
        [HttpGet("health")]
        public IActionResult Health() =>
            Ok(new { status = "ok", timestamp = DateTime.UtcNow, version = "1.0.0" });

        // ── Event ingestion ──────────────────────────────────────────────
        // POST /api/events
        // Body: { zoneId, highwayId, eventType, vehicleId, speedMph, latitude, longitude, confidence, deviceId, serverId, rawData }
        [HttpPost("events")]
        public async Task<IActionResult> IngestEvent([FromBody] IngestEventRequest req)
        {
            if (string.IsNullOrWhiteSpace(req.ZoneId) || string.IsNullOrWhiteSpace(req.EventType))
                return BadRequest(new { error = "zoneId and eventType are required." });

            var ev = new VehicleEvent
            {
                ZoneId     = req.ZoneId,
                HighwayId  = req.HighwayId,
                ServerId   = req.ServerId,
                DeviceId   = req.DeviceId,
                EventType  = req.EventType.ToLowerInvariant(),
                VehicleId  = req.VehicleId,
                SpeedMph   = req.SpeedMph,
                Latitude   = req.Latitude,
                Longitude  = req.Longitude,
                Confidence = req.Confidence,
                Timestamp  = req.Timestamp ?? DateTime.UtcNow,
                RawData    = req.RawData != null ? JsonSerializer.Serialize(req.RawData) : null,
                CreatedDate = DateTime.UtcNow,
                UpdatedDate = DateTime.UtcNow
            };

            _db.VehicleEvents.Add(ev);
            await _db.SaveChangesAsync();

            _logger.LogInformation("Event ingested: {EventType} in zone {ZoneId}", ev.EventType, ev.ZoneId);
            return Created($"/api/events/{ev.Id}", new { id = ev.Id, accepted = true });
        }

        // POST /api/events/batch
        // Body: [ { ...event fields }, ... ]
        [HttpPost("events/batch")]
        public async Task<IActionResult> IngestEventBatch([FromBody] List<IngestEventRequest> reqs)
        {
            if (reqs == null || !reqs.Any())
                return BadRequest(new { error = "Empty batch." });

            var created = 0;
            foreach (var req in reqs.Take(500)) // safety cap
            {
                if (string.IsNullOrWhiteSpace(req.ZoneId) || string.IsNullOrWhiteSpace(req.EventType)) continue;
                _db.VehicleEvents.Add(new VehicleEvent
                {
                    ZoneId      = req.ZoneId,
                    HighwayId   = req.HighwayId,
                    ServerId    = req.ServerId,
                    DeviceId    = req.DeviceId,
                    EventType   = req.EventType.ToLowerInvariant(),
                    VehicleId   = req.VehicleId,
                    SpeedMph    = req.SpeedMph,
                    Latitude    = req.Latitude,
                    Longitude   = req.Longitude,
                    Confidence  = req.Confidence,
                    Timestamp   = req.Timestamp ?? DateTime.UtcNow,
                    RawData     = req.RawData != null ? JsonSerializer.Serialize(req.RawData) : null,
                    CreatedDate = DateTime.UtcNow,
                    UpdatedDate = DateTime.UtcNow
                });
                created++;
            }
            await _db.SaveChangesAsync();
            return Ok(new { accepted = created, total = reqs.Count });
        }

        // GET /api/events?highwayId=I20&limit=50
        [HttpGet("events")]
        public async Task<IActionResult> GetEvents(
            [FromQuery] string? highwayId,
            [FromQuery] string? zoneId,
            [FromQuery] string? eventType,
            [FromQuery] int limit = 50)
        {
            limit = Math.Clamp(limit, 1, 500);
            var q = _db.VehicleEvents.AsQueryable();
            if (!string.IsNullOrEmpty(highwayId)) q = q.Where(e => e.HighwayId == highwayId);
            if (!string.IsNullOrEmpty(zoneId))    q = q.Where(e => e.ZoneId == zoneId);
            if (!string.IsNullOrEmpty(eventType)) q = q.Where(e => e.EventType == eventType);
            var results = await q.OrderByDescending(e => e.CreatedDate).Take(limit).ToListAsync();
            return Ok(results);
        }

        // ── Sensor heartbeat ─────────────────────────────────────────────
        // POST /api/sensors/{deviceId}/heartbeat
        // Body: { status?, firmwareVersion?, latitude?, longitude? }
        [HttpPost("sensors/{deviceId}/heartbeat")]
        public async Task<IActionResult> SensorHeartbeat(string deviceId, [FromBody] HeartbeatRequest req)
        {
            var sensor = await _db.SensorDevices
                .FirstOrDefaultAsync(s => s.DeviceId == deviceId);

            if (sensor == null)
                return NotFound(new { error = $"Sensor '{deviceId}' not found." });

            sensor.LastSeen       = DateTime.UtcNow;
            sensor.UpdatedDate    = DateTime.UtcNow;
            if (!string.IsNullOrEmpty(req.Status))          sensor.Status          = req.Status;
            if (!string.IsNullOrEmpty(req.FirmwareVersion)) sensor.FirmwareVersion = req.FirmwareVersion;
            if (req.Latitude.HasValue)  sensor.Latitude  = req.Latitude;
            if (req.Longitude.HasValue) sensor.Longitude = req.Longitude;

            await _db.SaveChangesAsync();
            return Ok(new { deviceId, lastSeen = sensor.LastSeen, status = sensor.Status });
        }

        // GET /api/sensors?highwayId=I20
        [HttpGet("sensors")]
        public async Task<IActionResult> GetSensors([FromQuery] string? highwayId, [FromQuery] string? zoneId)
        {
            var q = _db.SensorDevices.AsQueryable();
            if (!string.IsNullOrEmpty(highwayId)) q = q.Where(s => s.HighwayId == highwayId);
            if (!string.IsNullOrEmpty(zoneId))    q = q.Where(s => s.ZoneId == zoneId);
            return Ok(await q.OrderBy(s => s.DeviceName).ToListAsync());
        }

        // ── Switch server heartbeat ──────────────────────────────────────
        // POST /api/servers/{serverId}/heartbeat
        // Body: { status?, cpuPercent?, memoryPercent?, uptimeSeconds?, firmwareVersion? }
        [HttpPost("servers/{serverId}/heartbeat")]
        public async Task<IActionResult> ServerHeartbeat(string serverId, [FromBody] ServerHeartbeatRequest req)
        {
            var server = await _db.SwitchServers
                .FirstOrDefaultAsync(s => s.ServerId == serverId);

            if (server == null)
                return NotFound(new { error = $"Server '{serverId}' not found." });

            server.LastHeartbeat = DateTime.UtcNow;
            server.UpdatedDate   = DateTime.UtcNow;
            if (!string.IsNullOrEmpty(req.Status))          server.Status          = req.Status;
            if (!string.IsNullOrEmpty(req.FirmwareVersion)) server.FirmwareVersion = req.FirmwareVersion;
            if (req.CpuPercent.HasValue)     server.CpuPercent     = req.CpuPercent.Value;
            if (req.MemoryPercent.HasValue)  server.MemoryPercent  = req.MemoryPercent.Value;
            if (req.UptimeSeconds.HasValue)  server.UptimeSeconds  = req.UptimeSeconds.Value;

            await _db.SaveChangesAsync();
            return Ok(new { serverId, lastHeartbeat = server.LastHeartbeat, status = server.Status });
        }

        // GET /api/servers?highwayId=I20
        [HttpGet("servers")]
        public async Task<IActionResult> GetServers([FromQuery] string? highwayId)
        {
            var q = _db.SwitchServers.AsQueryable();
            if (!string.IsNullOrEmpty(highwayId)) q = q.Where(s => s.HighwayId == highwayId);
            return Ok(await q.OrderBy(s => s.ServerName).ToListAsync());
        }

        // ── Merge zones ───────────────────────────────────────────────────
        // GET /api/zones?highwayId=I20
        [HttpGet("zones")]
        public async Task<IActionResult> GetZones([FromQuery] string? highwayId)
        {
            var q = _db.MergeZones.AsQueryable();
            if (!string.IsNullOrEmpty(highwayId)) q = q.Where(z => z.HighwayId == highwayId);
            return Ok(await q.OrderBy(z => z.ZoneName).ToListAsync());
        }

        // PATCH /api/zones/{zoneId}/status
        // Body: { status }
        [HttpPatch("zones/{zoneId}/status")]
        public async Task<IActionResult> UpdateZoneStatus(string zoneId, [FromBody] ZoneStatusRequest req)
        {
            var zone = await _db.MergeZones.FirstOrDefaultAsync(z => z.ZoneId == zoneId);
            if (zone == null) return NotFound(new { error = $"Zone '{zoneId}' not found." });

            zone.Status      = req.Status;
            zone.UpdatedDate = DateTime.UtcNow;
            await _db.SaveChangesAsync();
            return Ok(new { zoneId, status = zone.Status });
        }

        // ── Highways ──────────────────────────────────────────────────────
        // GET /api/highways
        [HttpGet("highways")]
        public async Task<IActionResult> GetHighways() =>
            Ok(await _db.Highways.Where(h => h.IsActive).OrderBy(h => h.Name).ToListAsync());

        // ── Stats summary ─────────────────────────────────────────────────
        // GET /api/stats?highwayId=I20
        [HttpGet("stats")]
        public async Task<IActionResult> GetStats([FromQuery] string? highwayId)
        {
            var zonesQ   = _db.MergeZones.AsQueryable();
            var serversQ = _db.SwitchServers.AsQueryable();
            var sensorsQ = _db.SensorDevices.AsQueryable();
            var eventsQ  = _db.VehicleEvents.AsQueryable();

            if (!string.IsNullOrEmpty(highwayId))
            {
                zonesQ   = zonesQ.Where(z => z.HighwayId == highwayId);
                serversQ = serversQ.Where(s => s.HighwayId == highwayId);
                sensorsQ = sensorsQ.Where(s => s.HighwayId == highwayId);
                eventsQ  = eventsQ.Where(e => e.HighwayId == highwayId);
            }

            var since = DateTime.UtcNow.AddHours(-1);
            return Ok(new
            {
                highwayId,
                zones = new
                {
                    total       = await zonesQ.CountAsync(),
                    active      = await zonesQ.CountAsync(z => z.Status == "active"),
                    fault       = await zonesQ.CountAsync(z => z.Status == "fault"),
                    maintenance = await zonesQ.CountAsync(z => z.Status == "maintenance")
                },
                servers = new
                {
                    total   = await serversQ.CountAsync(),
                    online  = await serversQ.CountAsync(s => s.Status == "online"),
                    offline = await serversQ.CountAsync(s => s.Status == "offline"),
                    avgCpu  = await serversQ.AverageAsync(s => (double?)s.CpuPercent) ?? 0
                },
                sensors = new
                {
                    total   = await sensorsQ.CountAsync(),
                    online  = await sensorsQ.CountAsync(s => s.Status == "online"),
                    offline = await sensorsQ.CountAsync(s => s.Status == "offline"),
                    fault   = await sensorsQ.CountAsync(s => s.Status == "fault")
                },
                events = new
                {
                    lastHour   = await eventsQ.CountAsync(e => e.CreatedDate >= since),
                    detections = await eventsQ.CountAsync(e => e.CreatedDate >= since && e.EventType == "detection"),
                    conflicts  = await eventsQ.CountAsync(e => e.CreatedDate >= since && e.EventType == "conflict"),
                    faults     = await eventsQ.CountAsync(e => e.CreatedDate >= since && e.EventType == "fault")
                },
                generatedAt = DateTime.UtcNow
            });
        }
    }

    // ── Request DTOs ─────────────────────────────────────────────────────

    public class IngestEventRequest
    {
        public string ZoneId     { get; set; } = string.Empty;
        public string? HighwayId { get; set; }
        public string? ServerId  { get; set; }
        public string? DeviceId  { get; set; }
        public string EventType  { get; set; } = "detection";
        public string? VehicleId { get; set; }
        public double? SpeedMph  { get; set; }
        public double? Latitude  { get; set; }
        public double? Longitude { get; set; }
        public double? Confidence { get; set; }
        public DateTime? Timestamp { get; set; }
        public object? RawData   { get; set; }
    }

    public class HeartbeatRequest
    {
        public string? Status          { get; set; }
        public string? FirmwareVersion { get; set; }
        public double? Latitude        { get; set; }
        public double? Longitude       { get; set; }
    }

    public class ServerHeartbeatRequest
    {
        public string? Status          { get; set; }
        public string? FirmwareVersion { get; set; }
        public double? CpuPercent      { get; set; }
        public double? MemoryPercent   { get; set; }
        public long?   UptimeSeconds   { get; set; }
    }

    public class ZoneStatusRequest
    {
        public string Status { get; set; } = "active";
    }
}
