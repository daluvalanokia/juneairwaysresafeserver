# MergeSafeServer

Autonomous Merge Zone Control Platform — ASP.NET Core 8 MVC

---

## Quick Start

### Prerequisites
- [.NET 8 SDK](https://dotnet.microsoft.com/download/dotnet/8)

### Run locally

```bash
cd MergeSafeServer
dotnet run --project MergeSafeServer
```

Then open http://localhost:5000 (or https://localhost:5001).

The SQLite database (`mergesafe.db`) is auto-created on first launch with a seeded default highway (Interstate 20 / I20).

---

## First Login

On first launch there are no user profiles. Either:
1. Go to `/Settings` (no auth required initially) → add a Highway
2. Go to `/Users` → add a User Profile with your chosen User ID
3. Navigate to `/Portal` → select the highway and sign in

Or add the default admin in code by seeding a `UserProfile` in `AppDbContext.OnModelCreating`.

---

## Project Structure

```
MergeSafeServer/
├── Controllers/
│   ├── ApiController.cs          ← REST API for sensor/device ingestion
│   ├── DashboardController.cs
│   ├── DataInputFormatsController.cs
│   ├── EventsController.cs
│   ├── HomeController.cs
│   ├── MergeZonesController.cs
│   ├── PortalController.cs       ← Login / logout
│   ├── SensorsController.cs
│   ├── SettingsController.cs
│   ├── SwitchServersController.cs
│   ├── Traffic3DController.cs
│   ├── TriangulationController.cs
│   └── UsersController.cs
├── Data/
│   └── AppDbContext.cs           ← EF Core SQLite context
├── Models/                       ← Domain models
├── ViewModels/                   ← View-specific DTOs
├── Views/                        ← Razor views
│   ├── Shared/_Layout.cshtml     ← Dark sidebar layout
│   └── Portal/Index.cshtml       ← Standalone login page
└── wwwroot/
    ├── css/site.css              ← Dark theme
    └── js/site.js
```

---

## REST API

Base URL: `/api`

| Method | Route | Description |
|--------|-------|-------------|
| GET    | `/api/health` | Health check |
| GET    | `/api/stats?highwayId=` | System statistics summary |
| POST   | `/api/events` | Ingest a single vehicle event |
| POST   | `/api/events/batch` | Ingest up to 500 events |
| GET    | `/api/events?highwayId=&zoneId=&eventType=&limit=` | Query events |
| GET    | `/api/sensors?highwayId=&zoneId=` | List sensors |
| POST   | `/api/sensors/{deviceId}/heartbeat` | Sensor heartbeat update |
| GET    | `/api/servers?highwayId=` | List switch servers |
| POST   | `/api/servers/{serverId}/heartbeat` | Server heartbeat + telemetry |
| GET    | `/api/zones?highwayId=` | List merge zones |
| PATCH  | `/api/zones/{zoneId}/status` | Update zone status |
| GET    | `/api/highways` | List active highways |

### Example — ingest an event
```bash
curl -X POST http://localhost:5000/api/events \
  -H "Content-Type: application/json" \
  -d '{"zoneId":"ZONE-001","highwayId":"I20","eventType":"detection","vehicleId":"VEH-4291","speedMph":67.3,"latitude":32.7767,"longitude":-96.7970,"confidence":94}'
```

### Example — sensor heartbeat
```bash
curl -X POST http://localhost:5000/api/sensors/CAM-001/heartbeat \
  -H "Content-Type: application/json" \
  -d '{"status":"online","firmwareVersion":"2.3.1"}'
```

---

## TomTom API Key (3D Traffic)

Add your key to `appsettings.json`:
```json
{ "TomTomApiKey": "YOUR_KEY_HERE" }
```
Or paste it in the Settings page UI.

---

## Configuration

`appsettings.json`:
```json
{
  "ConnectionStrings": {
    "DefaultConnection": "Data Source=mergesafe.db"
  },
  "TomTomApiKey": ""
}
```

To use a different database, change the connection string — EF Core supports SQL Server, PostgreSQL (with Npgsql), and MySQL.

---

## Deployment

```bash
dotnet publish -c Release -o ./publish
cd publish
dotnet MergeSafeServer.dll
```

For IIS, use `dotnet publish` and point an IIS site at the publish folder with the ASP.NET Core Module.
