#!/bin/bash
# Usage: ./run_seed.sh [path/to/mergesafe.db]
# Default: looks for the DB in MergeSafeServer/mergesafe.db

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
DB_PATH="${1:-$SCRIPT_DIR/../MergeSafeServer/mergesafe.db}"

echo "Seeding database: $DB_PATH"

export PATH="/usr/local/dotnet:$PATH"
cd "$SCRIPT_DIR"
dotnet run --project Seed.csproj -- "$DB_PATH"
