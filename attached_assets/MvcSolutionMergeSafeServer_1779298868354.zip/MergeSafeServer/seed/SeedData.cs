// MergeSafeServer — comprehensive test data seeder
// Run: dotnet run --project seed/Seed.csproj  (or execute via bash script below)

using Microsoft.Data.Sqlite;
using System.Text.Json;

var dbPath = args.Length > 0 ? args[0] : "mergesafe.db";
var conn = new SqliteConnection($"Data Source={dbPath}");
conn.Open();

Console.WriteLine($"Connected to: {dbPath}");
Console.WriteLine("Seeding test data...\n");

void Exec(string sql, object? p = null)
{
    var cmd = conn.CreateCommand();
    cmd.CommandText = sql;
    if (p != null)
        foreach (var prop in p.GetType().GetProperties())
            cmd.Parameters.AddWithValue("@" + prop.Name, prop.GetValue(p) ?? DBNull.Value);
    cmd.ExecuteNonQuery();
}

long LastId()
{
    var cmd = conn.CreateCommand();
    cmd.CommandText = "SELECT last_insert_rowid()";
    return (long)cmd.ExecuteScalar()!;
}

var now = DateTime.UtcNow;
string Ts(int daysAgo = 0, int hoursAgo = 0) =>
    now.AddDays(-daysAgo).AddHours(-hoursAgo).ToString("o");

// ── Clear existing data (order matters for FK) ────────────────
Console.WriteLine("Clearing existing seeded data...");
foreach (var t in new[]{"SamplePayloads","InputFormatConfigs","VehicleEvents","TriangulationConfigs","SensorDevices","SwitchServers","MergeZones","UserProfiles","Highways"})
    Exec($"DELETE FROM {t} WHERE Id > 1"); // keep the EF seed row (Id=1)

// ══════════════════════════════════════════════════════════════
// 1. HIGHWAYS  (3 real Texas interstates + 1 fault state)
// ══════════════════════════════════════════════════════════════
Console.WriteLine("Seeding Highways...");

// I20 (Id=1) already seeded by EF OnModelCreating — update it to be richer
Exec(@"UPDATE Highways SET Name='Interstate 20', HighwayId='I20', State='TX',
       Description='Dallas–Fort Worth to Abilene corridor, 200 mi monitored',
       IsActive=1, UpdatedDate=@u WHERE Id=1", new { u = Ts() });

Exec(@"INSERT INTO Highways (Name,HighwayId,State,Description,IsActive,CreatedDate,UpdatedDate)
       VALUES ('Interstate 35','I35','TX','San Antonio to Dallas corridor, 270 mi monitored',1,@c,@u)",
     new { c = Ts(30), u = Ts() });
var i35Id = LastId(); // 2

Exec(@"INSERT INTO Highways (Name,HighwayId,State,Description,IsActive,CreatedDate,UpdatedDate)
       VALUES ('Interstate 10','I10','TX','Houston to El Paso corridor, 350 mi monitored',1,@c,@u)",
     new { c = Ts(20), u = Ts() });
var i10Id = LastId(); // 3

Exec(@"INSERT INTO Highways (Name,HighwayId,State,Description,IsActive,CreatedDate,UpdatedDate)
       VALUES ('Interstate 45','I45','TX','Houston to Dallas corridor — OFFLINE for maintenance',0,@c,@u)",
     new { c = Ts(10), u = Ts() });
// i45Id = 4 (inactive, tests "no active highway" path)

Console.WriteLine($"  ✓ 4 highways");

// ══════════════════════════════════════════════════════════════
// 2. MERGE ZONES — varied statuses across all 3 active highways
// ══════════════════════════════════════════════════════════════
Console.WriteLine("Seeding MergeZones...");

// I20 zones (highwayId = 'I20')
var zonesI20 = new[]
{
    ("I20-ZONE-001","MM 450 — Mesquite On-Ramp","active", 32.7700,-96.7870, 450.0, 500.0),
    ("I20-ZONE-002","MM 462 — Grand Prairie Merge","active", 32.7460,-97.0020, 462.0, 600.0),
    ("I20-ZONE-003","MM 478 — Arlington Interchange","fault",  32.7351,-97.2900, 478.0, 400.0),
    ("I20-ZONE-004","MM 490 — Fort Worth East","maintenance",32.7548,-97.4320, 490.0, 550.0),
    ("I20-ZONE-005","MM 502 — Fort Worth West","active", 32.7550,-97.5200, 502.0, 480.0),
};
var zoneI20Ids = new List<long>();
foreach (var (zid,name,status,lat,lon,mm,geo) in zonesI20)
{
    Exec(@"INSERT INTO MergeZones (HighwayId,ZoneName,ZoneId,MileMarker,Latitude,Longitude,Status,GeofenceRadius,CreatedDate,UpdatedDate)
           VALUES ('I20',@n,@z,@mm,@lat,@lon,@s,@g,@c,@u)",
         new { n=name, z=zid, mm, lat, lon, s=status, g=geo, c=Ts(15), u=Ts() });
    zoneI20Ids.Add(LastId());
}

// I35 zones
var zonesI35 = new[]
{
    ("I35-ZONE-001","MM 200 — Austin North Merge","active",  30.3870,-97.7100, 200.0, 520.0),
    ("I35-ZONE-002","MM 215 — Round Rock On-Ramp","active",  30.5083,-97.6789, 215.0, 480.0),
    ("I35-ZONE-003","MM 230 — Georgetown Merge","fault",   30.6325,-97.6773, 230.0, 600.0),
    ("I35-ZONE-004","MM 250 — Temple Interchange","active",  31.0977,-97.3428, 250.0, 550.0),
};
var zoneI35Ids = new List<long>();
foreach (var (zid,name,status,lat,lon,mm,geo) in zonesI35)
{
    Exec(@"INSERT INTO MergeZones (HighwayId,ZoneName,ZoneId,MileMarker,Latitude,Longitude,Status,GeofenceRadius,CreatedDate,UpdatedDate)
           VALUES ('I35',@n,@z,@mm,@lat,@lon,@s,@g,@c,@u)",
         new { n=name, z=zid, mm, lat, lon, s=status, g=geo, c=Ts(10), u=Ts() });
    zoneI35Ids.Add(LastId());
}

// I10 zones
var zonesI10 = new[]
{
    ("I10-ZONE-001","MM 740 — Houston West Merge","active",      29.7604,-95.3698, 740.0, 500.0),
    ("I10-ZONE-002","MM 755 — Katy Freeway Merge","maintenance", 29.7858,-95.7240, 755.0, 600.0),
    ("I10-ZONE-003","MM 780 — San Antonio East","active",        29.4241,-98.4936, 780.0, 520.0),
};
var zoneI10Ids = new List<long>();
foreach (var (zid,name,status,lat,lon,mm,geo) in zonesI10)
{
    Exec(@"INSERT INTO MergeZones (HighwayId,ZoneName,ZoneId,MileMarker,Latitude,Longitude,Status,GeofenceRadius,CreatedDate,UpdatedDate)
           VALUES ('I10',@n,@z,@mm,@lat,@lon,@s,@g,@c,@u)",
         new { n=name, z=zid, mm, lat, lon, s=status, g=geo, c=Ts(8), u=Ts() });
    zoneI10Ids.Add(LastId());
}

Console.WriteLine($"  ✓ {zonesI20.Length + zonesI35.Length + zonesI10.Length} merge zones");

// ══════════════════════════════════════════════════════════════
// 3. SWITCH SERVERS — 2-3 per highway, mixed statuses
// ══════════════════════════════════════════════════════════════
Console.WriteLine("Seeding SwitchServers...");

var servers = new[]
{
    // I20
    ("I20","I20-ZONE-001","SVR-I20-A1","Alpha Node 1","192.168.10.11",8080,"online",  18.4,42.1,864000L,"3.2.1"),
    ("I20","I20-ZONE-002","SVR-I20-A2","Alpha Node 2","192.168.10.12",8080,"online",  34.7,55.8,720000L,"3.2.1"),
    ("I20","I20-ZONE-003","SVR-I20-B1","Beta Node 1", "192.168.10.21",8080,"degraded",71.2,88.9,345600L,"3.1.4"),
    ("I20","I20-ZONE-004","SVR-I20-B2","Beta Node 2", "192.168.10.22",8080,"offline", 0.0,  0.0, 0L,     "3.0.9"),
    ("I20","I20-ZONE-005","SVR-I20-C1","Gamma Node 1","192.168.10.31",8080,"online",  22.1,38.4,432000L,"3.2.1"),
    // I35
    ("I35","I35-ZONE-001","SVR-I35-A1","I35 Alpha 1", "192.168.20.11",8080,"online",  15.9,44.2,900000L,"3.2.0"),
    ("I35","I35-ZONE-002","SVR-I35-A2","I35 Alpha 2", "192.168.20.12",8080,"online",  28.3,51.6,750000L,"3.2.0"),
    ("I35","I35-ZONE-003","SVR-I35-B1","I35 Beta 1",  "192.168.20.21",8080,"fault",   95.1,97.8,86400L, "3.1.2"),
    ("I35","I35-ZONE-004","SVR-I35-B2","I35 Beta 2",  "192.168.20.22",8080,"online",  19.5,40.2,600000L,"3.2.0"),
    // I10
    ("I10","I10-ZONE-001","SVR-I10-A1","I10 Alpha 1", "192.168.30.11",8080,"online",  12.8,35.4,960000L,"3.2.1"),
    ("I10","I10-ZONE-002","SVR-I10-A2","I10 Alpha 2", "192.168.30.12",8080,"maintenance",0.0,0.0,0L,    "3.2.1"),
    ("I10","I10-ZONE-003","SVR-I10-B1","I10 Beta 1",  "192.168.30.21",8080,"online",  30.6,58.9,480000L,"3.2.1"),
};
var serverIds = new List<(string zoneId, string serverId)>();
foreach (var (hw,zid,sid,name,ip,port,status,cpu,mem,up,fw) in servers)
{
    var hb = status == "offline" ? (object)DBNull.Value : (object)Ts(0, 0);
    Exec(@"INSERT INTO SwitchServers (ZoneId,HighwayId,ServerName,ServerId,IpAddress,Port,Status,CpuPercent,MemoryPercent,UptimeSeconds,LastHeartbeat,FirmwareVersion,CreatedDate,UpdatedDate)
           VALUES (@z,@hw,@n,@s,@ip,@p,@st,@cpu,@mem,@up,@hb,@fw,@c,@u)",
         new { z=zid, hw, n=name, s=sid, ip, p=port, st=status, cpu, mem, up, hb, fw, c=Ts(20), u=Ts() });
    serverIds.Add((zid, sid));
}
Console.WriteLine($"  ✓ {servers.Length} switch servers");

// ══════════════════════════════════════════════════════════════
// 4. SENSOR DEVICES — multiple types per zone
// ══════════════════════════════════════════════════════════════
Console.WriteLine("Seeding SensorDevices...");

// Helper — device type → source type
string SrcType(string dt) => dt switch {
    "camera" or "lidar" or "radar" => "physical",
    "signal receiver" => "satellite",
    "vehicle tag reader" => "telecom",
    _ => "physical"
};

var sensors = new[]
{
    // I20-ZONE-001 — full healthy set
    ("I20","I20-ZONE-001","SVR-I20-A1","CAM-I20-001","Camera Alpha 1","camera","online",    5.2,450.1,32.7705,-96.7875,"2.3.1"),
    ("I20","I20-ZONE-001","SVR-I20-A1","LDR-I20-001","LiDAR Alpha 1","lidar","online",      5.2,450.1,32.7698,-96.7868,"2.1.0"),
    ("I20","I20-ZONE-001","SVR-I20-A1","RAD-I20-001","Radar Alpha 1","radar","online",      5.2,450.1,32.7702,-96.7872,"1.9.4"),
    ("I20","I20-ZONE-001","SVR-I20-A1","TAG-I20-001","Tag Reader A1","vehicle tag reader","online",4.0,450.0,32.7700,-96.7870,"1.4.2"),
    // I20-ZONE-002
    ("I20","I20-ZONE-002","SVR-I20-A2","CAM-I20-002","Camera Alpha 2","camera","online",    5.1,462.0,32.7465,-97.0025,"2.3.1"),
    ("I20","I20-ZONE-002","SVR-I20-A2","LDR-I20-002","LiDAR Alpha 2","lidar","online",      5.1,462.0,32.7458,-97.0018,"2.1.0"),
    ("I20","I20-ZONE-002","SVR-I20-A2","SIG-I20-001","Satellite Rcvr 1","signal receiver","online",0.0,462.0,32.7460,-97.0020,"1.2.3"),
    // I20-ZONE-003 — fault zone (some sensors down)
    ("I20","I20-ZONE-003","SVR-I20-B1","CAM-I20-003","Camera Beta 1","camera","fault",      5.0,478.0,32.7355,-97.2905,"2.2.9"),
    ("I20","I20-ZONE-003","SVR-I20-B1","LDR-I20-003","LiDAR Beta 1","lidar","offline",      5.0,478.0,32.7348,-97.2898,"2.0.8"),
    ("I20","I20-ZONE-003","SVR-I20-B1","RAD-I20-002","Radar Beta 1","radar","online",       5.0,478.0,32.7352,-97.2902,"1.9.4"),
    // I20-ZONE-004 — maintenance
    ("I20","I20-ZONE-004","SVR-I20-B2","CAM-I20-004","Camera Beta 2","camera","maintenance",5.0,490.0,32.7550,-97.4325,"2.3.0"),
    ("I20","I20-ZONE-004","SVR-I20-B2","TAG-I20-002","Tag Reader A2","vehicle tag reader","maintenance",4.0,490.0,32.7545,-97.4318,"1.4.1"),
    // I20-ZONE-005
    ("I20","I20-ZONE-005","SVR-I20-C1","CAM-I20-005","Camera Gamma 1","camera","online",    5.2,502.0,32.7553,-97.5205,"2.3.1"),
    ("I20","I20-ZONE-005","SVR-I20-C1","LDR-I20-004","LiDAR Gamma 1","lidar","calibrating", 5.2,502.0,32.7548,-97.5198,"2.1.1"),
    // I35
    ("I35","I35-ZONE-001","SVR-I35-A1","CAM-I35-001","I35 Cam A1","camera","online",        5.1,200.0,30.3875,-97.7105,"2.3.1"),
    ("I35","I35-ZONE-001","SVR-I35-A1","LDR-I35-001","I35 LiDAR A1","lidar","online",       5.1,200.0,30.3868,-97.7098,"2.1.0"),
    ("I35","I35-ZONE-001","SVR-I35-A1","RAD-I35-001","I35 Radar A1","radar","online",        5.1,200.0,30.3872,-97.7102,"1.9.5"),
    ("I35","I35-ZONE-002","SVR-I35-A2","CAM-I35-002","I35 Cam A2","camera","online",         5.0,215.0,30.5088,-97.6794,"2.3.1"),
    ("I35","I35-ZONE-002","SVR-I35-A2","SIG-I35-001","I35 Sat Rcvr 1","signal receiver","online",0.0,215.0,30.5083,-97.6789,"1.2.4"),
    ("I35","I35-ZONE-003","SVR-I35-B1","CAM-I35-003","I35 Cam B1","camera","fault",          5.0,230.0,30.6328,-97.6778,"2.2.7"),
    ("I35","I35-ZONE-003","SVR-I35-B1","LDR-I35-002","I35 LiDAR B1","lidar","fault",         5.0,230.0,30.6321,-97.6770,"2.0.5"),
    ("I35","I35-ZONE-004","SVR-I35-B2","CAM-I35-004","I35 Cam B2","camera","online",          5.1,250.0,31.0982,-97.3433,"2.3.1"),
    ("I35","I35-ZONE-004","SVR-I35-B2","TAG-I35-001","I35 Tag Reader","vehicle tag reader","online",4.0,250.0,31.0977,-97.3428,"1.4.2"),
    // I10
    ("I10","I10-ZONE-001","SVR-I10-A1","CAM-I10-001","I10 Cam A1","camera","online",          5.2,740.0,29.7608,-95.3702,"2.3.1"),
    ("I10","I10-ZONE-001","SVR-I10-A1","LDR-I10-001","I10 LiDAR A1","lidar","online",         5.2,740.0,29.7600,-95.3694,"2.1.0"),
    ("I10","I10-ZONE-001","SVR-I10-A1","RAD-I10-001","I10 Radar A1","radar","online",          5.2,740.0,29.7604,-95.3698,"1.9.4"),
    ("I10","I10-ZONE-002","SVR-I10-A2","CAM-I10-002","I10 Cam A2","camera","maintenance",      5.0,755.0,29.7862,-95.7245,"2.3.0"),
    ("I10","I10-ZONE-002","SVR-I10-A2","SIG-I10-001","I10 Sat Rcvr 1","signal receiver","maintenance",0.0,755.0,29.7858,-95.7240,"1.2.3"),
    ("I10","I10-ZONE-003","SVR-I10-B1","CAM-I10-003","I10 Cam B1","camera","online",           5.1,780.0,29.4245,-98.4940,"2.3.1"),
    ("I10","I10-ZONE-003","SVR-I10-B1","LDR-I10-002","I10 LiDAR B2","lidar","online",          5.1,780.0,29.4238,-98.4932,"2.1.0"),
};

foreach (var (hw,zid,sid,did,name,dtype,status,ht,mm,lat,lon,fw) in sensors)
{
    var ls = status == "offline" ? (object)DBNull.Value : (object)Ts(0, 1);
    Exec(@"INSERT INTO SensorDevices (ZoneId,HighwayId,ServerId,DeviceName,DeviceId,DeviceType,SourceType,DeviceHeight,MileMarker,Latitude,Longitude,Status,LastSeen,FirmwareVersion,CreatedDate,UpdatedDate)
           VALUES (@z,@hw,@s,@n,@d,@dt,@src,@ht,@mm,@lat,@lon,@st,@ls,@fw,@c,@u)",
         new { z=zid, hw, s=sid, n=name, d=did, dt=dtype, src=SrcType(dtype), ht, mm, lat, lon, st=status, ls, fw, c=Ts(15), u=Ts() });
}
Console.WriteLine($"  ✓ {sensors.Length} sensor devices");

// ══════════════════════════════════════════════════════════════
// 5. TRIANGULATION CONFIGS
// ══════════════════════════════════════════════════════════════
Console.WriteLine("Seeding TriangulationConfigs...");

var triConfigs = new[]
{
    // I20
    ("I20","I20-ZONE-001",500.0,"Switch A","SVR-I20-A1",32.7700,-96.7870, "Switch B","SVR-I20-A2",32.7460,-97.0020, "Switch C","SVR-I20-C1",32.7550,-97.5200, true),
    ("I20","I20-ZONE-003",400.0,"Switch A","SVR-I20-B1",32.7351,-97.2900, "Switch B","SVR-I20-B2",32.7548,-97.4320, "Switch C","SVR-I20-A1",32.7700,-96.7870, false),
    // I35
    ("I35","I35-ZONE-001",520.0,"Alpha","SVR-I35-A1",30.3870,-97.7100, "Bravo","SVR-I35-A2",30.5083,-97.6789, "Charlie","SVR-I35-B2",31.0977,-97.3428, true),
    ("I35","I35-ZONE-003",600.0,"Alpha","SVR-I35-B1",30.6325,-97.6773, "Bravo","SVR-I35-A1",30.3870,-97.7100, "Charlie","SVR-I35-A2",30.5083,-97.6789, false),
    // I10
    ("I10","I10-ZONE-001",500.0,"Node A","SVR-I10-A1",29.7604,-95.3698, "Node B","SVR-I10-A2",29.7858,-95.7240, "Node C","SVR-I10-B1",29.4241,-98.4936, true),
};
foreach (var (hw,zid,geo,s1l,s1id,s1lat,s1lon,s2l,s2id,s2lat,s2lon,s3l,s3id,s3lat,s3lon,active) in triConfigs)
{
    Exec(@"INSERT INTO TriangulationConfigs (ZoneId,HighwayId,GeofenceRadius,Switch1Label,Switch1ServerId,Switch1Lat,Switch1Lon,Switch2Label,Switch2ServerId,Switch2Lat,Switch2Lon,Switch3Label,Switch3ServerId,Switch3Lat,Switch3Lon,IsActive,CreatedDate,UpdatedDate)
           VALUES (@z,@hw,@g,@s1l,@s1id,@s1lat,@s1lon,@s2l,@s2id,@s2lat,@s2lon,@s3l,@s3id,@s3lat,@s3lon,@a,@c,@u)",
         new { z=zid, hw, g=geo, s1l, s1id, s1lat, s1lon, s2l, s2id, s2lat, s2lon, s3l, s3id, s3lat, s3lon, a=active?1:0, c=Ts(10), u=Ts() });
}
Console.WriteLine($"  ✓ {triConfigs.Length} triangulation configs");

// ══════════════════════════════════════════════════════════════
// 6. USER PROFILES — roles: admin, operator, viewer
// ══════════════════════════════════════════════════════════════
Console.WriteLine("Seeding UserProfiles...");

var users = new[]
{
    // I20
    ("I20","admin001","admin001","Sarah Mitchell","admin","CAM-I20-001,LDR-I20-001,RAD-I20-001","Camera Alpha 1,LiDAR Alpha 1,Radar Alpha 1","512-555-0101","100 Main St, Dallas TX","System administrator — full access",true,"admin"),
    ("I20","op001",  "op2024",  "James Rivera",  "operator","CAM-I20-001,CAM-I20-002","Camera Alpha 1,Camera Alpha 2","512-555-0102","200 Oak Ave, Dallas TX","Shift A operator",true,"password"),
    ("I20","op002",  "op2024",  "Linda Chen",    "operator","CAM-I20-003,LDR-I20-003","Camera Beta 1,LiDAR Beta 1","512-555-0103","300 Elm St, Dallas TX","Shift B operator",true,"password"),
    ("I20","view001","view2024","Carlos Nguyen", "viewer",  "","","512-555-0104","400 Pine Rd, Dallas TX","Read-only observer",true,""),
    ("I20","view002","",        "Priya Patel",   "viewer",  "","","512-555-0105","","Trainee — no password required",true,""),
    // I35
    ("I35","admin002","admin002","Michael Torres","admin","CAM-I35-001,LDR-I35-001","I35 Cam A1,I35 LiDAR A1","210-555-0201","100 Commerce St, Austin TX","I35 system administrator",true,"admin"),
    ("I35","op003",   "op2024",  "Angela Wright", "operator","CAM-I35-001,CAM-I35-002","I35 Cam A1,I35 Cam A2","210-555-0202","200 Congress Ave, Austin TX","I35 Day operator",true,"password"),
    ("I35","view003", "",        "David Kim",     "viewer",  "","","210-555-0203","","I35 Read-only",true,""),
    // I10
    ("I10","admin003","admin003","Rachel Green",  "admin","CAM-I10-001,LDR-I10-001","I10 Cam A1,I10 LiDAR A1","713-555-0301","100 Main St, Houston TX","I10 system administrator",true,"admin"),
    ("I10","op004",   "op2024",  "Thomas Brown",  "operator","CAM-I10-001,CAM-I10-003","I10 Cam A1,I10 Cam B1","713-555-0302","200 Houston Ave, Houston TX","I10 Operator",true,"password"),
    // Inactive user — tests IsActive=false path
    ("I20","old001",  "old2020", "Bob Testuser",  "viewer",  "","","","","DEACTIVATED — tests inactive filter",false,""),
};
foreach (var (hw,uid,pwd,name,utype,devIds,devNames,phone,addr,notes,active,pass) in users)
{
    Exec(@"INSERT INTO UserProfiles (UserId,Password,FullName,UserType,HighwayId,DeviceIdsRaw,DeviceNamesRaw,Phone,Address,Notes,IsActive,CreatedDate,UpdatedDate)
           VALUES (@uid,@pwd,@n,@ut,@hw,@di,@dn,@ph,@ad,@nt,@ac,@c,@u)",
         new { uid, pwd=pass, n=name, ut=utype, hw, di=devIds, dn=devNames, ph=phone, ad=addr, nt=notes, ac=active?1:0, c=Ts(30), u=Ts() });
}
Console.WriteLine($"  ✓ {users.Length} user profiles");

// ══════════════════════════════════════════════════════════════
// 7. DATA INPUT FORMAT CONFIGS — all 4 source types
// ══════════════════════════════════════════════════════════════
Console.WriteLine("Seeding InputFormatConfigs...");

var fmtCustom = JsonSerializer.Serialize(new[]
{
    new { name="lane_id",    type="string" },
    new { name="occupancy",  type="number" },
    new { name="confidence", type="number" }
});
var fmtCustomSat = JsonSerializer.Serialize(new[]
{
    new { name="satellite_count", type="number" },
    new { name="hdop",            type="number" }
});

var formats = new[]
{
    // Physical
    ("physical","Standard Camera Feed v2","SRC-CAM-001","https://cam.i20.mergesafe.local/feed","Full camera detection payload with speed and direction",
     "make,model,date,time,timestamp,latitude,longitude,speed,speed_mph,direction_degrees,firmware_version,status,vehicle_id,vehicle_type,traffic_density_percent,average_speed_mph",
     fmtCustom),
    ("physical","LiDAR Point Cloud v1","SRC-LDR-001","https://lidar.i20.mergesafe.local/stream","3D point cloud payload with occupancy data",
     "timestamp,latitude,longitude,speed,direction_degrees,status,vehicle_type,firmware_version",
     fmtCustom),
    ("physical","Radar Doppler v1","SRC-RAD-001","https://radar.i20.mergesafe.local/feed","Radar speed detection payload",
     "timestamp,latitude,longitude,speed,speed_mph,direction_degrees,vehicle_id,vehicle_type,status",
     ""),
    // Satellite
    ("satellite","Standard Satellite Feed v1","SRC-SAT-001","https://api.satnav.provider.com/v2/feed","GPS satellite telemetry payload",
     "timestamp,date,time,coordinates,latitude,longitude,speed,speed_mph,direction_degrees,signal_strength_dbm,firmware_version,status,vehicle_id,vehicle_type",
     fmtCustomSat),
    ("satellite","High-Accuracy GNSS v2","SRC-SAT-002","https://api.gnss.provider.com/hd","Sub-meter GNSS accuracy feed",
     "timestamp,latitude,longitude,speed,speed_mph,direction_degrees,signal_strength_dbm,vehicle_id,vehicle_type",
     fmtCustomSat),
    // Telecom
    ("telecom","Cellular Tag Reader v1","SRC-TEL-001","https://api.telecom.provider.com/tags","Vehicle tag read via cellular network",
     "timestamp,tag_id,vehicle_id,speed,speed_mph,latitude,longitude,signal_strength_dbm,status",
     ""),
    ("telecom","DSRC Roadside Unit v1","SRC-TEL-002","https://dsrc.i35.mergesafe.local/stream","Dedicated Short Range Communication payload",
     "timestamp,vehicle_id,vehicle_type,speed,speed_mph,direction_degrees,tag_id,latitude,longitude",
     ""),
    // Tracker
    ("tracker","OBD-II Fleet Tracker v1","SRC-TRK-001","https://tracker.fleet.api.com/v1","OBD-II CAN bus vehicle tracker payload",
     "make,model,timestamp,date,time,latitude,longitude,speed,speed_mph,direction_degrees,vehicle_id,vehicle_type,firmware_version,status",
     ""),
    ("tracker","Mobile ALPR Scanner v1","SRC-TRK-002","","Automated License Plate Reader mobile unit",
     "timestamp,vehicle_id,vehicle_type,speed_mph,latitude,longitude,direction_degrees,status",
     ""),
};
var fmtIds = new List<long>();
foreach (var (stype,fname,sid,src,desc,fields,custom) in formats)
{
    Exec(@"INSERT INTO InputFormatConfigs (SourceType,FormatName,SourceId,InputSource,Description,EnabledFieldsRaw,CustomFieldsJson,CreatedDate,UpdatedDate)
           VALUES (@st,@fn,@sid,@src,@desc,@fields,@custom,@c,@u)",
         new { st=stype, fn=fname, sid, src, desc, fields, custom=string.IsNullOrEmpty(custom)?(object)DBNull.Value:(object)custom, c=Ts(20), u=Ts() });
    fmtIds.Add(LastId());
}
Console.WriteLine($"  ✓ {formats.Length} input format configs");

// ══════════════════════════════════════════════════════════════
// 8. SAMPLE PAYLOADS — generated for key format configs
// ══════════════════════════════════════════════════════════════
Console.WriteLine("Seeding SamplePayloads...");

var rng = new Random(42);
string RandVeh() => $"VEH-{rng.Next(10000,99999)}";
string RandTag() => $"TAG-{rng.Next(10000,99999)}";
double RandLat() => Math.Round(32.7767 + (rng.NextDouble()-0.5)*0.2, 6);
double RandLon() => Math.Round(-96.797 + (rng.NextDouble()-0.5)*0.2, 6);

// Camera payload
var camPayload = new {
    source_type="physical", generated_at=Ts(),
    data=new { source_id="SRC-CAM-001", make="Toyota", model="Camry", timestamp=Ts(),
                latitude=RandLat(), longitude=RandLon(), speed=72, speed_mph=72,
                direction_degrees=270, vehicle_id=RandVeh(), vehicle_type="sedan",
                traffic_density_percent=45, average_speed_mph=67, firmware_version="2.3.1", status="active",
                lane_id="lane_2", occupancy=0.72, confidence=96 }
};
// Satellite payload
var satPayload = new {
    source_type="satellite", generated_at=Ts(),
    data=new { source_id="SRC-SAT-001", timestamp=Ts(), date=DateTime.UtcNow.ToString("yyyy-MM-dd"),
                time=DateTime.UtcNow.ToString("HH:mm:ss"), coordinates=$"{RandLat()},{RandLon()}",
                latitude=RandLat(), longitude=RandLon(), speed=65, speed_mph=65,
                direction_degrees=180, signal_strength_dbm=-52, vehicle_id=RandVeh(),
                vehicle_type="suv", status="active", firmware_version="1.2.3", satellite_count=12, hdop=0.8 }
};
// Telecom payload
var telPayload = new {
    source_type="telecom", generated_at=Ts(),
    data=new { source_id="SRC-TEL-001", timestamp=Ts(), tag_id=RandTag(),
                vehicle_id=RandVeh(), speed=58, speed_mph=58,
                latitude=RandLat(), longitude=RandLon(), signal_strength_dbm=-68, status="active" }
};
// Tracker payload
var trkPayload = new {
    source_type="tracker", generated_at=Ts(),
    data=new { source_id="SRC-TRK-001", make="Ford", model="F-150", timestamp=Ts(),
                date=DateTime.UtcNow.ToString("yyyy-MM-dd"), time=DateTime.UtcNow.ToString("HH:mm:ss"),
                latitude=RandLat(), longitude=RandLon(), speed=62, speed_mph=62,
                direction_degrees=90, vehicle_id=RandVeh(), vehicle_type="truck",
                firmware_version="3.0.1", status="active" }
};

var payloads = new[]
{
    (fmtIds[0], "physical", "Camera Feed — Standard Sedan Detection",   JsonSerializer.Serialize(camPayload, new JsonSerializerOptions{WriteIndented=true}), true),
    (fmtIds[0], "physical", "Camera Feed — Truck High Speed Alert",     JsonSerializer.Serialize(new { source_type="physical", data=new { source_id="SRC-CAM-001", vehicle_type="truck", speed_mph=89, status="alert", timestamp=Ts(), latitude=RandLat(), longitude=RandLon(), traffic_density_percent=78 } }, new JsonSerializerOptions{WriteIndented=true}), true),
    (fmtIds[3], "satellite","Satellite GNSS — Normal Pass",             JsonSerializer.Serialize(satPayload, new JsonSerializerOptions{WriteIndented=true}), true),
    (fmtIds[5], "telecom",  "Cellular Tag — Vehicle Detected",          JsonSerializer.Serialize(telPayload, new JsonSerializerOptions{WriteIndented=true}), true),
    (fmtIds[7], "tracker",  "OBD-II Tracker — Fleet Vehicle",          JsonSerializer.Serialize(trkPayload, new JsonSerializerOptions{WriteIndented=true}), true),
    (fmtIds[1], "physical", "LiDAR — INVALID malformed payload",       "{\"source_type\":\"physical\",\"data\":\"CORRUPTED\",\"err\":true}", false),
};
foreach (var (fid,stype,label,payload,valid) in payloads)
{
    Exec(@"INSERT INTO SamplePayloads (SourceType,FormatConfigId,FormatName,Payload,IsValid,Label,CreatedDate,UpdatedDate)
           VALUES (@st,@fid,@fn,@pl,@v,@lb,@c,@u)",
         new { st=stype, fid, fn=formats[(int)(fid - fmtIds[0])].Item2, pl=payload, v=valid?1:0, lb=label, c=Ts(5), u=Ts() });
}
Console.WriteLine($"  ✓ {payloads.Length} sample payloads");

// ══════════════════════════════════════════════════════════════
// 9. VEHICLE EVENTS — rich historical + recent + edge cases
// ══════════════════════════════════════════════════════════════
Console.WriteLine("Seeding VehicleEvents...");

var eventTypes = new[] { "detection","detection","detection","merge","conflict","fault","speeding","detection" };
var zoneList   = new[] {
    ("I20","I20-ZONE-001","SVR-I20-A1","CAM-I20-001"),
    ("I20","I20-ZONE-002","SVR-I20-A2","CAM-I20-002"),
    ("I20","I20-ZONE-003","SVR-I20-B1","CAM-I20-003"),
    ("I20","I20-ZONE-005","SVR-I20-C1","CAM-I20-005"),
    ("I35","I35-ZONE-001","SVR-I35-A1","CAM-I35-001"),
    ("I35","I35-ZONE-002","SVR-I35-A2","CAM-I35-002"),
    ("I35","I35-ZONE-003","SVR-I35-B1","CAM-I35-003"),
    ("I10","I10-ZONE-001","SVR-I10-A1","CAM-I10-001"),
    ("I10","I10-ZONE-003","SVR-I10-B1","CAM-I10-003"),
};
var vTypes = new[] {"sedan","truck","suv","motorcycle","van"};

int evCount = 0;
// 150 historical events spread over 30 days
for (int i = 0; i < 150; i++)
{
    var z  = zoneList[rng.Next(zoneList.Length)];
    var et = eventTypes[rng.Next(eventTypes.Length)];
    var vt = vTypes[rng.Next(vTypes.Length)];
    var spd = et == "speeding" ? rng.Next(85,110) : et == "fault" ? 0 : rng.Next(25,80);
    var conf = et == "fault" ? rng.Next(40,70) : rng.Next(80,100);
    var ts = now.AddDays(-rng.Next(0,30)).AddHours(-rng.Next(0,23)).AddMinutes(-rng.Next(0,59));
    Exec(@"INSERT INTO VehicleEvents (ZoneId,HighwayId,ServerId,DeviceId,EventType,VehicleId,SpeedMph,Latitude,Longitude,Confidence,Timestamp,RawData,CreatedDate,UpdatedDate)
           VALUES (@z,@hw,@sv,@dv,@et,@vid,@sp,@lat,@lon,@cf,@ts,@rd,@cd,@ud)",
         new { z=z.Item2, hw=z.Item1, sv=z.Item3, dv=z.Item4, et, vid=RandVeh(),
               sp=(double)spd, lat=RandLat(), lon=RandLon(), cf=(double)conf,
               ts=ts.ToString("o"), rd=$"{{\"vehicle_type\":\"{vt}\",\"source\":\"seed\"}}", cd=ts.ToString("o"), ud=ts.ToString("o") });
    evCount++;
}

// Recent burst — last 2 hours (for live dashboard feel)
var recentScenarios = new[]
{
    ("I20","I20-ZONE-001","SVR-I20-A1","CAM-I20-001","detection", "VEH-55201","sedan",   72.1, 0,2),
    ("I20","I20-ZONE-001","SVR-I20-A1","LDR-I20-001","detection", "VEH-55202","suv",     68.4, 0,2),
    ("I20","I20-ZONE-003","SVR-I20-B1","CAM-I20-003","fault",     "VEH-55203","truck",    0.0, 0,1),
    ("I20","I20-ZONE-003","SVR-I20-B1","RAD-I20-002","conflict",  "VEH-55204","sedan",   88.9, 0,1),
    ("I35","I35-ZONE-001","SVR-I35-A1","CAM-I35-001","detection", "VEH-55205","van",      60.2, 0,0),
    ("I35","I35-ZONE-002","SVR-I35-A2","CAM-I35-002","merge",     "VEH-55206","sedan",   55.5, 0,0),
    ("I35","I35-ZONE-003","SVR-I35-B1","CAM-I35-003","fault",     "VEH-55207","truck",    0.0, 0,0),
    ("I10","I10-ZONE-001","SVR-I10-A1","CAM-I10-001","detection", "VEH-55208","suv",      70.8, 0,0),
    ("I10","I10-ZONE-001","SVR-I10-A1","RAD-I10-001","speeding",  "VEH-55209","motorcycle",97.3,0,0),
    ("I20","I20-ZONE-002","SVR-I20-A2","CAM-I20-002","detection", "VEH-55210","sedan",   63.0, 0,0),
    ("I20","I20-ZONE-005","SVR-I20-C1","CAM-I20-005","merge",     "VEH-55211","truck",   48.2, 0,0),
    // Edge cases
    ("I20","I20-ZONE-001","SVR-I20-A1","CAM-I20-001","detection", "VEH-00001","sedan",    0.0, 0,0), // zero speed (stopped)
    ("I35","I35-ZONE-001","SVR-I35-A1","CAM-I35-001","conflict",  "VEH-99999","truck",   110.5,0,0), // extreme speed
    ("I10","I10-ZONE-003","SVR-I10-B1","CAM-I10-003","fault",     "VEH-11111","van",      0.0, 0,0), // fault with no speed
};
foreach (var (hw,zid,sid,did,et,vid,vt,spd,daysAgo,hrsAgo) in recentScenarios)
{
    var ts = now.AddDays(-daysAgo).AddHours(-hrsAgo).AddMinutes(-rng.Next(0,30));
    var conf = et == "fault" ? rng.Next(40,60) : et == "conflict" ? rng.Next(65,80) : rng.Next(88,99);
    Exec(@"INSERT INTO VehicleEvents (ZoneId,HighwayId,ServerId,DeviceId,EventType,VehicleId,SpeedMph,Latitude,Longitude,Confidence,Timestamp,RawData,CreatedDate,UpdatedDate)
           VALUES (@z,@hw,@sv,@dv,@et,@vid,@sp,@lat,@lon,@cf,@ts,@rd,@cd,@ud)",
         new { z=zid, hw, sv=sid, dv=did, et, vid, sp=spd, lat=RandLat(), lon=RandLon(), cf=(double)conf,
               ts=ts.ToString("o"), rd=$"{{\"vehicle_type\":\"{vt}\",\"scenario\":\"recent_seed\"}}", cd=ts.ToString("o"), ud=ts.ToString("o") });
    evCount++;
}
Console.WriteLine($"  ✓ {evCount} vehicle events");

// ══════════════════════════════════════════════════════════════
// DONE
// ══════════════════════════════════════════════════════════════
conn.Close();
Console.WriteLine("\n════════════════════════════════════════");
Console.WriteLine("✅  Seed complete! Summary:");
Console.WriteLine($"   Highways            : 4 (3 active, 1 inactive)");
Console.WriteLine($"   Merge Zones         : {zonesI20.Length + zonesI35.Length + zonesI10.Length} across I20/I35/I10");
Console.WriteLine($"   Switch Servers      : {servers.Length} (online/offline/fault/maintenance/degraded)");
Console.WriteLine($"   Sensor Devices      : {sensors.Length} (camera/lidar/radar/satellite/telecom)");
Console.WriteLine($"   Triangulation Cfgs  : {triConfigs.Length}");
Console.WriteLine($"   User Profiles       : {users.Length} (admin/operator/viewer/inactive)");
Console.WriteLine($"   Input Format Cfgs   : {formats.Length} (physical/satellite/telecom/tracker)");
Console.WriteLine($"   Sample Payloads     : {payloads.Length} (valid + invalid)");
Console.WriteLine($"   Vehicle Events      : {evCount} (30-day history + recent burst)");
Console.WriteLine("════════════════════════════════════════\n");
Console.WriteLine("Login credentials:");
Console.WriteLine("  I20 admin   → User ID: admin001  Password: admin");
Console.WriteLine("  I20 operator→ User ID: op001     Password: password");
Console.WriteLine("  I35 admin   → User ID: admin002  Password: admin");
Console.WriteLine("  I10 admin   → User ID: admin003  Password: admin");
Console.WriteLine("  Any viewer  → Password: (blank) or 'view2024'");
