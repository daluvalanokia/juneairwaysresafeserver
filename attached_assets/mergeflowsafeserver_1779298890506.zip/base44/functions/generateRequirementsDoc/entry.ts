import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';
import { jsPDF } from 'npm:jspdf@4.0.0';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    const doc = new jsPDF({ orientation: 'portrait', unit: 'mm', format: 'a4' });
    const W = 210;
    const margin = 18;
    const contentW = W - margin * 2;
    let y = 0;

    // ── helpers ──────────────────────────────────────────────────────────────

    const checkPage = (needed = 10) => {
      if (y + needed > 275) {
        doc.addPage();
        y = 20;
      }
    };

    const hr = (color = [220, 220, 220]) => {
      doc.setDrawColor(...color);
      doc.setLineWidth(0.3);
      doc.line(margin, y, W - margin, y);
      y += 4;
    };

    const text = (str, x, size = 9, color = [50, 50, 50], style = 'normal') => {
      doc.setFontSize(size);
      doc.setTextColor(...color);
      doc.setFont('helvetica', style);
      doc.text(str, x, y);
    };

    const wrappedText = (str, x, maxW, size = 9, color = [80, 80, 80]) => {
      doc.setFontSize(size);
      doc.setTextColor(...color);
      doc.setFont('helvetica', 'normal');
      const lines = doc.splitTextToSize(str, maxW);
      doc.text(lines, x, y);
      y += lines.length * (size * 0.45) + 2;
    };

    const sectionHeader = (title, level = 1) => {
      checkPage(14);
      if (level === 1) {
        y += 4;
        doc.setFillColor(15, 23, 42);
        doc.roundedRect(margin, y - 5, contentW, 10, 2, 2, 'F');
        doc.setFontSize(11);
        doc.setTextColor(255, 255, 255);
        doc.setFont('helvetica', 'bold');
        doc.text(title, margin + 4, y + 1.5);
        y += 10;
      } else if (level === 2) {
        y += 3;
        doc.setFillColor(241, 245, 249);
        doc.roundedRect(margin, y - 4, contentW, 8, 1, 1, 'F');
        doc.setFontSize(9.5);
        doc.setTextColor(30, 58, 138);
        doc.setFont('helvetica', 'bold');
        doc.text(title, margin + 3, y + 0.5);
        y += 8;
      } else {
        y += 2;
        doc.setFontSize(9);
        doc.setTextColor(71, 85, 105);
        doc.setFont('helvetica', 'bold');
        doc.text('▸  ' + title, margin + 2, y);
        y += 6;
      }
    };

    const tableRow = (cols, widths, isHeader = false) => {
      checkPage(8);
      const rowH = 7;
      const bg = isHeader ? [30, 41, 59] : [248, 250, 252];
      doc.setFillColor(...bg);
      doc.rect(margin, y - 5, contentW, rowH, 'F');
      doc.setDrawColor(200, 210, 220);
      doc.setLineWidth(0.1);
      doc.rect(margin, y - 5, contentW, rowH, 'S');

      let cx = margin + 2;
      cols.forEach((col, i) => {
        doc.setFontSize(isHeader ? 7.5 : 8);
        doc.setFont('helvetica', isHeader ? 'bold' : 'normal');
        doc.setTextColor(...(isHeader ? [255, 255, 255] : [50, 60, 70]));
        const cellW = widths[i] - 3;
        const lines = doc.splitTextToSize(String(col), cellW);
        doc.text(lines[0], cx, y);
        cx += widths[i];
      });
      y += rowH;
    };

    const bullet = (str, indent = 0) => {
      checkPage(6);
      doc.setFontSize(8.5);
      doc.setFont('helvetica', 'normal');
      doc.setTextColor(60, 70, 80);
      const prefix = '•  ';
      const lines = doc.splitTextToSize(str, contentW - 8 - indent);
      doc.text(prefix, margin + 4 + indent, y);
      doc.text(lines, margin + 9 + indent, y);
      y += lines.length * 4.5 + 1;
    };

    const seqStep = (actor, arrow, target, desc) => {
      checkPage(7);
      doc.setFontSize(8);
      doc.setFont('helvetica', 'bold');
      doc.setTextColor(30, 64, 175);
      doc.text(actor, margin + 2, y);
      doc.setFont('helvetica', 'normal');
      doc.setTextColor(100, 116, 139);
      doc.text(arrow, margin + 38, y);
      doc.setFont('helvetica', 'bold');
      doc.setTextColor(21, 128, 61);
      doc.text(target, margin + 52, y);
      doc.setFont('helvetica', 'normal');
      doc.setTextColor(71, 85, 105);
      const lines = doc.splitTextToSize(desc, contentW - 80);
      doc.text(lines, margin + 90, y);
      y += Math.max(lines.length * 4, 5) + 1;
    };

    // ══════════════════════════════════════════════════════════════════════════
    // COVER PAGE
    // ══════════════════════════════════════════════════════════════════════════

    doc.setFillColor(15, 23, 42);
    doc.rect(0, 0, W, 297, 'F');

    // Accent stripe
    doc.setFillColor(37, 99, 235);
    doc.rect(0, 100, W, 3, 'F');
    doc.rect(0, 104, W, 1, 'F');

    doc.setFontSize(28);
    doc.setFont('helvetica', 'bold');
    doc.setTextColor(255, 255, 255);
    doc.text('MergeSafeServer', W / 2, 60, { align: 'center' });

    doc.setFontSize(14);
    doc.setFont('helvetica', 'normal');
    doc.setTextColor(148, 163, 184);
    doc.text('Control Platform', W / 2, 70, { align: 'center' });

    doc.setFontSize(18);
    doc.setFont('helvetica', 'bold');
    doc.setTextColor(96, 165, 250);
    doc.text('Software Requirements Document', W / 2, 115, { align: 'center' });

    doc.setFontSize(9);
    doc.setFont('helvetica', 'normal');
    doc.setTextColor(100, 116, 139);
    doc.text('Comprehensive Design Reference — UI, Database, Modules & Interactions', W / 2, 125, { align: 'center' });

    const meta = [
      ['Document Version:', '1.0'],
      ['Classification:', 'Internal — Technical Design'],
      ['Platform:', 'React + Base44 BaaS'],
      ['Generated:', new Date().toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' })],
    ];
    let my = 155;
    meta.forEach(([label, val]) => {
      doc.setFontSize(8.5);
      doc.setFont('helvetica', 'bold');
      doc.setTextColor(148, 163, 184);
      doc.text(label, 50, my);
      doc.setFont('helvetica', 'normal');
      doc.setTextColor(255, 255, 255);
      doc.text(val, 105, my);
      my += 8;
    });

    // ══════════════════════════════════════════════════════════════════════════
    // TABLE OF CONTENTS
    // ══════════════════════════════════════════════════════════════════════════

    doc.addPage();
    y = 22;

    doc.setFillColor(15, 23, 42);
    doc.rect(0, 0, W, 14, 'F');
    doc.setFontSize(10);
    doc.setFont('helvetica', 'bold');
    doc.setTextColor(255, 255, 255);
    doc.text('TABLE OF CONTENTS', margin, 10);

    y = 28;
    const toc = [
      ['1.', 'System Overview & Architecture', '3'],
      ['2.', 'Application Layout & Navigation', '4'],
      ['3.', 'Module: Dashboard (System Overview)', '5'],
      ['4.', 'Module: Highways / Settings', '6'],
      ['5.', 'Module: Merge Zones', '7'],
      ['6.', 'Module: Switch Servers', '8'],
      ['7.', 'Module: Sensor Devices', '9'],
      ['8.', 'Module: Triangulation Configuration', '10'],
      ['9.', 'Module: Vehicle Events', '11'],
      ['10.', 'Module: 3D Traffic Visualization', '12'],
      ['11.', 'Module: Data Input Formats', '13'],
      ['12.', 'Module: Users & Access Control', '16'],
      ['13.', 'Module: Portal / Operator Login', '17'],
      ['14.', 'Database Schema — All Entities', '18'],
      ['15.', 'Backend Functions', '22'],
      ['16.', 'Sequence Diagrams', '23'],
      ['17.', 'UI Design System', '26'],
      ['18.', 'Security & Access Control', '27'],
    ];

    toc.forEach(([num, title, pg]) => {
      checkPage(7);
      doc.setFontSize(9);
      doc.setFont('helvetica', 'bold');
      doc.setTextColor(30, 58, 138);
      doc.text(num, margin + 2, y);
      doc.setFont('helvetica', 'normal');
      doc.setTextColor(50, 60, 70);
      doc.text(title, margin + 12, y);
      doc.setTextColor(148, 163, 184);
      doc.text(pg, W - margin - 5, y, { align: 'right' });
      // dotted line
      doc.setDrawColor(210, 218, 228);
      doc.setLineWidth(0.2);
      const titleW = doc.getTextWidth(title);
      doc.setLineDashPattern([0.5, 1.5], 0);
      doc.line(margin + 12 + titleW + 3, y - 1, W - margin - 10, y - 1);
      doc.setLineDashPattern([], 0);
      y += 7;
    });

    // ══════════════════════════════════════════════════════════════════════════
    // 1. SYSTEM OVERVIEW
    // ══════════════════════════════════════════════════════════════════════════

    doc.addPage();
    y = 20;
    sectionHeader('1. SYSTEM OVERVIEW & ARCHITECTURE', 1);
    y += 2;
    wrappedText(
      'MergeSafeServer is a web-based autonomous merge zone control platform for interstate highway management. It provides real-time monitoring, configuration, and telemetry analysis for sensor networks, switch servers, and vehicle detection systems deployed along highway corridors.',
      margin, contentW
    );
    y += 2;

    sectionHeader('1.1  Technology Stack', 2);
    const stackRows = [
      ['Layer', 'Technology', 'Purpose'],
      ['Frontend', 'React 18 + Vite', 'Single-page application, component-based UI'],
      ['Styling', 'Tailwind CSS + shadcn/ui', 'Design tokens, utility classes, accessible components'],
      ['State', '@tanstack/react-query', 'Server state caching and mutations'],
      ['Routing', 'react-router-dom v6', 'Client-side routing with nested layouts'],
      ['Maps', 'react-leaflet', 'Interactive geospatial highway & zone visualisation'],
      ['3D', 'three.js', '3D traffic scene rendering'],
      ['Backend/DB', 'Base44 BaaS', 'Managed database, auth, serverless functions'],
      ['Functions', 'Deno Deploy', 'Edge serverless functions (TypeScript/JS)'],
      ['External API', 'TomTom Traffic API', 'Real-time traffic flow data for 3D view'],
    ];
    const sw = [40, 55, contentW - 95];
    stackRows.forEach((r, i) => tableRow(r, sw, i === 0));

    y += 4;
    sectionHeader('1.2  High-Level Architecture', 2);
    bullet('Browser → React SPA (pages + components) → Base44 SDK → Base44 BaaS (entities / auth / integrations)');
    bullet('Browser → React SPA → Deno Edge Functions → External APIs (TomTom)');
    bullet('All entity operations use Base44 SDK methods: list(), filter(), create(), update(), delete()');
    bullet('Authentication is managed entirely by Base44 platform; no custom auth backend');
    bullet('Highway-scoped data filtering: a global HighwaySelector persists the selected highway_id throughout all modules');

    y += 4;
    sectionHeader('1.3  Route Map', 2);
    const routes = [
      ['Path', 'Component', 'Description'],
      ['/', 'Dashboard', 'System overview, stats, map, event feed'],
      ['/zones', 'MergeZones', 'Merge zone CRUD and status'],
      ['/servers', 'SwitchServers', 'Switch server CRUD and health metrics'],
      ['/sensors', 'Sensors', 'Sensor device CRUD and barcode scan'],
      ['/triangulation', 'Triangulation', '3-switch GPS triangulation config'],
      ['/events', 'Events', 'Vehicle event log with filtering'],
      ['/traffic3d', 'Traffic3D', '2D map + 3D immersive traffic view'],
      ['/users', 'Users', 'User profile and device assignment management'],
      ['/input-formats', 'DataInputFormats', 'API payload schema configuration'],
      ['/settings', 'Settings', 'Highway configuration + API keys'],
      ['/portal', 'Portal', 'Operator login portal'],
    ];
    const rw = [30, 40, contentW - 70];
    routes.forEach((r, i) => tableRow(r, rw, i === 0));

    // ══════════════════════════════════════════════════════════════════════════
    // 2. LAYOUT & NAVIGATION
    // ══════════════════════════════════════════════════════════════════════════

    doc.addPage();
    y = 20;
    sectionHeader('2. APPLICATION LAYOUT & NAVIGATION', 1);

    sectionHeader('2.1  AppLayout Component', 2);
    wrappedText('The persistent shell wraps all authenticated routes except /portal. It is composed of a collapsible sidebar and a fixed top header bar.', margin, contentW);
    y += 2;

    sectionHeader('Sidebar', 3);
    bullet('Width: 224 px expanded / 64 px collapsed (transition-all duration-300)');
    bullet('Brand logo: circular icon with primary glow + "MergeSafeServer" wordmark');
    bullet('Navigation items rendered from NAV_ITEMS constant (11 routes)');
    bullet('Active state: bg-primary/15 + border-primary/25 + glow-primary class');
    bullet('Collapse toggle button at bottom: ChevronLeft / ChevronRight icon');

    sectionHeader('Top Header Bar', 3);
    bullet('System Live indicator: pulsing green dot + "SYSTEM LIVE" monospace label');
    bullet('HighwaySelector: dropdown to choose the active highway; propagated via props to all pages');
    bullet('Backdrop blur: bg-card/50 backdrop-blur-sm');

    sectionHeader('2.2  HighwaySelector Component', 2);
    bullet('Fetches Highway entity list on mount via base44.entities.Highway.list()');
    bullet('Renders shadcn/ui Select with highway name + optional icon');
    bullet('Calls onHighwayChange(highway_id) callback to update global state in AuthenticatedApp');
    bullet('Global state held in useState in App.jsx, passed as prop to AppLayout and each page');

    sectionHeader('2.3  PageHeader Component', 2);
    bullet('Props: title (string), subtitle (string, optional), children (action buttons)');
    bullet('Layout: flex row, title/subtitle left, children right');
    bullet('Used uniformly across all module pages');

    // ══════════════════════════════════════════════════════════════════════════
    // 3. DASHBOARD
    // ══════════════════════════════════════════════════════════════════════════

    doc.addPage();
    y = 20;
    sectionHeader('3. MODULE: DASHBOARD (SYSTEM OVERVIEW)', 1);

    sectionHeader('3.1  Purpose', 2);
    wrappedText('Provides an at-a-glance overview of the entire highway system. Displays key statistics, a geospatial map, and a live event feed. Supports a Demo Mode for simulating traffic without live data.', margin, contentW);

    sectionHeader('3.2  UI Fields & Controls', 2);
    const dashFields = [
      ['Element', 'Type', 'Description'],
      ['Demo / Exit Demo button', 'Toggle Button', 'Activates DemoMap with simulated vehicle events (Zap icon)'],
      ['Merge Zones stat card', 'StatCard', 'Total zones count; red accent if any in fault'],
      ['Switch Servers stat card', 'StatCard', 'online/total ratio; warning if not all online'],
      ['Sensor Devices stat card', 'StatCard', 'online/total ratio'],
      ['Recent Alerts stat card', 'StatCard', 'Count of fault/conflict events in last 20'],
      ['Map panel', 'LeafletMap / Three.js', 'HighwayMap (live) or DemoMap (simulation)'],
      ['Map legend', 'Static badges', 'Zone Active/Fault, Camera/LiDAR/Radar color coding'],
      ['Merge Zones list', 'Card list', 'Links to /zones; shows zone_name, zone_id, mile_marker, StatusBadge'],
      ['Recent Events / Demo Feed', 'Scrollable list', 'Last 20 VehicleEvent records; colour-coded by event_type'],
    ];
    const df = [45, 35, contentW - 80];
    dashFields.forEach((r, i) => tableRow(r, df, i === 0));

    sectionHeader('3.3  Data Fetching', 2);
    bullet('Parallel Promise.all: MergeZone, SwitchServer, SensorDevice, VehicleEvent (last 20) filtered by selectedHighway');
    bullet('Demo mode: simulated vehicles generated in DemoMap component; events stored in local demoEvents state (max 30)');

    // ══════════════════════════════════════════════════════════════════════════
    // 4. SETTINGS / HIGHWAYS
    // ══════════════════════════════════════════════════════════════════════════

    doc.addPage();
    y = 20;
    sectionHeader('4. MODULE: SETTINGS / HIGHWAYS', 1);

    sectionHeader('4.1  Purpose', 2);
    wrappedText('Manages the set of interstate highways in the system and stores external API keys. Highways are the root scope for all other entities.', margin, contentW);

    sectionHeader('4.2  UI Fields', 2);
    const settFields = [
      ['Field', 'Input Type', 'Validation', 'Notes'],
      ['Highway Name', 'Text input', 'Required', 'Human-readable name e.g. Interstate 20'],
      ['Highway ID', 'Text input', 'Required', 'Unique key used as FK in all child entities'],
      ['State / Region', 'Text input', 'Optional', 'State abbreviation or name'],
      ['Description', 'Text input', 'Optional', 'Free-form description'],
      ['TomTom API Key', 'Password input', 'Optional', 'Saved via saveTomTomKey backend function; show/hide toggle'],
    ];
    const sf = [35, 28, 25, contentW - 88];
    settFields.forEach((r, i) => tableRow(r, sf, i === 0));

    sectionHeader('4.3  Actions', 2);
    bullet('Add Highway → opens Dialog modal with form fields → base44.entities.Highway.create()');
    bullet('Edit Highway → pre-populates form → base44.entities.Highway.update(id, data)');
    bullet('Delete Highway → base44.entities.Highway.delete(id)');
    bullet('Save TomTom API Key → calls saveTomTomKey backend function with { apiKey }');

    // ══════════════════════════════════════════════════════════════════════════
    // 5. MERGE ZONES
    // ══════════════════════════════════════════════════════════════════════════

    doc.addPage();
    y = 20;
    sectionHeader('5. MODULE: MERGE ZONES', 1);

    sectionHeader('5.1  Purpose', 2);
    wrappedText('Defines the physical merge zone areas along a highway. A Merge Zone is the root spatial scope for Switch Servers and Sensor Devices. Zones have GPS coordinates and geofence parameters.', margin, contentW);

    sectionHeader('5.2  Card Display Fields', 2);
    bullet('zone_name — primary title (bold)');
    bullet('zone_id — monospace secondary label');
    bullet('StatusBadge — coloured badge (active/inactive/fault/maintenance)');
    bullet('mile_marker — displayed as "MM {value}"');
    bullet('geofence_radius — displayed in metres');
    bullet('latitude / longitude — monospace coordinate pair');
    bullet('highway_id — highway reference');

    sectionHeader('5.3  Form Fields (Create/Edit Dialog)', 2);
    const mzFields = [
      ['Field', 'Type', 'Required', 'Default'],
      ['Zone Name', 'Text', 'Yes', '—'],
      ['Zone ID', 'Text', 'Yes', '—'],
      ['Highway ID', 'Text', 'Yes', 'Pre-filled from selectedHighway'],
      ['Mile Marker', 'Number', 'No', '—'],
      ['Latitude', 'Number', 'No', '—'],
      ['Longitude', 'Number', 'No', '—'],
      ['Geofence Radius (m)', 'Number', 'No', '500'],
      ['Status', 'Select dropdown', 'No', 'active'],
    ];
    const mzw = [40, 30, 25, contentW - 95];
    mzFields.forEach((r, i) => tableRow(r, mzw, i === 0));

    // ══════════════════════════════════════════════════════════════════════════
    // 6. SWITCH SERVERS
    // ══════════════════════════════════════════════════════════════════════════

    doc.addPage();
    y = 20;
    sectionHeader('6. MODULE: SWITCH SERVERS', 1);

    sectionHeader('6.1  Purpose', 2);
    wrappedText('Manages edge computing nodes (switch servers) that process sensor data and control merge decisions within each zone. Displays health metrics including CPU usage, memory, uptime and network address.', margin, contentW);

    sectionHeader('6.2  Card Display Fields', 2);
    bullet('server_name — title; server_id — monospace ID');
    bullet('StatusBadge — online / offline / degraded / fault');
    bullet('IP Address : Port — monospace');
    bullet('CPU / RAM — percentage display with animated progress bar');
    bullet('Uptime — formatted as "{h}h {m}m"');
    bullet('Firmware Version — displayed if present');

    sectionHeader('6.3  Form Fields', 2);
    const svFields = [
      ['Field', 'Input Type', 'Span', 'Notes'],
      ['Server Name', 'Text', 'Full width', 'Required'],
      ['Server ID', 'Text', 'Half', 'Unique identifier'],
      ['Zone ID', 'Text', 'Half', 'FK → MergeZone.zone_id'],
      ['Highway ID', 'Text', 'Half', 'FK → Highway.highway_id'],
      ['IP Address', 'Text', 'Full width', 'IPv4 address'],
      ['Port', 'Number', 'Half', 'Default 8080'],
      ['Firmware Version', 'Text', 'Half', 'Optional'],
      ['Status', 'Select', 'Half', 'online/offline/degraded/fault'],
    ];
    const svw = [38, 28, 22, contentW - 88];
    svFields.forEach((r, i) => tableRow(r, svw, i === 0));

    sectionHeader('6.4  Barcode Scanner Integration', 2);
    bullet('BarcodeScanner component activated via "Scan This Device" dashed button in the dialog');
    bullet('Scans JSON → merges all parsed fields into form state');
    bullet('Scans plain IP (4 dot-separated octets) → populates ip_address only');
    bullet('Scans other string → populates server_id');

    // ══════════════════════════════════════════════════════════════════════════
    // 7. SENSOR DEVICES
    // ══════════════════════════════════════════════════════════════════════════

    doc.addPage();
    y = 20;
    sectionHeader('7. MODULE: SENSOR DEVICES', 1);

    sectionHeader('7.1  Purpose', 2);
    wrappedText('Registers and monitors all physical sensor hardware installed along the highway. Supports cameras, LiDAR, radar, vehicle tag readers and signal receivers. Devices are scoped to a Zone and can optionally reference a Switch Server.', margin, contentW);

    sectionHeader('7.2  Device Types & Icons', 2);
    const dtypes = [
      ['Device Type', 'Icon', 'Color Theme'],
      ['camera', 'Camera icon', 'Blue'],
      ['lidar', 'Scan icon', 'Purple'],
      ['radar', 'Radio icon', 'Amber'],
      ['vehicle tag reader', 'Tag icon', 'Green'],
      ['signal receiver', 'Antenna icon', 'Slate'],
    ];
    const dtw = [40, 35, contentW - 75];
    dtypes.forEach((r, i) => tableRow(r, dtw, i === 0));

    sectionHeader('7.3  Form Fields', 2);
    const sdFields = [
      ['Field', 'Type', 'Notes'],
      ['Device Name', 'Text', 'Required'],
      ['Device ID', 'Text', 'Required, unique identifier'],
      ['Zone ID', 'Text', 'FK → MergeZone.zone_id'],
      ['Highway ID', 'Text', 'FK → Highway.highway_id'],
      ['Server ID', 'Text', 'Optional FK → SwitchServer.server_id'],
      ['Device Type', 'Select', 'camera/lidar/radar/vehicle tag reader/signal receiver'],
      ['Source Type', 'Select', 'physical/satellite/telecom/tracker'],
      ['Device Height (m)', 'Number', 'Installation height'],
      ['Mile Marker', 'Number', 'Position along interstate'],
      ['Location Comment', 'Text', 'Descriptive notes'],
      ['Latitude / Longitude', 'Number', 'GPS coordinates'],
      ['Status', 'Select', 'online/offline/fault/calibrating'],
      ['Firmware Version', 'Text', 'Optional'],
      ['Notes', 'Textarea', 'Free-form notes'],
    ];
    const sdw = [38, 25, contentW - 63];
    sdFields.forEach((r, i) => tableRow(r, sdw, i === 0));

    // ══════════════════════════════════════════════════════════════════════════
    // 8. TRIANGULATION
    // ══════════════════════════════════════════════════════════════════════════

    doc.addPage();
    y = 20;
    sectionHeader('8. MODULE: TRIANGULATION CONFIGURATION', 1);

    sectionHeader('8.1  Purpose', 2);
    wrappedText('Defines three-switch GPS triangulation setups per merge zone. Each configuration records the positions and server references of exactly three switch nodes used for vehicle position triangulation. Used by the Demo Map to show dashed signal-path lines.', margin, contentW);

    sectionHeader('8.2  Form Fields', 2);
    const triFields = [
      ['Field', 'Type', 'Notes'],
      ['Zone ID', 'Text', 'FK → MergeZone.zone_id'],
      ['Highway ID', 'Text', 'FK → Highway.highway_id'],
      ['Geofence Radius (m)', 'Number', 'Default 500'],
      ['Switch N Label', 'Text (×3)', 'Display label for each switch (A/B/C)'],
      ['Switch N Server ID', 'Text (×3)', 'FK → SwitchServer.server_id'],
      ['Switch N Latitude', 'Number (×3)', 'GPS lat of each switch node'],
      ['Switch N Longitude', 'Number (×3)', 'GPS lon of each switch node'],
      ['Is Active', 'Boolean', 'Default true'],
    ];
    const triw = [40, 28, contentW - 68];
    triFields.forEach((r, i) => tableRow(r, triw, i === 0));

    sectionHeader('8.3  SwitchPanel Sub-component', 2);
    bullet('Extracted as SwitchPanel({ num, form, setForm }) — renders fields for one switch node');
    bullet('Uses dynamic field prefix: switch{N}_ to access the right fields in the shared form state');
    bullet('Rendered three times (num=1,2,3) inside the dialog');

    // ══════════════════════════════════════════════════════════════════════════
    // 9. VEHICLE EVENTS
    // ══════════════════════════════════════════════════════════════════════════

    doc.addPage();
    y = 20;
    sectionHeader('9. MODULE: VEHICLE EVENTS', 1);

    sectionHeader('9.1  Purpose', 2);
    wrappedText('Displays a real-time log of sensor-detected vehicle events. Supports filtering by event type and manual refresh. Events are read-only and generated externally or by the Demo simulation.', margin, contentW);

    sectionHeader('9.2  Table Columns', 2);
    const evCols = [
      ['Column', 'Source Field', 'Format', 'Width'],
      ['Type', 'event_type', 'UPPERCASE + color + icon', '1/8'],
      ['Zone', 'zone_id', 'Monospace', '1/8'],
      ['Device', 'device_id', 'Monospace', '1/8'],
      ['Vehicle', 'vehicle_id', 'Monospace', '1/8'],
      ['Speed', 'speed_mph', '{n} mph', '1/8'],
      ['Coordinates', 'latitude, longitude', '5 decimal places', '2/8'],
      ['Time', 'created_date', 'HH:mm:ss (date-fns format)', '1/8'],
    ];
    const evw = [22, 28, 32, contentW - 82];
    evCols.forEach((r, i) => tableRow(r, evw, i === 0));

    sectionHeader('9.3  Filter & Controls', 2);
    bullet('Event type filter Select: all / detection / merge / conflict / speeding / fault');
    bullet('Refresh button: calls VehicleEvent.filter() again; RefreshCw icon animates during load');
    bullet('Max 100 records loaded, sorted by -created_date');

    sectionHeader('9.4  Event Type Color Coding', 2);
    const evColor = [
      ['Event Type', 'Color Class', 'Icon Component'],
      ['detection', 'text-primary (blue)', 'Car'],
      ['merge', 'text-accent (green)', 'Zap'],
      ['conflict', 'text-destructive (red)', 'AlertTriangle'],
      ['speeding', 'text-yellow-400', 'AlertTriangle'],
      ['fault', 'text-destructive (red)', 'AlertTriangle'],
    ];
    const ecw = [30, 40, contentW - 70];
    evColor.forEach((r, i) => tableRow(r, ecw, i === 0));

    // ══════════════════════════════════════════════════════════════════════════
    // 10. 3D TRAFFIC
    // ══════════════════════════════════════════════════════════════════════════

    doc.addPage();
    y = 20;
    sectionHeader('10. MODULE: 3D TRAFFIC VISUALIZATION', 1);

    sectionHeader('10.1  Purpose', 2);
    wrappedText('Provides a dual-mode traffic viewer: a 2D Leaflet map landing page with congestion overlays (MapLanding) and a fully immersive Three.js 3D scene (Scene3D) with animated vehicles. Uses TomTom Traffic API for real congestion data.', margin, contentW);

    sectionHeader('10.2  Components', 2);
    bullet('Traffic3D (page) — manages mode state (map vs 3D), data fetching, countdown timer (auto-refresh every 5 min)');
    bullet('MapLanding — Leaflet map with road polylines coloured by congestion level; device markers grouped by coordinates');
    bullet('Scene3D — Three.js scene with lane geometry, animated vehicle meshes, directional lighting');
    bullet('TrafficFeed — real-time text feed panel of segment events');
    bullet('TrafficControls — camera angle, speed multiplier, density sliders');
    bullet('TrafficCanvas2D — top-down 2D canvas fallback view');

    sectionHeader('10.3  External API Integration', 2);
    bullet('getTomTomTraffic backend function fetches /traffic/services/4/flowSegmentData from TomTom');
    bullet('Returns speed, freeFlowSpeed, currentTravelTime, freeFlowTravelTime, confidence per segment');
    bullet('If TOMTOM_API_KEY not set, function returns simulated demo data');
    bullet('Invoked from frontend: base44.functions.invoke("getTomTomTraffic", { highway_id })');

    // ══════════════════════════════════════════════════════════════════════════
    // 11. DATA INPUT FORMATS
    // ══════════════════════════════════════════════════════════════════════════

    doc.addPage();
    y = 20;
    sectionHeader('11. MODULE: DATA INPUT FORMATS', 1);

    sectionHeader('11.1  Purpose', 2);
    wrappedText('Allows operators to define and manage JSON payload schemas for each of the four data source types. Provides tools to generate synthetic sample payloads, validate them, save them to the database, and duplicate configurations across tabs.', margin, contentW);

    sectionHeader('11.2  Tab Structure', 2);
    bullet('Four tabs: Physical | Satellite | Telecom | Tracker');
    bullet('Each tab renders an independent FormatTab component with its own state');
    bullet('Source type colour coding: Physical=Blue, Satellite=Purple, Telecom=Green, Tracker=Orange');

    sectionHeader('11.3  Format Config Card Fields (Display)', 2);
    const ifDisplay = [
      ['Element', 'Source Field', 'Style'],
      ['Format Name', 'format_name', 'Bold 0.875rem'],
      ['Source ID', 'source_id', 'Monospace 0.625rem, muted'],
      ['Input Source', 'input_source', 'Monospace 0.625rem, blue-400, ⇒ prefix'],
      ['Description', 'description', '0.75rem muted'],
      ['Enabled Field Badges', 'enabled_fields[0..3]', 'Source-coloured monospace chips (max 4 + overflow count)'],
      ['Custom Field Count', 'custom_fields.length', '"{n} custom" chip'],
      ['Generate Payload btn', '—', 'Full-width outline sm button with Play icon'],
    ];
    const ifd = [38, 30, contentW - 68];
    ifDisplay.forEach((r, i) => tableRow(r, ifd, i === 0));

    sectionHeader('11.4  Create / Edit Dialog Fields', 2);
    const ifForm = [
      ['Field', 'Input', 'Required', 'Notes'],
      ['Format Name', 'Text', 'Yes', 'Placeholder: "Standard Satellite Feed v1"'],
      ['Source ID', 'Text (monospace)', 'No', 'Placeholder: "SRC-SAT-001"'],
      ['Description', 'Text', 'No', 'Free-form description'],
      ['Input Source', 'Text', 'No', 'Endpoint URL, stream name, or device tag'],
      ['Common Fields', 'Checkbox grid (2-col)', 'No', '20 predefined fields, scrollable max-h-48'],
      ['Custom Fields', 'Dynamic rows (name + type)', 'No', 'name=Text, type=Select (string/number/boolean/array/object)'],
    ];
    const iff = [32, 26, 20, contentW - 78];
    ifForm.forEach((r, i) => tableRow(r, iff, i === 0));

    y += 3;
    sectionHeader('11.5  20 Predefined Common Fields', 2);
    const cf = [
      'make', 'model', 'date', 'time', 'timestamp', 'coordinates',
      'latitude', 'longitude', 'speed', 'speed_mph', 'altitude_meters',
      'direction_degrees', 'firmware_version', 'status', 'vehicle_id',
      'tag_id', 'signal_strength_dbm', 'vehicle_type',
      'traffic_density_percent', 'average_speed_mph'
    ];
    bullet(cf.join('  ·  '));

    sectionHeader('11.6  Sample Payload Generation', 2);
    bullet('Click "Generate Sample Payload" on a config card');
    bullet('Calls generateInputPayload backend function with { source_type, enabled_fields, custom_fields }');
    bullet('Payload preview panel shows: validation status (CheckCircle/AlertCircle), Copy button, Save button, close (X) button');
    bullet('Save button → creates SamplePayload entity record; payload stored as JSON string');

    sectionHeader('11.7  Saved Payloads Section', 2);
    bullet('Displayed below the preview panel when savedPayloads.length > 0');
    bullet('Each saved payload row: validity icon, label/format_name, created timestamp, copy/duplicate/delete actions');
    bullet('Payload JSON displayed in expandable monospace green-on-dark code block (max-h-32)');
    bullet('Duplicate: creates new SamplePayload with label "… (Copy)"');

    sectionHeader('11.8  Cross-Tab Format Duplication', 2);
    bullet('Toolbar "Duplicate" dropdown: shows all configs across all source types');
    bullet('User selects a source format and a target source type, then clicks Duplicate');
    bullet('Creates a new InputFormatConfig with source_type = selected target, format_name += " (Copy)"');

    // ══════════════════════════════════════════════════════════════════════════
    // 12. USERS
    // ══════════════════════════════════════════════════════════════════════════

    doc.addPage();
    y = 20;
    sectionHeader('12. MODULE: USERS & ACCESS CONTROL', 1);

    sectionHeader('12.1  Purpose', 2);
    wrappedText('Manages operator and viewer user profiles stored in the UserProfile entity. Each profile can be associated with a specific highway and granted access to specific sensor devices. This is an application-level profile layer separate from Base44 authentication.', margin, contentW);

    sectionHeader('12.2  Table Columns', 2);
    const uCols = [
      ['Column', 'Source', 'Visibility'],
      ['User (avatar + name + ID)', 'full_name, user_id', 'Always'],
      ['Phone', 'phone', 'md+'],
      ['Address', 'address', 'lg+'],
      ['Type', 'user_type', 'Always (colour badge)'],
      ['Interstate', 'highway_name', 'md+'],
      ['Devices', 'device_ids.length', 'lg+'],
      ['Status', 'is_active', 'Always (green pulse / grey)'],
      ['Actions', 'Edit / Delete icons', 'Always'],
    ];
    const ucw = [45, 35, contentW - 80];
    uCols.forEach((r, i) => tableRow(r, ucw, i === 0));

    sectionHeader('12.3  User Type Color Badges', 2);
    const utypes = [
      ['Type', 'Background', 'Text'],
      ['admin', 'bg-red-500/15', 'text-red-400'],
      ['operator', 'bg-blue-500/15', 'text-blue-400'],
      ['viewer', 'bg-slate-500/15', 'text-slate-400'],
      ['technician', 'bg-yellow-500/15', 'text-yellow-400'],
      ['supervisor', 'bg-purple-500/15', 'text-purple-400'],
    ];
    const utw = [30, 40, contentW - 70];
    utypes.forEach((r, i) => tableRow(r, utw, i === 0));

    sectionHeader('12.4  Add / Edit Dialog Fields', 2);
    const uForm = [
      ['Field', 'Input', 'Notes'],
      ['Full Name', 'Text', 'Required'],
      ['User ID', 'Text (monospace)', 'e.g. USR-0042'],
      ['Phone', 'Text', 'Free-form'],
      ['User Type', 'Select', 'admin/operator/viewer/technician/supervisor'],
      ['Address', 'Text (full width)', 'Street address'],
      ['Interstate Assignment', 'Select dropdown', 'From Highway entity list; resets device selection'],
      ['Device Access (search)', 'Text search', 'Filters devices by name/ID/type/mile_marker'],
      ['Device Checkboxes', 'Custom checkbox list', 'Scrollable 14rem; toggle adds/removes from device_ids & device_names arrays'],
      ['Notes', 'Text', 'Optional free-form'],
      ['Status', 'Select', 'active / inactive → stored as is_active boolean'],
    ];
    const ufw = [38, 28, contentW - 66];
    uForm.forEach((r, i) => tableRow(r, ufw, i === 0));

    // ══════════════════════════════════════════════════════════════════════════
    // 13. PORTAL
    // ══════════════════════════════════════════════════════════════════════════

    doc.addPage();
    y = 20;
    sectionHeader('13. MODULE: PORTAL / OPERATOR LOGIN', 1);

    sectionHeader('13.1  Purpose', 2);
    wrappedText('A standalone login page at /portal accessible outside the AppLayout shell. Allows highway operators to authenticate against their assigned UserProfile records and enter a monitoring session scoped to their highway.', margin, contentW);

    sectionHeader('13.2  UI Fields', 2);
    const pFields = [
      ['Field', 'Type', 'Notes'],
      ['Interstate selector', 'Select dropdown', 'Loads from Highway entity; required'],
      ['Password / Access Code', 'Password input', 'Show/hide toggle via Eye/EyeOff icon'],
      ['Login button', 'Submit button', 'Disabled while loading; shows spinner'],
    ];
    const pw = [40, 35, contentW - 75];
    pFields.forEach((r, i) => tableRow(r, pw, i === 0));

    sectionHeader('13.3  Authentication Flow', 2);
    bullet('On submit: validates highway_id and password are filled');
    bullet('Calls base44.entities.UserProfile.filter({ highway_id }) to get profiles for that highway');
    bullet('Checks password match against profile records (demo: any non-empty value accepted)');
    bullet('On success: stores highway_id in sessionStorage → redirects to / (dashboard)');
    bullet('Existing session detected on mount → immediate redirect to /');

    // ══════════════════════════════════════════════════════════════════════════
    // 14. DATABASE SCHEMA
    // ══════════════════════════════════════════════════════════════════════════

    doc.addPage();
    y = 20;
    sectionHeader('14. DATABASE SCHEMA — ALL ENTITIES', 1);
    wrappedText('All entities are managed by the Base44 BaaS platform. Every record has built-in fields: id (string), created_date (ISO datetime), updated_date (ISO datetime), created_by (email string).', margin, contentW);

    // Helper to render an entity table
    const entityTable = (name, fields) => {
      checkPage(18);
      sectionHeader(name, 2);
      const ew = [38, 20, 15, contentW - 73];
      const header = ['Field', 'Type', 'Required', 'Description / Enum Values'];
      tableRow(header, ew, true);
      fields.forEach(f => tableRow(f, ew));
      y += 3;
    };

    entityTable('14.1  Highway', [
      ['name', 'string', 'Yes', 'Human-readable highway name'],
      ['highway_id', 'string', 'Yes', 'Unique identifier (PK-like)'],
      ['description', 'string', 'No', 'Optional description'],
      ['state', 'string', 'No', 'State or region'],
      ['is_active', 'boolean', 'No', 'Default: true'],
    ]);

    entityTable('14.2  MergeZone', [
      ['highway_id', 'string', 'Yes', 'FK → Highway.highway_id'],
      ['zone_name', 'string', 'Yes', 'Display name'],
      ['zone_id', 'string', 'Yes', 'Unique zone identifier'],
      ['mile_marker', 'number', 'No', 'Position along the interstate'],
      ['latitude / longitude', 'number', 'No', 'GPS coordinates'],
      ['status', 'enum', 'No', 'active | inactive | fault | maintenance'],
      ['geofence_radius', 'number', 'No', 'Metres, default 500'],
    ]);

    entityTable('14.3  SwitchServer', [
      ['zone_id', 'string', 'Yes', 'FK → MergeZone.zone_id'],
      ['highway_id', 'string', 'No', 'Denormalised highway reference'],
      ['server_name', 'string', 'Yes', 'Display name'],
      ['server_id', 'string', 'Yes', 'Unique server identifier'],
      ['ip_address', 'string', 'No', 'IPv4 address'],
      ['port', 'number', 'No', 'Default 8080'],
      ['status', 'enum', 'No', 'online | offline | degraded | fault'],
      ['cpu_percent', 'number', 'No', 'Default 0'],
      ['memory_percent', 'number', 'No', 'Default 0'],
      ['uptime_seconds', 'number', 'No', 'Default 0'],
      ['last_heartbeat', 'datetime', 'No', 'ISO 8601'],
      ['firmware_version', 'string', 'No', 'Semver string'],
    ]);

    doc.addPage();
    y = 20;

    entityTable('14.4  SensorDevice', [
      ['zone_id', 'string', 'Yes', 'FK → MergeZone.zone_id'],
      ['highway_id', 'string', 'No', 'Denormalised highway reference'],
      ['server_id', 'string', 'No', 'FK → SwitchServer.server_id'],
      ['device_name', 'string', 'Yes', 'Display name'],
      ['device_id', 'string', 'Yes', 'Unique device identifier'],
      ['device_type', 'enum', 'Yes', 'camera | lidar | radar | vehicle tag reader | signal receiver'],
      ['source_type', 'enum', 'No', 'physical | satellite | telecom | tracker'],
      ['device_height', 'number', 'No', 'Installation height in metres'],
      ['mile_marker', 'number', 'No', 'Position along the interstate'],
      ['location_comment', 'string', 'No', 'Descriptive location note'],
      ['latitude / longitude', 'number', 'No', 'GPS coordinates'],
      ['status', 'enum', 'No', 'online | offline | fault | calibrating'],
      ['last_seen', 'datetime', 'No', 'ISO 8601 timestamp'],
      ['firmware_version', 'string', 'No', 'Semver string'],
      ['notes', 'string', 'No', 'Free-form notes'],
    ]);

    entityTable('14.5  TriangulationConfig', [
      ['zone_id', 'string', 'Yes', 'FK → MergeZone.zone_id'],
      ['highway_id', 'string', 'No', 'Denormalised reference'],
      ['geofence_radius', 'number', 'No', 'Default 500'],
      ['switch{1-3}_server_id', 'string', 'No', 'FK → SwitchServer.server_id (×3)'],
      ['switch{1-3}_lat', 'number', 'No', 'GPS latitude of switch node (×3)'],
      ['switch{1-3}_lon', 'number', 'No', 'GPS longitude of switch node (×3)'],
      ['switch{1-3}_label', 'string', 'No', 'Display label (×3)'],
      ['is_active', 'boolean', 'No', 'Default true'],
    ]);

    entityTable('14.6  VehicleEvent', [
      ['zone_id', 'string', 'Yes', 'FK → MergeZone.zone_id'],
      ['highway_id', 'string', 'No', 'Denormalised reference'],
      ['server_id', 'string', 'No', 'Source server'],
      ['device_id', 'string', 'No', 'Source device'],
      ['event_type', 'enum', 'Yes', 'detection | merge | conflict | speeding | fault'],
      ['vehicle_id', 'string', 'No', 'Detected vehicle identifier'],
      ['speed_mph', 'number', 'No', 'Vehicle speed'],
      ['latitude / longitude', 'number', 'No', 'GPS location at event time'],
      ['confidence', 'number', 'No', 'Detection confidence 0–100'],
      ['timestamp', 'datetime', 'No', 'Event timestamp (ISO 8601)'],
      ['raw_data', 'string', 'No', 'JSON payload from sensor'],
    ]);

    doc.addPage();
    y = 20;

    entityTable('14.7  InputFormatConfig', [
      ['source_type', 'enum', 'Yes', 'physical | satellite | telecom | tracker'],
      ['format_name', 'string', 'Yes', 'User-friendly name for the format'],
      ['source_id', 'string', 'No', 'Unique input source identifier'],
      ['input_source', 'string', 'No', 'Endpoint URL, stream name, or device tag'],
      ['description', 'string', 'No', 'Free-form description'],
      ['enabled_fields', 'string[]', 'No', 'Array of predefined field keys'],
      ['custom_fields', 'object[]', 'No', 'Array of { name: string, type: string }'],
    ]);

    entityTable('14.8  SamplePayload', [
      ['source_type', 'enum', 'Yes', 'physical | satellite | telecom | tracker'],
      ['format_config_id', 'string', 'Yes', 'FK → InputFormatConfig.id'],
      ['format_name', 'string', 'No', 'Snapshot of format_name at save time'],
      ['payload', 'string', 'Yes', 'JSON-stringified generated payload'],
      ['is_valid', 'boolean', 'No', 'Validation result flag'],
      ['label', 'string', 'No', 'Optional user label (used for copies)'],
    ]);

    entityTable('14.9  UserProfile', [
      ['user_id', 'string', 'No', 'Application-level user identifier'],
      ['full_name', 'string', 'Yes', 'Display name'],
      ['address', 'string', 'No', 'Street address'],
      ['phone', 'string', 'No', 'Contact phone'],
      ['user_type', 'enum', 'No', 'admin | operator | viewer | technician | supervisor'],
      ['highway_id', 'string', 'No', 'FK → Highway.highway_id'],
      ['highway_name', 'string', 'No', 'Denormalised highway name'],
      ['device_ids', 'string[]', 'No', 'Array of device_id values the user can access'],
      ['device_names', 'string[]', 'No', 'Parallel array of display names'],
      ['notes', 'string', 'No', 'Free-form notes'],
      ['is_active', 'boolean', 'No', 'Default true'],
    ]);

    // ── Entity Relationship Diagram (text) ──────────────────────────────────
    checkPage(40);
    sectionHeader('14.10  Entity Relationships', 2);
    bullet('Highway (1) ────< MergeZone (highway_id)');
    bullet('Highway (1) ────< SwitchServer (highway_id)');
    bullet('Highway (1) ────< SensorDevice (highway_id)');
    bullet('Highway (1) ────< UserProfile (highway_id)');
    bullet('MergeZone (1) ────< SwitchServer (zone_id)');
    bullet('MergeZone (1) ────< SensorDevice (zone_id)');
    bullet('MergeZone (1) ────< VehicleEvent (zone_id)');
    bullet('MergeZone (1) ────< TriangulationConfig (zone_id)');
    bullet('SwitchServer (1) ────< SensorDevice (server_id, optional)');
    bullet('InputFormatConfig (1) ────< SamplePayload (format_config_id)');
    bullet('UserProfile.device_ids[] ────>< SensorDevice.device_id  (M:N via array)');

    // ══════════════════════════════════════════════════════════════════════════
    // 15. BACKEND FUNCTIONS
    // ══════════════════════════════════════════════════════════════════════════

    doc.addPage();
    y = 20;
    sectionHeader('15. BACKEND FUNCTIONS', 1);
    wrappedText('Serverless edge functions deployed on Deno Deploy. All functions authenticate the caller via base44.auth.me() before executing business logic.', margin, contentW);

    const beFunctions = [
      ['Function', 'Inputs', 'Output', 'Description'],
      ['generateInputPayload', 'source_type, enabled_fields[], custom_fields[]', '{ payload, validation, field_count }', 'Generates randomised telemetry JSON from schema config. Uses Dallas-area GPS bounds, random vehicle makes/models, timestamps.'],
      ['getTomTomTraffic', 'highway_id', 'traffic segment array', 'Calls TomTom Traffic Flow API. Falls back to simulated data if TOMTOM_API_KEY not set.'],
      ['saveTomTomKey', '{ apiKey }', '{ success }', 'Persists TomTom API key as TOMTOM_API_KEY environment secret via Base44 admin API.'],
    ];
    const bew = [32, 42, 40, contentW - 114];
    beFunctions.forEach((r, i) => tableRow(r, bew, i === 0));

    y += 4;
    sectionHeader('15.1  generateInputPayload — Logic Detail', 2);
    bullet('SOURCE_BASE: per source-type base fields (sensor_id, tracker_id, device_id, fleet_id)');
    bullet('COMMON_FIELD_SAMPLES: 20 field definitions with type and sample values');
    bullet('generateUnique(): random timestamp (±60 min), GPS ±0.1° around Dallas, speed 20–100 mph, random direction 0–360°');
    bullet('Builds payload.data object by iterating enabled_fields and custom_fields');
    bullet('Validation: fails if no fields selected; fails if custom field missing name or type');
    bullet('Returns full payload JSON + validation summary object');

    // ══════════════════════════════════════════════════════════════════════════
    // 16. SEQUENCE DIAGRAMS
    // ══════════════════════════════════════════════════════════════════════════

    doc.addPage();
    y = 20;
    sectionHeader('16. SEQUENCE DIAGRAMS', 1);

    sectionHeader('16.1  Application Bootstrap', 2);
    seqStep('Browser', '→', 'AuthProvider', 'Mounts; calls base44.auth.me()');
    seqStep('AuthProvider', '→', 'Base44 BaaS', 'GET /auth/me (bearer token from cookie)');
    seqStep('Base44 BaaS', '→', 'AuthProvider', 'Returns user object or 401');
    seqStep('AuthProvider', '→', 'AuthenticatedApp', 'Sets isLoadingAuth=false, provides user context');
    seqStep('AuthenticatedApp', '→', 'AppLayout', 'Renders layout with Outlet');
    seqStep('AppLayout', '→', 'HighwaySelector', 'Mounts; fetches Highway.list()');
    seqStep('HighwaySelector', '→', 'AppLayout', 'onHighwayChange(highway_id) on selection');
    seqStep('AppLayout', '→', 'Page Component', 'Passes selectedHighway as prop');

    y += 4;
    sectionHeader('16.2  Create / Edit Entity (Generic CRUD)', 2);
    seqStep('User', '→', 'Page', 'Clicks "Add / Edit" button');
    seqStep('Page', '→', 'Dialog', 'setOpen(true); form pre-populated if editing');
    seqStep('User', '→', 'Dialog', 'Fills form fields, clicks Save/Create');
    seqStep('Dialog', '→', 'save()', 'Calls save() handler');
    seqStep('save()', '→', 'Base44 SDK', 'Entity.create(data) or Entity.update(id, data)');
    seqStep('Base44 SDK', '→', 'Base44 BaaS', 'HTTP POST/PUT to database API');
    seqStep('Base44 BaaS', '→', 'Base44 SDK', 'Returns saved record');
    seqStep('save()', '→', 'Page', 'setOpen(false); load() refreshes list');

    y += 4;
    sectionHeader('16.3  Generate & Save Sample Payload', 2);
    seqStep('User', '→', 'FormatTab', 'Clicks "Generate Sample Payload" on a config card');
    seqStep('FormatTab', '→', 'generatePayload()', 'setSelectedConfig(cfg); setGenerating(true)');
    seqStep('generatePayload()', '→', 'base44.functions', 'invoke("generateInputPayload", { source_type, enabled_fields, custom_fields })');
    seqStep('base44.functions', '→', 'Deno Edge Fn', 'HTTP POST with payload config');
    seqStep('Deno Edge Fn', '→', 'base44.functions', 'Returns { payload, validation, field_count }');
    seqStep('FormatTab', '→', 'Payload Preview', 'setPayload(res.data.payload); renders preview panel');
    seqStep('User', '→', 'FormatTab', 'Clicks "Save" button in preview panel');
    seqStep('FormatTab', '→', 'savePayload()', 'setSaving(true)');
    seqStep('savePayload()', '→', 'Base44 SDK', 'SamplePayload.create({ source_type, format_config_id, payload, is_valid })');
    seqStep('Base44 SDK', '→', 'Base44 BaaS', 'Persists record to database');
    seqStep('savePayload()', '→', 'FormatTab', 'setSaving(false); load() refreshes savedPayloads list');

    y += 4;
    sectionHeader('16.4  Cross-Tab Format Duplication', 2);
    seqStep('User', '→', 'FormatTab', 'Opens "Duplicate" dropdown toolbar button');
    seqStep('FormatTab', '→', 'allConfigs', 'Lists all InputFormatConfig records across all source types');
    seqStep('User', '→', 'DropdownMenu', 'Selects a source config and a target source type');
    seqStep('User', '→', 'FormatTab', 'Clicks "Duplicate" confirm button');
    seqStep('duplicateTo()', '→', 'Base44 SDK', 'InputFormatConfig.create({ source_type: target, format_name + "(Copy)", ... })');
    seqStep('Base44 SDK', '→', 'FormatTab', 'Returns new config; load() refreshes the target tab data');

    doc.addPage();
    y = 20;

    sectionHeader('16.5  Dashboard Data Load with Highway Filter', 2);
    seqStep('User', '→', 'HighwaySelector', 'Selects "Interstate 20"');
    seqStep('HighwaySelector', '→', 'AppLayout', 'onHighwayChange("I20")');
    seqStep('AppLayout', '→', 'Dashboard', 'Re-renders with selectedHighway="I20"');
    seqStep('Dashboard useEffect', '→', 'Base44 SDK', 'Promise.all: MergeZone.filter({highway_id:"I20"}), SwitchServer.filter({...}), SensorDevice.filter({...}), VehicleEvent.filter({...}, -created_date, 20)');
    seqStep('Base44 BaaS', '→', 'Dashboard', 'Returns filtered arrays; setZones/setServers/setSensors/setEvents');
    seqStep('Dashboard', '→', 'StatCards', 'Re-renders with new counts');
    seqStep('Dashboard', '→', 'HighwayMap', 'Passes zones and sensors for map rendering');

    y += 4;
    sectionHeader('16.6  TomTom Traffic Data Flow', 2);
    seqStep('Traffic3D', '→', 'fetchTraffic()', 'User clicks refresh or 5-min countdown expires');
    seqStep('fetchTraffic()', '→', 'base44.functions', 'invoke("getTomTomTraffic", { highway_id })');
    seqStep('base44.functions', '→', 'Deno Edge Fn', 'Authenticated HTTP POST');
    seqStep('Deno Edge Fn', '→', 'TomTom API', 'GET /traffic/services/4/flowSegmentData?key=TOMTOM_API_KEY');
    seqStep('TomTom API', '→', 'Deno Edge Fn', 'Returns speed, freeFlowSpeed, travelTime per segment');
    seqStep('Deno Edge Fn', '→', 'Traffic3D', 'Returns structured traffic data array');
    seqStep('Traffic3D', '→', 'Scene3D/MapLanding', 'Passes trafficData prop; components re-render with new congestion colours');

    y += 4;
    sectionHeader('16.7  Operator Portal Login', 2);
    seqStep('User', '→', 'Portal', 'Selects highway and enters access code; clicks Login');
    seqStep('Portal', '→', 'Base44 SDK', 'UserProfile.filter({ highway_id: selectedHighway })');
    seqStep('Base44 SDK', '→', 'Portal', 'Returns profile records for that highway');
    seqStep('Portal', '→', 'Portal (local)', 'Validates credentials against returned profiles');
    seqStep('Portal', '→', 'sessionStorage', 'sessionStorage.setItem("highway_id", value)');
    seqStep('Portal', '→', 'Browser', 'window.location.href = "/" (redirect to dashboard)');

    // ══════════════════════════════════════════════════════════════════════════
    // 17. UI DESIGN SYSTEM
    // ══════════════════════════════════════════════════════════════════════════

    doc.addPage();
    y = 20;
    sectionHeader('17. UI DESIGN SYSTEM', 1);

    sectionHeader('17.1  Color Tokens (CSS Variables)', 2);
    const colorTokens = [
      ['Token', 'Light Mode', 'Dark Mode', 'Usage'],
      ['--background', 'hsl(0 0% 100%)', 'hsl(0 0% 3.9%)', 'Page background'],
      ['--foreground', 'hsl(0 0% 3.9%)', 'hsl(0 0% 98%)', 'Primary text'],
      ['--card', 'hsl(0 0% 100%)', 'hsl(0 0% 3.9%)', 'Card/panel backgrounds'],
      ['--primary', 'hsl(0 0% 9%)', 'hsl(0 0% 98%)', 'Buttons, active nav, accents'],
      ['--secondary', 'hsl(0 0% 96.1%)', 'hsl(0 0% 14.9%)', 'Subtle backgrounds, hover'],
      ['--muted', 'hsl(0 0% 96.1%)', 'hsl(0 0% 14.9%)', 'Muted text, placeholder backgrounds'],
      ['--border', 'hsl(0 0% 89.8%)', 'hsl(0 0% 14.9%)', 'All borders and dividers'],
      ['--destructive', 'hsl(0 84.2% 60.2%)', 'hsl(0 62.8% 30.6%)', 'Errors, delete actions'],
    ];
    const ctw = [33, 32, 32, contentW - 97];
    colorTokens.forEach((r, i) => tableRow(r, ctw, i === 0));

    sectionHeader('17.2  Typography', 2);
    bullet('Font: system sans-serif (Helvetica / Arial fallback stack via Tailwind default)');
    bullet('Page titles: text-lg font-bold tracking-tight');
    bullet('Section headers in cards: text-sm font-semibold');
    bullet('Body text: text-sm');
    bullet('Metadata / IDs / code: text-xs font-mono text-muted-foreground');
    bullet('Badge / chip text: text-[10px] or text-[11px]');

    sectionHeader('17.3  Component Patterns', 2);
    bullet('Cards: rounded-xl border border-border bg-card p-4 — consistent across all module grids');
    bullet('Dialogs: max-w-lg (standard) / max-w-2xl (complex forms like Triangulation, Users)');
    bullet('Buttons: shadcn/ui Button with size="sm" for actions within cards; default for primary dialog actions');
    bullet('Status Badges: StatusBadge shared component — maps status string to colour class');
    bullet('Tables: grid-based layout with monospace column data (Events) or HTML table (Users)');
    bullet('Inputs: h-8 text-sm for compact inline forms; default h-9 in dialogs');
    bullet('Source-type colour chips: tab-specific colour for field badges (blue/purple/green/orange)');

    sectionHeader('17.4  Responsive Breakpoints', 2);
    bullet('Mobile: single column card grid, condensed table (some columns hidden)');
    bullet('md (768 px): 2-column card grid; table shows Phone, Interstate columns');
    bullet('xl (1280 px): 3-column card grid');
    bullet('Table responsive: phone/address/devices hidden below md/lg');

    sectionHeader('17.5  Animation & Feedback', 2);
    bullet('Loading spinner: border-t-primary rounded-full animate-spin (8×8 or custom size)');
    bullet('System Live indicator: animate-pulse on green dot in header');
    bullet('Demo mode event feed: "LIVE" badge with animate-pulse text-yellow-400');
    bullet('CPU progress bar: transition-all on width change');
    bullet('Copy confirmation: "Copied!" text replaces "Copy" for 2 seconds');
    bullet('Save confirmation: keySaved state shows "Saved!" + CheckCircle icon for 2.5 s');

    // ══════════════════════════════════════════════════════════════════════════
    // 18. SECURITY
    // ══════════════════════════════════════════════════════════════════════════

    doc.addPage();
    y = 20;
    sectionHeader('18. SECURITY & ACCESS CONTROL', 1);

    sectionHeader('18.1  Authentication', 2);
    bullet('Handled entirely by Base44 platform; no custom auth implementation');
    bullet('Session tokens managed via HTTP-only cookies by Base44 BaaS');
    bullet('All entity API calls are authenticated via the Base44 SDK token');
    bullet('Backend functions authenticate caller via base44.auth.me() on every request');
    bullet('Unauthenticated function calls return 401 Unauthorized');

    sectionHeader('18.2  Authorization', 2);
    bullet('User roles stored in Base44 User entity: admin / user (default)');
    bullet('UserProfile entity stores application roles: admin, operator, viewer, technician, supervisor');
    bullet('Admin-only operations protected by user.role === "admin" checks in backend functions');
    bullet('Highway-scoped data: all listing operations filtered by highway_id prop');
    bullet('UserProfile device_ids array controls which sensors a user profile has access to (application-level)');

    sectionHeader('18.3  API Keys & Secrets', 2);
    bullet('TomTom API key stored as TOMTOM_API_KEY environment secret (not exposed to frontend)');
    bullet('saveTomTomKey backend function updates the secret; only accessible to authenticated users');
    bullet('BASE44_APP_ID is the only pre-populated secret available in edge functions');
    bullet('No other API keys or credentials are stored client-side');

    sectionHeader('18.4  Portal Access', 2);
    bullet('/portal route is outside the AppLayout shell — accessible without the main navigation');
    bullet('Operator login validated against UserProfile records for the selected highway');
    bullet('Session stored in sessionStorage (tab-scoped, cleared on tab close)');
    bullet('No sensitive credentials transmitted; password field is a demo access code');

    // ══════════════════════════════════════════════════════════════════════════
    // FOOTER on each page
    // ══════════════════════════════════════════════════════════════════════════

    const totalPages = doc.getNumberOfPages();
    for (let i = 2; i <= totalPages; i++) {
      doc.setPage(i);
      doc.setFillColor(15, 23, 42);
      doc.rect(0, 287, W, 10, 'F');
      doc.setFontSize(7);
      doc.setFont('helvetica', 'normal');
      doc.setTextColor(100, 116, 139);
      doc.text('MergeSafeServer Control Platform — Software Requirements Document v1.0 — CONFIDENTIAL', margin, 293);
      doc.text(`Page ${i} of ${totalPages}`, W - margin, 293, { align: 'right' });
    }

    const pdfBytes = doc.output('arraybuffer');
    return new Response(pdfBytes, {
      status: 200,
      headers: {
        'Content-Type': 'application/pdf',
        'Content-Disposition': 'attachment; filename=MergeSafeServer_Requirements_v1.0.pdf',
      },
    });

  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});