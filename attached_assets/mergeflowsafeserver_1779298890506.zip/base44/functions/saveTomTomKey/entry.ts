import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

// This function stores the TomTom API key as a user setting on the current user's profile.
// For a production system, keys would be stored as backend secrets via the dashboard.
// Here we persist the key on the user entity so it's retrievable by backend functions.

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });
    if (user.role !== 'admin') return Response.json({ error: 'Admin only' }, { status: 403 });

    const { apiKey } = await req.json();
    if (!apiKey || typeof apiKey !== 'string') {
      return Response.json({ error: 'apiKey is required' }, { status: 400 });
    }

    // Store on user profile (masked for security in logs)
    await base44.auth.updateMe({ tomtom_api_key: apiKey });

    return Response.json({ success: true, message: 'TomTom API key saved.' });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});