import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

const VEHICLE_MAKES = ["Ford", "Toyota", "Honda", "Chevrolet", "BMW", "Tesla", "Audi", "Mercedes"];
const VEHICLE_MODELS = {
  Ford: ["F-150", "Mustang", "Explorer", "Transit"],
  Toyota: ["Camry", "Tacoma", "Corolla", "Prius"],
  Honda: ["Accord", "Civic", "CR-V", "Pilot"],
  Chevrolet: ["Silverado", "Malibu", "Equinox", "Traverse"],
  BMW: ["X5", "3 Series", "5 Series"],
  Tesla: ["Model S", "Model 3", "Model X", "Model Y"],
  Audi: ["A4", "Q5", "Q7", "RS5"],
  Mercedes: ["E-Class", "GLE", "C-Class"]
};

const SAMPLE_VALUES = {
  string: "example-string",
  number: 42.5,
  boolean: true,
  array: ["item1", "item2"],
  object: { key: "value" }
};

const COMMON_FIELD_SAMPLES = {
  make: { type: "string", sample: "Ford" },
  model: { type: "string", sample: "F-150" },
  date: { type: "string", sample: "2026-05-20" },
  time: { type: "string", sample: "14:30:00Z" },
  timestamp: { type: "string", sample: "2026-05-20T14:30:00Z" },
  coordinates: { type: "array", sample: [32.7767, -96.7980] },
  latitude: { type: "number", sample: 32.7767 },
  longitude: { type: "number", sample: -96.7980 },
  speed: { type: "number", sample: 65.0 },
  speed_mph: { type: "number", sample: 65.0 },
  altitude_meters: { type: "number", sample: 150.0 },
  direction_degrees: { type: "number", sample: 270 },
  firmware_version: { type: "string", sample: "v2.4.1" },
  status: { type: "string", sample: "online" },
  vehicle_id: { type: "string", sample: "VEH-001" },
  tag_id: { type: "string", sample: "TAG-XYZ-123" },
  signal_strength_dbm: { type: "number", sample: -85 },
  device_status: { type: "string", sample: "online" },
  provider_name: { type: "string", sample: "GlobalSat Trackers" },
  telecom_provider: { type: "string", sample: "Verizon IoT" },
  vehicle_type: { type: "string", sample: "car" },
  traffic_density_percent: { type: "number", sample: 75 },
  average_speed_mph: { type: "number", sample: 35 }
};

const SOURCE_BASE = {
  physical: {
    sensor_id: "CAM-I20-001",
    highway_id: "I20",
    device_type: "camera"
  },
  satellite: {
    tracker_id: "SAT-VEH-456",
    provider_name: "GlobalSat Trackers"
  },
  telecom: {
    device_id: "TEL-DEV-78901",
    telecom_provider: "Verizon IoT"
  },
  tracker: {
    tracker_id: "TRK-001",
    fleet_id: "FLEET-A"
  }
};

// Generate unique values for each payload
const generateUnique = () => {
  const now = new Date();
  const offsetMs = Math.floor(Math.random() * 3600000); // 0-60 min offset
  const timestamp = new Date(now.getTime() - offsetMs).toISOString();
  
  // Generate coordinate within realistic highway range (Dallas area ±0.1 degrees)
  const baseLat = 32.7767;
  const baseLon = -96.7980;
  const lat = parseFloat((baseLat + (Math.random() - 0.5) * 0.2).toFixed(4));
  const lon = parseFloat((baseLon + (Math.random() - 0.5) * 0.2).toFixed(4));
  
  const make = VEHICLE_MAKES[Math.floor(Math.random() * VEHICLE_MAKES.length)];
  const model = VEHICLE_MODELS[make][Math.floor(Math.random() * VEHICLE_MODELS[make].length)];
  const speed = Math.floor(Math.random() * 80) + 20; // 20-100 mph
  const direction = Math.floor(Math.random() * 360);
  
  return { timestamp, lat, lon, make, model, speed, direction };
};

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const body = await req.json();
    const { source_type, enabled_fields = [], custom_fields = [] } = body;

    if (!source_type) {
      return Response.json({ error: 'source_type is required' }, { status: 400 });
    }

    const validSourceTypes = ['physical', 'satellite', 'telecom', 'tracker'];
    if (!validSourceTypes.includes(source_type)) {
      return Response.json({ error: `Invalid source_type. Must be one of: ${validSourceTypes.join(', ')}` }, { status: 400 });
    }

    // Generate unique data for this payload
    const unique = generateUnique();

    // Build base payload from source type
    const payload = {
      ...(SOURCE_BASE[source_type] || {}),
      timestamp: unique.timestamp,
      data: {}
    };

    // Add enabled predefined fields with unique values
    for (const field of enabled_fields) {
      const fieldDef = COMMON_FIELD_SAMPLES[field];
      if (fieldDef) {
        // Use unique values for dynamic fields
        if (field === 'timestamp') {
          payload.data[field] = unique.timestamp;
        } else if (field === 'date') {
          payload.data[field] = unique.timestamp.split('T')[0];
        } else if (field === 'time') {
          payload.data[field] = unique.timestamp.split('T')[1];
        } else if (field === 'latitude') {
          payload.data[field] = unique.lat;
        } else if (field === 'longitude') {
          payload.data[field] = unique.lon;
        } else if (field === 'coordinates') {
          payload.data[field] = [unique.lat, unique.lon];
        } else if (field === 'make') {
          payload.data[field] = unique.make;
        } else if (field === 'model') {
          payload.data[field] = unique.model;
        } else if (field === 'speed' || field === 'speed_mph') {
          payload.data[field] = unique.speed;
        } else if (field === 'direction_degrees') {
          payload.data[field] = unique.direction;
        } else {
          payload.data[field] = fieldDef.sample;
        }
      } else {
        payload.data[field] = "unknown";
      }
    }

    // Add custom fields
    for (const cf of custom_fields) {
      if (cf.name && cf.type) {
        const sample = SAMPLE_VALUES[cf.type];
        payload.data[cf.name] = sample !== undefined ? sample : "unknown";
      }
    }

    // Validation summary
    const validation = {
      valid: true,
      issues: []
    };

    if (!enabled_fields.length && !custom_fields.length) {
      validation.valid = false;
      validation.issues.push("No fields selected. Add at least one field to generate a valid payload.");
    }

    for (const cf of custom_fields) {
      if (!cf.name) {
        validation.valid = false;
        validation.issues.push("A custom field is missing a name.");
      }
      if (!cf.type) {
        validation.valid = false;
        validation.issues.push(`Custom field "${cf.name || '(unnamed)'}" is missing a type.`);
      }
    }

    return Response.json({
      source_type,
      payload,
      validation,
      field_count: enabled_fields.length + custom_fields.length
    });

  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});