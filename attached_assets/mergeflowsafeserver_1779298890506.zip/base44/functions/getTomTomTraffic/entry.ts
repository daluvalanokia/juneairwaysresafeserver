import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    const { centerLat, centerLon } = await req.json();

    const apiKey = Deno.env.get('TOMTOM_API_KEY');

    if (apiKey) {
      // Use TomTom Traffic Flow API for real-time data
      const zoom = 10;
      const url = `https://api.tomtom.com/traffic/services/4/flowSegmentData/absolute/${zoom}/json?point=${centerLat},${centerLon}&unit=MPH&key=${apiKey}`;

      const response = await fetch(url);
      if (!response.ok) {
        // Fall back to simulated data on API errors (bad key, quota, etc.)
        return Response.json({
          simulated: true,
          apiError: `TomTom API error: ${response.status} ${response.statusText}`,
          segments: generateSimulatedSegments(centerLat, centerLon),
        });
      }

      const data = await response.json();
      const flow = data.flowSegmentData;

      if (!flow) {
        return Response.json({
          simulated: true,
          segments: generateSimulatedSegments(centerLat, centerLon),
        });
      }

      const currentSpeed = flow.currentSpeed;
      const freeFlowSpeed = flow.freeFlowSpeed;
      const ratio = currentSpeed / freeFlowSpeed;
      const congestionLevel = ratio >= 0.8 ? 'free' : ratio >= 0.5 ? 'moderate' : ratio >= 0.25 ? 'heavy' : 'standstill';

      // Build segments from TomTom coordinates
      const coords = (flow.coordinates?.coordinate || []).map(c => ({ lat: c.latitude, lon: c.longitude }));

      // Split into segments if we have enough points, otherwise build around center
      const segments = buildSegmentsFromFlow(centerLat, centerLon, currentSpeed, freeFlowSpeed, congestionLevel, coords);

      return Response.json({ simulated: false, segments });
    }

    // Fallback to simulated data if no API key
    return Response.json({
      simulated: true,
      segments: generateSimulatedSegments(centerLat, centerLon),
    });

  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});

function buildSegmentsFromFlow(centerLat, centerLon, currentSpeed, freeFlowSpeed, congestionLevel, coords) {
  const EXIT_LON = centerLon - 0.008;
  const MERGE_LON = centerLon;

  if (coords.length >= 2) {
    // Use real TomTom coordinates
    const mid = Math.floor(coords.length / 2);
    return [
      {
        id: 'hwy-approach',
        label: 'Highway Approach',
        currentSpeed,
        freeFlowSpeed,
        congestionLevel,
        coordinates: coords.slice(0, mid + 1),
      },
      {
        id: 'hwy-merge',
        label: 'Merge Zone',
        currentSpeed: Math.round(currentSpeed * 0.7),
        freeFlowSpeed,
        congestionLevel: congestionLevel === 'free' ? 'moderate' : 'heavy',
        coordinates: coords.slice(mid),
      },
    ];
  }

  // Fallback geometry if TomTom didn't return coordinates
  return [
    {
      id: 'hwy-west',
      label: 'Highway Approach',
      currentSpeed,
      freeFlowSpeed,
      congestionLevel,
      coordinates: [
        { lat: centerLat, lon: EXIT_LON - 0.010 },
        { lat: centerLat, lon: EXIT_LON },
      ],
    },
    {
      id: 'hwy-merge',
      label: 'Merge Zone',
      currentSpeed: Math.round(currentSpeed * 0.7),
      freeFlowSpeed,
      congestionLevel: congestionLevel === 'free' ? 'moderate' : 'heavy',
      coordinates: [
        { lat: centerLat, lon: EXIT_LON },
        { lat: centerLat, lon: MERGE_LON },
      ],
    },
    {
      id: 'hwy-east',
      label: 'Post-Merge',
      currentSpeed,
      freeFlowSpeed,
      congestionLevel,
      coordinates: [
        { lat: centerLat, lon: MERGE_LON },
        { lat: centerLat, lon: MERGE_LON + 0.010 },
      ],
    },
  ];
}

function generateSimulatedSegments(centerLat = 32.7767, centerLon = -96.7980) {
  const HWY_LAT = centerLat;
  const EXIT_LON = centerLon - 0.008;
  const MERGE_LON = centerLon;

  return [
    {
      id: 'hwy-west',
      label: 'I-35E Westbound Approach',
      currentSpeed: 62,
      freeFlowSpeed: 70,
      congestionLevel: 'free',
      coordinates: [
        { lat: HWY_LAT, lon: EXIT_LON - 0.010 },
        { lat: HWY_LAT, lon: EXIT_LON },
      ],
    },
    {
      id: 'hwy-merge',
      label: 'I-35E Merge Zone',
      currentSpeed: 38,
      freeFlowSpeed: 70,
      congestionLevel: 'heavy',
      coordinates: [
        { lat: HWY_LAT, lon: EXIT_LON },
        { lat: HWY_LAT, lon: MERGE_LON },
      ],
    },
    {
      id: 'hwy-east',
      label: 'I-35E Eastbound Post-Merge',
      currentSpeed: 55,
      freeFlowSpeed: 70,
      congestionLevel: 'moderate',
      coordinates: [
        { lat: HWY_LAT, lon: MERGE_LON },
        { lat: HWY_LAT, lon: MERGE_LON + 0.010 },
      ],
    },
    {
      id: 'ramp-entry',
      label: 'Exit 42 On-Ramp',
      currentSpeed: 25,
      freeFlowSpeed: 45,
      congestionLevel: 'heavy',
      coordinates: [
        { lat: HWY_LAT, lon: EXIT_LON },
        { lat: HWY_LAT - 0.0015, lon: EXIT_LON + 0.002 },
        { lat: HWY_LAT - 0.0018, lon: EXIT_LON + 0.004 },
        { lat: HWY_LAT - 0.0010, lon: EXIT_LON + 0.006 },
        { lat: HWY_LAT, lon: MERGE_LON },
      ],
    },
  ];
}