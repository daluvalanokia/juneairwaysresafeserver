import { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import PageHeader from '@/components/shared/PageHeader';
import StatusBadge from '@/components/shared/StatusBadge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Plus, Edit2, Trash2, Camera, Radar, ScanLine } from 'lucide-react';
import BarcodeScanner from '@/components/shared/BarcodeScanner';

const EMPTY = { zone_id: '', highway_id: '', server_id: '', device_name: '', device_id: '', device_type: 'camera', source_type: 'physical', device_height: '', mile_marker: '', location_comment: '', latitude: '', longitude: '', status: 'online', firmware_version: '', notes: '' };

const DEVICE_ICONS = {
  camera: Camera,
  lidar: Radar,
  radar: Radar,
};

const TYPE_COLORS = {
  camera: 'text-primary border-primary/30 bg-primary/10',
  lidar: 'text-accent border-accent/30 bg-accent/10',
  radar: 'text-yellow-400 border-yellow-500/30 bg-yellow-500/10',
};

export default function Sensors({ selectedHighway }) {
  const [sensors, setSensors] = useState([]);
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState(EMPTY);
  const [editing, setEditing] = useState(null);
  const [filterType, setFilterType] = useState('all');
  const [scanning, setScanning] = useState(false);

  const handleScan = (raw) => {
    setScanning(false);
    try {
      const parsed = JSON.parse(raw);
      setForm(p => ({ ...p, ...parsed }));
    } catch {
      setForm(p => ({ ...p, device_id: raw }));
    }
  };

  const load = () => {
    const filter = selectedHighway ? { highway_id: selectedHighway } : {};
    base44.entities.SensorDevice.filter(filter).then(setSensors);
  };

  useEffect(() => { load(); }, [selectedHighway]);

  const save = async () => {
    const data = { ...form, highway_id: form.highway_id || selectedHighway };
    if (editing) await base44.entities.SensorDevice.update(editing, data);
    else await base44.entities.SensorDevice.create(data);
    setOpen(false); setEditing(null); setForm(EMPTY); load();
  };

  const del = async (id) => { await base44.entities.SensorDevice.delete(id); load(); };
  const openEdit = (s) => { setForm({ ...s }); setEditing(s.id); setOpen(true); };
  const openNew = () => { setForm({ ...EMPTY, highway_id: selectedHighway || '' }); setEditing(null); setOpen(true); };

  const displayed = filterType === 'all' ? sensors : sensors.filter(s => s.device_type === filterType);

  return (
    <div>
      <PageHeader title="Sensor Devices" subtitle="Camera, LiDAR, and Radar hardware configuration">
        <div className="flex gap-2">
          <Select value={filterType} onValueChange={setFilterType}>
            <SelectTrigger className="h-8 w-32 text-xs bg-secondary border-border"><SelectValue /></SelectTrigger>
            <SelectContent>
              {['all','camera','lidar','radar','vehicle tag reader','signal receiver'].map(t => <SelectItem key={t} value={t} className="text-xs">{t === 'all' ? 'All Types' : t}</SelectItem>)}
            </SelectContent>
          </Select>
          <Button onClick={openNew} size="sm" className="gap-2">
            <Plus className="w-4 h-4" /> Add Sensor
          </Button>
        </div>
      </PageHeader>

      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
        {displayed.map(s => {
          const Icon = DEVICE_ICONS[s.device_type] || Camera;
          return (
            <div key={s.id} className="rounded-xl border border-border bg-card p-4">
              <div className="flex items-start justify-between mb-3">
                <div className="flex items-center gap-2">
                  <div className={`w-8 h-8 rounded-lg border flex items-center justify-center ${TYPE_COLORS[s.device_type]}`}>
                    <Icon className="w-4 h-4" />
                  </div>
                  <div>
                    <p className="font-semibold text-foreground text-sm">{s.device_name}</p>
                    <p className="text-xs text-muted-foreground font-mono">{s.device_id}</p>
                  </div>
                </div>
                <StatusBadge status={s.status} />
              </div>
              <div className="space-y-1 text-xs text-muted-foreground mb-4">
                <div className="flex justify-between">
                  <span>Type</span><span className="font-mono text-foreground uppercase">{s.device_type}</span>
                </div>
                {s.source_type && (
                  <div className="flex justify-between">
                    <span>Source</span><span className="font-mono text-foreground capitalize">{s.source_type}</span>
                  </div>
                )}
                <div className="flex justify-between">
                  <span>Height</span><span className="font-mono text-foreground">{s.device_height ?? '—'}m</span>
                </div>
                <div className="flex justify-between">
                  <span>Coords</span><span className="font-mono text-foreground">{s.latitude}, {s.longitude}</span>
                </div>
                <div className="flex justify-between">
                  <span>Server</span><span className="font-mono text-foreground">{s.server_id || '—'}</span>
                </div>
                <div className="flex justify-between">
                  <span>Mile Marker</span><span className="font-mono text-foreground">{s.mile_marker ?? '—'}</span>
                </div>
                {s.location_comment && (
                  <div className="flex justify-between">
                    <span>Location</span><span className="font-mono text-foreground text-right max-w-[150px] truncate">{s.location_comment}</span>
                  </div>
                )}
                <div className="flex justify-between">
                  <span>Zone</span><span className="font-mono text-foreground">{s.zone_id}</span>
                </div>
              </div>
              <div className="flex gap-2">
                <Button variant="outline" size="sm" className="flex-1 gap-1" onClick={() => openEdit(s)}>
                  <Edit2 className="w-3 h-3" /> Edit
                </Button>
                <Button variant="outline" size="sm" className="text-destructive hover:text-destructive" onClick={() => del(s.id)}>
                  <Trash2 className="w-3 h-3" />
                </Button>
              </div>
            </div>
          );
        })}
        {displayed.length === 0 && (
          <div className="col-span-3 text-center py-16 text-muted-foreground">
            {selectedHighway ? 'No sensors configured.' : 'Select a highway to view sensors.'}
          </div>
        )}
      </div>

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="max-w-lg max-h-[90vh] overflow-y-auto">
          <DialogHeader><DialogTitle>{editing ? 'Edit Sensor Device' : 'New Sensor Device'}</DialogTitle></DialogHeader>
          {scanning ? (
            <BarcodeScanner onScan={handleScan} onClose={() => setScanning(false)} />
          ) : (
            <>
              <Button variant="outline" size="sm" className="gap-2 w-full border-dashed" onClick={() => setScanning(true)}>
                <ScanLine className="w-4 h-4 text-primary" /> Scan This Device
              </Button>
              <div className="grid grid-cols-2 gap-3">
                {[
                  ['device_name','Device Name','text'],
                  ['device_id','Device ID','text'],
                  ['zone_id','Zone ID','text'],
                  ['server_id','Server ID','text'],
                  ['highway_id','Highway ID','text'],
                  ['device_height','Height (m)','number'],
                  ['latitude','Latitude','number'],
                  ['longitude','Longitude','number'],
                  ['mile_marker','Mile Marker','number'],
                  ['firmware_version','Firmware','text'],
                  ].map(([key, label, type]) => (
                  <div key={key} className={['device_name','device_id'].includes(key) ? 'col-span-2' : ''}>
                    <Label className="text-xs">{label}</Label>
                    <Input type={type} value={form[key] || ''} onChange={e => setForm(p => ({ ...p, [key]: e.target.value }))} className="mt-1 h-8 text-sm" />
                  </div>
                ))}
                <div>
                  <Label className="text-xs">Device Type</Label>
                  <Select value={form.device_type} onValueChange={v => setForm(p => ({ ...p, device_type: v }))}>
                    <SelectTrigger className="mt-1 h-8 text-sm"><SelectValue /></SelectTrigger>
                    <SelectContent>
                      {['camera','lidar','radar','vehicle tag reader','signal receiver'].map(t => <SelectItem key={t} value={t}>{t}</SelectItem>)}
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label className="text-xs">Source Type</Label>
                  <Select value={form.source_type} onValueChange={v => setForm(p => ({ ...p, source_type: v }))}>
                    <SelectTrigger className="mt-1 h-8 text-sm"><SelectValue /></SelectTrigger>
                    <SelectContent>
                      {['physical','satellite','telecom','tracker'].map(t => <SelectItem key={t} value={t} className="capitalize">{t}</SelectItem>)}
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label className="text-xs">Status</Label>
                  <Select value={form.status} onValueChange={v => setForm(p => ({ ...p, status: v }))}>
                    <SelectTrigger className="mt-1 h-8 text-sm"><SelectValue /></SelectTrigger>
                    <SelectContent>
                      {['online','offline','fault','calibrating'].map(s => <SelectItem key={s} value={s}>{s}</SelectItem>)}
                    </SelectContent>
                  </Select>
                </div>
                <div className="col-span-2">
                  <Label className="text-xs">Location Comment</Label>
                  <Input value={form.location_comment || ''} onChange={e => setForm(p => ({ ...p, location_comment: e.target.value }))} className="mt-1 h-8 text-sm" />
                </div>
                <div className="col-span-2">
                  <Label className="text-xs">Notes</Label>
                  <Input value={form.notes || ''} onChange={e => setForm(p => ({ ...p, notes: e.target.value }))} className="mt-1 h-8 text-sm" />
                </div>
              </div>
              <div className="flex justify-end gap-2 pt-2">
                <Button variant="outline" size="sm" onClick={() => setOpen(false)}>Cancel</Button>
                <Button size="sm" onClick={save}>{editing ? 'Save' : 'Create'}</Button>
              </div>
            </>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}