import { useState, useEffect, useRef } from 'react';
import { base44 } from '@/api/base44Client';
import { Radio, Lock, User, Route, Eye, EyeOff, AlertCircle, Box } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Label } from '@/components/ui/label';
import { useNavigate } from 'react-router-dom';

export default function Portal() {
  const [userId, setUserId] = useState('');
  const [password, setPassword] = useState('');
  const [highwayId, setHighwayId] = useState('');
  const highwayIdRef = useRef('');
  const [highways, setHighways] = useState([]);
  const [showPass, setShowPass] = useState(false);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();

  useEffect(() => {
    const session = localStorage.getItem('mss_portal_session');
    if (session) navigate('/traffic3d');
    base44.entities.Highway.list().then(setHighways);
  }, []);

  const handleHighwayChange = (v) => {
    highwayIdRef.current = v;
    setHighwayId(v);
    setError('');
  };

  const handleLogin = async (e) => {
    e.preventDefault();
    const trimmedUserId = userId.trim();
    const trimmedHighwayId = (highwayIdRef.current || highwayId).trim();
    if (!trimmedUserId || !trimmedHighwayId) {
      setError('User ID and Interstate are required.');
      return;
    }
    setLoading(true);
    setError('');
    try {
      const profiles = await base44.entities.UserProfile.filter({ highway_id: trimmedHighwayId });
      const match = profiles.find(p => p.user_id?.toLowerCase() === trimmedUserId.toLowerCase());
      if (!match) {
        setError('User ID not found for the selected interstate.');
        setLoading(false);
        return;
      }
      // Blank password always passes; if a password is set, verify it
      if (match.password && match.password !== password) {
        setError('Incorrect password.');
        setLoading(false);
        return;
      }
      const hw = highways.find(h => h.highway_id === trimmedHighwayId);
      localStorage.setItem('mss_portal_session', JSON.stringify({
        user: match,
        highway: hw,
        loginTime: Date.now(),
      }));
      navigate('/traffic3d');
    } catch {
      setError('Sign-in failed. Please try again.');
    }
    setLoading(false);
  };

  return (
    <div className="min-h-screen bg-background flex items-center justify-center p-4 relative overflow-hidden">
      {/* Background grid */}
      <div className="fixed inset-0 bg-[linear-gradient(rgba(59,130,246,0.03)_1px,transparent_1px),linear-gradient(90deg,rgba(59,130,246,0.03)_1px,transparent_1px)] bg-[size:40px_40px] pointer-events-none" />
      {/* Glow blobs */}
      <div className="fixed top-[-200px] left-[-200px] w-[500px] h-[500px] rounded-full bg-primary/5 blur-3xl pointer-events-none" />
      <div className="fixed bottom-[-200px] right-[-200px] w-[500px] h-[500px] rounded-full bg-blue-500/5 blur-3xl pointer-events-none" />

      <div className="w-full max-w-md relative z-10">
        {/* Brand */}
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-primary/10 border border-primary/30 mb-4 shadow-lg">
            <div className="relative">
              <div className="w-7 h-7 rounded-full bg-primary/30 animate-ping absolute inset-0 m-auto" />
              <Box className="w-7 h-7 text-primary relative" />
            </div>
          </div>
          <h1 className="text-2xl font-bold tracking-tight">MergeSafeServer</h1>
          <p className="text-sm text-muted-foreground mt-1">Highway Control Platform</p>
        </div>

        {/* Card */}
        <div className="bg-card border border-border rounded-2xl shadow-2xl p-8">
          <div className="flex items-center gap-2 mb-6 pb-4 border-b border-border">
            <Radio className="w-3.5 h-3.5 text-green-400 animate-pulse" />
            <span className="text-xs font-mono text-muted-foreground">OPERATOR PORTAL ACCESS</span>
            <span className="ml-auto w-2 h-2 rounded-full bg-green-400 animate-pulse" />
          </div>

          <form onSubmit={handleLogin} className="space-y-5">
            {/* User ID */}
            <div className="space-y-1.5">
              <Label className="text-xs font-semibold">User ID</Label>
              <div className="relative">
                <User className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground pointer-events-none" />
                <Input
                  value={userId}
                  onChange={e => { setUserId(e.target.value); setError(''); }}
                  placeholder="USR-I20-001"
                  className="pl-9 font-mono"
                  autoFocus
                />
              </div>
            </div>

            {/* Interstate */}
            <div className="space-y-1.5">
              <Label className="text-xs font-semibold">Interstate Assignment</Label>
              <div className="relative">
                <Route className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground z-10 pointer-events-none" />
                <Select value={highwayId} onValueChange={handleHighwayChange}>
                  <SelectTrigger className="pl-9">
                    <SelectValue placeholder="Select your interstate..." />
                  </SelectTrigger>
                  <SelectContent>
                    {highways.map(h => (
                      <SelectItem key={h.highway_id} value={h.highway_id}>
                        {h.name} — {h.state}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>

            {/* Password */}
            <div className="space-y-1.5">
              <Label className="text-xs font-semibold">
                Password{' '}
                <span className="text-muted-foreground font-normal">(leave blank if not set)</span>
              </Label>
              <div className="relative">
                <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground pointer-events-none" />
                <Input
                  type={showPass ? 'text' : 'password'}
                  value={password}
                  onChange={e => { setPassword(e.target.value); setError(''); }}
                  placeholder="••••••••"
                  className="pl-9 pr-9"
                />
                <button
                  type="button"
                  onClick={() => setShowPass(s => !s)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground transition-colors"
                >
                  {showPass ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>

            {/* Error */}
            {error && (
              <div className="flex items-center gap-2 text-destructive text-xs bg-destructive/10 border border-destructive/20 rounded-lg px-3 py-2.5">
                <AlertCircle className="w-3.5 h-3.5 flex-shrink-0" />
                {error}
              </div>
            )}

            <Button type="submit" className="w-full gap-2" disabled={loading}>
              {loading ? (
                <><span className="w-3.5 h-3.5 border-2 border-primary-foreground/30 border-t-primary-foreground rounded-full animate-spin" /> Signing in...</>
              ) : (
                <><Box className="w-4 h-4" /> Access Traffic Map</>
              )}
            </Button>
          </form>

          <p className="mt-5 text-[11px] text-muted-foreground font-mono text-center">
            Authorized personnel only · MergeSafeServer v1.0
          </p>
        </div>

        {/* Demo hint */}
        <div className="mt-4 bg-muted/40 border border-border rounded-xl px-4 py-3 text-center">
          <p className="text-[11px] text-muted-foreground font-mono">
            Demo — ID: <span className="text-primary font-semibold">USR-I20-001</span> ·
            Interstate: <span className="text-primary font-semibold">Interstate 20</span> ·
            Password: <span className="text-primary font-semibold">blank</span>
          </p>
        </div>
      </div>
    </div>
  );
}