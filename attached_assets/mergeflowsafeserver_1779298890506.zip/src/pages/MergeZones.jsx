import { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import PageHeader from '@/components/shared/PageHeader';
import StatusBadge from '@/components/shared/StatusBadge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Plus, Edit2, Trash2, MapPin } from 'lucide-react';

const EMPTY = { highway_id: '', zone_name: '', zone_id: '', mile_marker: '', latitude: '', longitude: '', status: 'active', geofence_radius: 500 };

export default function MergeZones({ selectedHighway }) {
  const [zones, setZones] = useState([]);
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState(EMPTY);
  const [editing, setEditing] = useState(null);

  const load = () => {
    const filter = selectedHighway ? { highway_id: selectedHighway } : {};
    base44.entities.MergeZone.filter(filter).then(setZones);
  };

  useEffect(() => { load(); }, [selectedHighway]);

  const save = async () => {
    const data = { ...form, highway_id: form.highway_id || selectedHighway };
    if (editing) await base44.entities.MergeZone.update(editing, data);
    else await base44.entities.MergeZone.create(data);
    setOpen(false); setEditing(null); setForm(EMPTY); load();
  };

  const del = async (id) => {
    await base44.entities.MergeZone.delete(id); load();
  };

  const openEdit = (z) => { setForm({ ...z }); setEditing(z.id); setOpen(true); };
  const openNew = () => { setForm({ ...EMPTY, highway_id: selectedHighway || '' }); setEditing(null); setOpen(true); };

  return (
    <div>
      <PageHeader title="Merge Zones" subtitle="Configure and monitor autonomous merge zones">
        <Button onClick={openNew} size="sm" className="gap-2">
          <Plus className="w-4 h-4" /> Add Zone
        </Button>
      </PageHeader>

      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
        {zones.map(z => (
          <div key={z.id} className="rounded-xl border border-border bg-card p-4">
            <div className="flex items-start justify-between mb-3">
              <div>
                <p className="font-semibold text-foreground">{z.zone_name}</p>
                <p className="text-xs text-muted-foreground font-mono">{z.zone_id}</p>
              </div>
              <StatusBadge status={z.status} />
            </div>
            <div className="space-y-1 text-xs text-muted-foreground mb-4">
              <div className="flex items-center gap-1"><MapPin className="w-3 h-3" /> MM {z.mile_marker} · Geofence {z.geofence_radius}m</div>
              <div className="font-mono">Lat {z.latitude} / Lon {z.longitude}</div>
              <div className="font-mono">Highway: {z.highway_id}</div>
            </div>
            <div className="flex gap-2">
              <Button variant="outline" size="sm" className="flex-1 gap-1" onClick={() => openEdit(z)}>
                <Edit2 className="w-3 h-3" /> Edit
              </Button>
              <Button variant="outline" size="sm" className="text-destructive hover:text-destructive" onClick={() => del(z.id)}>
                <Trash2 className="w-3 h-3" />
              </Button>
            </div>
          </div>
        ))}
        {zones.length === 0 && (
          <div className="col-span-3 text-center py-16 text-muted-foreground">
            {selectedHighway ? 'No merge zones configured for this highway.' : 'Select a highway to view zones.'}
          </div>
        )}
      </div>

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="max-w-lg">
          <DialogHeader><DialogTitle>{editing ? 'Edit Merge Zone' : 'New Merge Zone'}</DialogTitle></DialogHeader>
          <div className="grid grid-cols-2 gap-3">
            {[
              ['zone_name', 'Zone Name', 'text'],
              ['zone_id', 'Zone ID', 'text'],
              ['highway_id', 'Highway ID', 'text'],
              ['mile_marker', 'Mile Marker', 'number'],
              ['latitude', 'Latitude', 'number'],
              ['longitude', 'Longitude', 'number'],
              ['geofence_radius', 'Geofence Radius (m)', 'number'],
            ].map(([key, label, type]) => (
              <div key={key} className={key === 'zone_name' ? 'col-span-2' : ''}>
                <Label className="text-xs">{label}</Label>
                <Input type={type} value={form[key] || ''} onChange={e => setForm(p => ({ ...p, [key]: e.target.value }))} className="mt-1 h-8 text-sm" />
              </div>
            ))}
            <div>
              <Label className="text-xs">Status</Label>
              <Select value={form.status} onValueChange={v => setForm(p => ({ ...p, status: v }))}>
                <SelectTrigger className="mt-1 h-8 text-sm"><SelectValue /></SelectTrigger>
                <SelectContent>
                  {['active','inactive','fault','maintenance'].map(s => <SelectItem key={s} value={s}>{s}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
          </div>
          <div className="flex justify-end gap-2 pt-2">
            <Button variant="outline" size="sm" onClick={() => setOpen(false)}>Cancel</Button>
            <Button size="sm" onClick={save}>{editing ? 'Save' : 'Create'}</Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}