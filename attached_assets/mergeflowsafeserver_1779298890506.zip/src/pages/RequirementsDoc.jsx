import { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { FileText, Download, Loader2, CheckCircle2 } from 'lucide-react';
import PageHeader from '@/components/shared/PageHeader';

export default function RequirementsDoc() {
  const [loading, setLoading] = useState(false);
  const [done, setDone] = useState(false);
  const [error, setError] = useState(null);

  const generate = async () => {
    setLoading(true);
    setDone(false);
    setError(null);
    try {
      // Use axios-based SDK invoke but treat raw response as blob
      const axiosRes = await base44.functions.invoke('generateRequirementsDoc', {}, { responseType: 'arraybuffer' });
      const blob = new Blob([axiosRes.data], { type: 'application/pdf' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = 'MergeSafeServer_Requirements_v1.0.pdf';
      a.click();
      URL.revokeObjectURL(url);
      setDone(true);
      setTimeout(() => setDone(false), 3000);
    } catch (e) {
      setError(e.message);
    }
    setLoading(false);
  };

  return (
    <div>
      <PageHeader
        title="Requirements Document"
        subtitle="Generate a comprehensive PDF design and requirements specification"
      />

      <div className="max-w-2xl">
        <div className="rounded-xl border border-border bg-card p-6 space-y-5">
          {/* Icon + description */}
          <div className="flex items-start gap-4">
            <div className="w-12 h-12 rounded-xl bg-primary/10 border border-primary/20 flex items-center justify-center flex-shrink-0">
              <FileText className="w-6 h-6 text-primary" />
            </div>
            <div>
              <h2 className="font-semibold text-sm">MergeSafeServer — Software Requirements Document</h2>
              <p className="text-xs text-muted-foreground mt-1 leading-relaxed">
                A detailed PDF covering all modules, UI field definitions, database entity schemas,
                module interactions, sequence diagrams, design system tokens, and security model.
              </p>
            </div>
          </div>

          {/* Contents list */}
          <div className="rounded-lg border border-border bg-secondary/30 px-4 py-3">
            <p className="text-xs font-semibold text-muted-foreground mb-2 uppercase tracking-wider">Document Contents</p>
            <ul className="space-y-1">
              {[
                'System Overview & Technology Stack',
                'Application Layout & Navigation Design',
                'All 10 Module Specifications (UI fields, forms, logic)',
                'Complete Database Schema — 9 Entities with all fields',
                'Entity Relationship Diagram',
                'Backend Functions Reference',
                '7 Sequence Diagrams (bootstrap, CRUD, payload gen, etc.)',
                'UI Design System — Colors, Typography, Components',
                'Security & Access Control Model',
              ].map((item, i) => (
                <li key={i} className="flex items-center gap-2 text-xs text-foreground">
                  <span className="w-4 h-4 rounded-full bg-primary/10 text-primary text-[9px] flex items-center justify-center font-bold flex-shrink-0">{i + 1}</span>
                  {item}
                </li>
              ))}
            </ul>
          </div>

          {/* Error */}
          {error && (
            <p className="text-xs text-destructive bg-destructive/10 rounded-lg px-3 py-2">{error}</p>
          )}

          {/* CTA */}
          <Button
            onClick={generate}
            disabled={loading}
            className="gap-2 w-full"
            size="lg"
          >
            {loading ? (
              <><Loader2 className="w-4 h-4 animate-spin" /> Generating PDF…</>
            ) : done ? (
              <><CheckCircle2 className="w-4 h-4 text-green-400" /> Downloaded!</>
            ) : (
              <><Download className="w-4 h-4" /> Generate & Download PDF</>
            )}
          </Button>

          <p className="text-[10px] text-muted-foreground text-center">
            ~25–30 pages · PDF format · Generated server-side
          </p>
        </div>
      </div>
    </div>
  );
}