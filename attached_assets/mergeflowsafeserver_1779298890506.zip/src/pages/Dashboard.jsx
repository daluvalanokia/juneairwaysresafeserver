import { useState, useEffect, useCallback } from 'react';
import { base44 } from '@/api/base44Client';
import StatCard from '@/components/shared/StatCard';
import StatusBadge from '@/components/shared/StatusBadge';
import PageHeader from '@/components/shared/PageHeader';
import { Button } from '@/components/ui/button';
import { Cpu, Radio, Map, Activity, AlertTriangle, CheckCircle, Zap, X } from 'lucide-react';
import { Link } from 'react-router-dom';
import HighwayMap from '@/components/dashboard/HighwayMap';
import DemoMap from '@/components/dashboard/DemoMap';

const EVENT_COLORS = {
  detection: 'text-blue-400',
  merge:      'text-green-400',
  conflict:   'text-red-400',
  speeding:   'text-yellow-400',
  fault:      'text-red-400',
};

export default function Dashboard({ selectedHighway }) {
  const [zones, setZones] = useState([]);
  const [servers, setServers] = useState([]);
  const [sensors, setSensors] = useState([]);
  const [events, setEvents] = useState([]);
  const [loading, setLoading] = useState(true);
  const [demoMode, setDemoMode] = useState(false);
  const [demoEvents, setDemoEvents] = useState([]);

  useEffect(() => {
    const filter = selectedHighway ? { highway_id: selectedHighway } : {};
    Promise.all([
      base44.entities.MergeZone.filter(filter),
      base44.entities.SwitchServer.filter(filter),
      base44.entities.SensorDevice.filter(filter),
      base44.entities.VehicleEvent.filter(filter, '-created_date', 20),
    ]).then(([z, sv, se, ev]) => {
      setZones(z); setServers(sv); setSensors(se); setEvents(ev);
    }).finally(() => setLoading(false));
  }, [selectedHighway]);

  const handleDemoEvent = useCallback((vehicle) => {
    const entry = {
      id: `${vehicle.id}-${Date.now()}`,
      vehicle_id: vehicle.id,
      event_type: vehicle.event_type,
      speed_mph: vehicle.speed,
      zone_id: 'DEMO-MZ-001',
      timestamp: new Date().toLocaleTimeString(),
    };
    setDemoEvents(prev => [entry, ...prev].slice(0, 30));
  }, []);

  const faultZones = zones.filter(z => z.status === 'fault').length;
  const onlineServers = servers.filter(s => s.status === 'online').length;
  const onlineSensors = sensors.filter(s => s.status === 'online').length;
  const recentFaults = events.filter(e => e.event_type === 'fault' || e.event_type === 'conflict').length;

  if (loading) return (
    <div className="flex items-center justify-center h-64">
      <div className="w-8 h-8 border-4 border-primary/20 border-t-primary rounded-full animate-spin" />
    </div>
  );

  return (
    <div>
      <PageHeader
        title="System Overview"
        subtitle={selectedHighway ? `Monitoring: ${selectedHighway}` : 'Select a highway to begin monitoring'}
      >
        <Button
          size="sm"
          variant={demoMode ? 'destructive' : 'outline'}
          className="gap-2 font-mono text-xs"
          onClick={() => { setDemoMode(d => !d); setDemoEvents([]); }}
        >
          <Zap className="w-3.5 h-3.5" />
          {demoMode ? 'EXIT DEMO' : 'DEMO'}
        </Button>
      </PageHeader>

      {/* Stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        <StatCard label="Merge Zones" value={zones.length} icon={Map} color={faultZones > 0 ? 'destructive' : 'accent'} trend={faultZones > 0 ? `${faultZones} in fault` : 'All operational'} />
        <StatCard label="Switch Servers" value={`${onlineServers}/${servers.length}`} icon={Cpu} color={onlineServers === servers.length ? 'accent' : 'warning'} trend="Online / Total" />
        <StatCard label="Sensor Devices" value={`${onlineSensors}/${sensors.length}`} icon={Radio} color={onlineSensors === sensors.length ? 'accent' : 'warning'} trend="Online / Total" />
        <StatCard label="Recent Alerts" value={recentFaults} icon={AlertTriangle} color={recentFaults > 0 ? 'destructive' : 'muted'} trend="Last 20 events" />
      </div>

      {/* Map panel */}
      <div className="rounded-xl border border-border bg-card p-4 mb-4">
        <div className="flex items-center justify-between mb-3">
          <h2 className="text-sm font-semibold text-foreground flex items-center gap-2">
            <Map className="w-4 h-4 text-primary" />
            {demoMode ? (
              <span className="flex items-center gap-2">
                Demo — Merge Zone Alpha
                <span className="text-xs font-mono text-yellow-400 animate-pulse">● LIVE SIM</span>
              </span>
            ) : 'Highway Layout'}
          </h2>
          <div className="flex items-center gap-4 text-xs text-muted-foreground font-mono">
            {demoMode ? (
              <>
                <span className="flex items-center gap-1"><span className="w-2.5 h-2.5 rounded-full bg-blue-400 inline-block" /> Detection</span>
                <span className="flex items-center gap-1"><span className="w-2.5 h-2.5 rounded-full bg-green-400 inline-block" /> Merge</span>
                <span className="flex items-center gap-1"><span className="w-2.5 h-2.5 rounded-full bg-red-400 inline-block" /> Conflict</span>
                <span className="flex items-center gap-1"><span className="w-2.5 h-2.5 rounded-full bg-yellow-400 inline-block" /> Speeding</span>
              </>
            ) : (
              <>
                <span className="flex items-center gap-1"><span className="w-2.5 h-2.5 rounded-full bg-green-500 inline-block" /> Zone Active</span>
                <span className="flex items-center gap-1"><span className="w-2.5 h-2.5 rounded-full bg-red-500 inline-block" /> Zone Fault</span>
                <span className="flex items-center gap-1"><span className="w-2 h-2 rounded-full bg-blue-500 inline-block" /> Camera</span>
                <span className="flex items-center gap-1"><span className="w-2 h-2 rounded-full bg-green-400 inline-block" /> LiDAR</span>
                <span className="flex items-center gap-1"><span className="w-2 h-2 rounded-full bg-yellow-400 inline-block" /> Radar</span>
              </>
            )}
          </div>
        </div>

        {demoMode && (
          <div className="mb-2 text-xs text-muted-foreground font-mono flex flex-wrap gap-4 px-1">
            <span className="flex items-center gap-1.5"><span className="w-3 h-3 rounded-sm inline-block" style={{background:'#f97316'}} /> SW-1 Switch Server</span>
            <span className="flex items-center gap-1.5"><span className="w-3 h-3 rounded-sm inline-block" style={{background:'#a78bfa'}} /> SW-2 Switch Server</span>
            <span className="flex items-center gap-1.5"><span className="w-3 h-3 rounded-sm inline-block" style={{background:'#fb7185'}} /> SW-3 Switch Server</span>
            <span className="flex items-center gap-1.5 text-muted-foreground">Dashed lines = triangulation signal paths</span>
          </div>
        )}

        <div style={{ height: '380px' }}>
          {demoMode
            ? <DemoMap onEventGenerated={handleDemoEvent} />
            : <HighwayMap zones={zones} sensors={sensors} />
          }
        </div>
      </div>

      {/* Demo event feed + zone list */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <div className="rounded-xl border border-border bg-card p-4">
          <h2 className="text-sm font-semibold text-foreground mb-3 flex items-center gap-2">
            <Map className="w-4 h-4 text-primary" /> Merge Zones
          </h2>
          {zones.length === 0 ? (
            <p className="text-sm text-muted-foreground text-center py-8">{selectedHighway ? 'No zones configured' : 'Select a highway'}</p>
          ) : (
            <div className="space-y-2">
              {zones.map(z => (
                <Link key={z.id} to="/zones" className="flex items-center justify-between p-3 rounded-lg bg-secondary hover:bg-secondary/80 transition-colors">
                  <div>
                    <p className="text-sm font-medium text-foreground">{z.zone_name}</p>
                    <p className="text-xs text-muted-foreground font-mono">{z.zone_id} · MM {z.mile_marker}</p>
                  </div>
                  <StatusBadge status={z.status} />
                </Link>
              ))}
            </div>
          )}
        </div>

        <div className="rounded-xl border border-border bg-card p-4">
          <h2 className="text-sm font-semibold text-foreground mb-3 flex items-center gap-2">
            <Activity className="w-4 h-4 text-primary" />
            {demoMode ? 'Demo Event Feed' : 'Recent Events'}
            {demoMode && demoEvents.length > 0 && (
              <span className="ml-auto text-xs font-mono text-yellow-400 animate-pulse">● LIVE</span>
            )}
          </h2>
          {demoMode ? (
            demoEvents.length === 0 ? (
              <p className="text-sm text-muted-foreground text-center py-8 animate-pulse">Waiting for vehicles...</p>
            ) : (
              <div className="space-y-1.5 max-h-64 overflow-y-auto">
                {demoEvents.map(e => (
                  <div key={e.id} className="flex items-center justify-between p-2 rounded-lg bg-secondary text-xs font-mono">
                    <div className="flex items-center gap-2">
                      <span className={`font-semibold ${EVENT_COLORS[e.event_type]}`}>{e.event_type?.toUpperCase()}</span>
                      <span className="text-muted-foreground">{e.vehicle_id}</span>
                    </div>
                    <div className="flex items-center gap-3 text-muted-foreground">
                      <span>{e.speed_mph} mph</span>
                      <span>{e.timestamp}</span>
                    </div>
                  </div>
                ))}
              </div>
            )
          ) : (
            events.length === 0 ? (
              <p className="text-sm text-muted-foreground text-center py-8">No recent events</p>
            ) : (
              <div className="space-y-2 max-h-64 overflow-y-auto">
                {events.map(e => (
                  <div key={e.id} className="flex items-center justify-between p-2 rounded-lg bg-secondary">
                    <div className="flex items-center gap-2">
                      {e.event_type === 'fault' || e.event_type === 'conflict'
                        ? <AlertTriangle className="w-3.5 h-3.5 text-destructive" />
                        : <CheckCircle className="w-3.5 h-3.5 text-accent" />
                      }
                      <span className="text-xs text-foreground font-mono">{e.event_type?.toUpperCase()}</span>
                    </div>
                    <span className="text-xs text-muted-foreground font-mono">{e.zone_id}</span>
                  </div>
                ))}
              </div>
            )
          )}
        </div>
      </div>
    </div>
  );
}