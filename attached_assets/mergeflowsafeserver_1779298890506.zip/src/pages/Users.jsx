import { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { Plus, Pencil, Trash2, User, MapPin, Phone, Shield, Radio, X, Check } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';

const USER_TYPES = ['admin', 'operator', 'viewer', 'technician', 'supervisor'];

const TYPE_COLORS = {
  admin:      'bg-red-500/15 text-red-400 border-red-500/25',
  operator:   'bg-blue-500/15 text-blue-400 border-blue-500/25',
  viewer:     'bg-slate-500/15 text-slate-400 border-slate-500/25',
  technician: 'bg-yellow-500/15 text-yellow-400 border-yellow-500/25',
  supervisor: 'bg-purple-500/15 text-purple-400 border-purple-500/25',
};

const DEVICE_TYPE_COLORS = {
  camera: 'text-blue-400',
  lidar:  'text-purple-400',
  radar:  'text-amber-400',
};

const EMPTY_FORM = {
  user_id: '', full_name: '', address: '', phone: '',
  user_type: 'viewer', highway_id: '', highway_name: '',
  device_ids: [], device_names: [], notes: '', is_active: true,
};

export default function Users() {
  const [users, setUsers] = useState([]);
  const [highways, setHighways] = useState([]);
  const [devices, setDevices] = useState([]);
  const [filteredDevices, setFilteredDevices] = useState([]);
  const [form, setForm] = useState(EMPTY_FORM);
  const [editingId, setEditingId] = useState(null);
  const [open, setOpen] = useState(false);
  const [search, setSearch] = useState('');
  const [deviceSearch, setDeviceSearch] = useState('');

  useEffect(() => {
    load();
    base44.entities.Highway.list().then(setHighways);
  }, []);

  const load = () => base44.entities.UserProfile.list('-created_date').then(setUsers);

  // When highway changes in form, load its devices
  useEffect(() => {
    if (!form.highway_id) { setDevices([]); setFilteredDevices([]); return; }
    base44.entities.SensorDevice.filter({ highway_id: form.highway_id })
      .then(devs => { setDevices(devs); setFilteredDevices(devs); });
  }, [form.highway_id]);

  // Filter devices by search
  useEffect(() => {
    if (!deviceSearch.trim()) { setFilteredDevices(devices); return; }
    const q = deviceSearch.toLowerCase();
    setFilteredDevices(devices.filter(d =>
      d.device_name?.toLowerCase().includes(q) ||
      d.device_id?.toLowerCase().includes(q) ||
      d.device_type?.toLowerCase().includes(q) ||
      String(d.mile_marker)?.includes(q)
    ));
  }, [deviceSearch, devices]);

  const openAdd = () => { setForm(EMPTY_FORM); setEditingId(null); setDeviceSearch(''); setOpen(true); };
  const openEdit = (u) => {
    setForm({ ...EMPTY_FORM, ...u });
    setEditingId(u.id);
    setDeviceSearch('');
    setOpen(true);
  };

  const handleHighwayChange = (hwId) => {
    const hw = highways.find(h => h.highway_id === hwId);
    setForm(f => ({ ...f, highway_id: hwId, highway_name: hw?.name || '', device_ids: [], device_names: [] }));
  };

  const toggleDevice = (device) => {
    setForm(f => {
      const already = f.device_ids.includes(device.device_id);
      if (already) {
        return {
          ...f,
          device_ids: f.device_ids.filter(id => id !== device.device_id),
          device_names: f.device_names.filter(n => n !== device.device_name),
        };
      }
      return {
        ...f,
        device_ids: [...f.device_ids, device.device_id],
        device_names: [...f.device_names, device.device_name],
      };
    });
  };

  const handleSave = async () => {
    if (!form.full_name.trim()) return;
    if (editingId) {
      await base44.entities.UserProfile.update(editingId, form);
    } else {
      await base44.entities.UserProfile.create(form);
    }
    setOpen(false);
    load();
  };

  const handleDelete = async (id) => {
    await base44.entities.UserProfile.delete(id);
    load();
  };

  const filtered = users.filter(u =>
    !search.trim() ||
    u.full_name?.toLowerCase().includes(search.toLowerCase()) ||
    u.user_id?.toLowerCase().includes(search.toLowerCase()) ||
    u.highway_name?.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="space-y-5">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-lg font-bold tracking-tight">Users</h1>
          <p className="text-xs text-muted-foreground mt-0.5">Manage user profiles and device access assignments</p>
        </div>
        <Button onClick={openAdd} size="sm" className="gap-1.5">
          <Plus className="w-4 h-4" /> Add User
        </Button>
      </div>

      {/* Search */}
      <Input
        placeholder="Search by name, ID, or highway..."
        value={search}
        onChange={e => setSearch(e.target.value)}
        className="max-w-sm text-sm"
      />

      {/* Table */}
      <div className="rounded-xl border border-border overflow-hidden">
        <table className="w-full text-sm">
          <thead>
            <tr className="border-b border-border bg-muted/40">
              <th className="text-left px-4 py-3 text-xs font-semibold text-muted-foreground">User</th>
              <th className="text-left px-4 py-3 text-xs font-semibold text-muted-foreground hidden md:table-cell">Phone</th>
              <th className="text-left px-4 py-3 text-xs font-semibold text-muted-foreground hidden lg:table-cell">Address</th>
              <th className="text-left px-4 py-3 text-xs font-semibold text-muted-foreground">Type</th>
              <th className="text-left px-4 py-3 text-xs font-semibold text-muted-foreground hidden md:table-cell">Interstate</th>
              <th className="text-left px-4 py-3 text-xs font-semibold text-muted-foreground hidden lg:table-cell">Devices</th>
              <th className="text-left px-4 py-3 text-xs font-semibold text-muted-foreground">Status</th>
              <th className="px-4 py-3" />
            </tr>
          </thead>
          <tbody className="divide-y divide-border">
            {filtered.length === 0 && (
              <tr>
                <td colSpan={8} className="px-4 py-10 text-center text-sm text-muted-foreground">
                  No users found. Click "Add User" to create one.
                </td>
              </tr>
            )}
            {filtered.map(u => (
              <tr key={u.id} className="hover:bg-muted/30 transition-colors">
                <td className="px-4 py-3">
                  <div className="flex items-center gap-2.5">
                    <div className="w-8 h-8 rounded-full bg-primary/10 border border-primary/20 flex items-center justify-center flex-shrink-0">
                      <User className="w-4 h-4 text-primary" />
                    </div>
                    <div>
                      <div className="font-medium text-sm">{u.full_name}</div>
                      {u.user_id && <div className="text-[11px] text-muted-foreground font-mono">{u.user_id}</div>}
                    </div>
                  </div>
                </td>
                <td className="px-4 py-3 text-xs text-muted-foreground hidden md:table-cell">
                  {u.phone || <span className="text-muted-foreground/40">—</span>}
                </td>
                <td className="px-4 py-3 text-xs text-muted-foreground hidden lg:table-cell max-w-[160px] truncate">
                  {u.address || <span className="text-muted-foreground/40">—</span>}
                </td>
                <td className="px-4 py-3">
                  <span className={`px-2 py-0.5 rounded-full text-[11px] font-semibold border capitalize ${TYPE_COLORS[u.user_type] || TYPE_COLORS.viewer}`}>
                    {u.user_type}
                  </span>
                </td>
                <td className="px-4 py-3 hidden md:table-cell">
                  {u.highway_name ? (
                    <div className="flex items-center gap-1">
                      <Radio className="w-3 h-3 text-primary" />
                      <span className="text-xs font-mono">{u.highway_name}</span>
                    </div>
                  ) : <span className="text-muted-foreground/40 text-xs">—</span>}
                </td>
                <td className="px-4 py-3 hidden lg:table-cell">
                  {u.device_ids?.length > 0 ? (
                    <span className="text-xs text-muted-foreground">{u.device_ids.length} device{u.device_ids.length > 1 ? 's' : ''}</span>
                  ) : <span className="text-muted-foreground/40 text-xs">—</span>}
                </td>
                <td className="px-4 py-3">
                  <div className={`flex items-center gap-1.5 text-[11px] font-mono ${u.is_active ? 'text-green-400' : 'text-slate-500'}`}>
                    <div className={`w-1.5 h-1.5 rounded-full ${u.is_active ? 'bg-green-400 animate-pulse' : 'bg-slate-500'}`} />
                    {u.is_active ? 'Active' : 'Inactive'}
                  </div>
                </td>
                <td className="px-4 py-3">
                  <div className="flex items-center gap-1">
                    <button onClick={() => openEdit(u)} className="p-1.5 rounded-lg hover:bg-secondary text-muted-foreground hover:text-foreground transition-colors">
                      <Pencil className="w-3.5 h-3.5" />
                    </button>
                    <button onClick={() => handleDelete(u.id)} className="p-1.5 rounded-lg hover:bg-destructive/10 text-muted-foreground hover:text-destructive transition-colors">
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Add/Edit Dialog */}
      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>{editingId ? 'Edit User' : 'Add User'}</DialogTitle>
          </DialogHeader>

          <div className="space-y-5 py-2">
            {/* Basic Info */}
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-1.5">
                <Label className="text-xs">Full Name *</Label>
                <Input value={form.full_name} onChange={e => setForm(f => ({ ...f, full_name: e.target.value }))} placeholder="Jane Smith" />
              </div>
              <div className="space-y-1.5">
                <Label className="text-xs">User ID</Label>
                <Input value={form.user_id} onChange={e => setForm(f => ({ ...f, user_id: e.target.value }))} placeholder="e.g. USR-0042" className="font-mono" />
              </div>
              <div className="space-y-1.5">
                <Label className="text-xs">Phone</Label>
                <Input value={form.phone} onChange={e => setForm(f => ({ ...f, phone: e.target.value }))} placeholder="+1 555 000 0000" />
              </div>
              <div className="space-y-1.5">
                <Label className="text-xs">User Type</Label>
                <Select value={form.user_type} onValueChange={v => setForm(f => ({ ...f, user_type: v }))}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    {USER_TYPES.map(t => <SelectItem key={t} value={t} className="capitalize">{t}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
              <div className="col-span-2 space-y-1.5">
                <Label className="text-xs">Address</Label>
                <Input value={form.address} onChange={e => setForm(f => ({ ...f, address: e.target.value }))} placeholder="123 Main St, City, TX 79772" />
              </div>
            </div>

            {/* Interstate Selection */}
            <div className="space-y-1.5">
              <Label className="text-xs flex items-center gap-1.5"><Radio className="w-3.5 h-3.5 text-primary" /> Interstate Assignment</Label>
              <Select value={form.highway_id} onValueChange={handleHighwayChange}>
                <SelectTrigger>
                  <SelectValue placeholder="Select an interstate..." />
                </SelectTrigger>
                <SelectContent>
                  {highways.map(h => (
                    <SelectItem key={h.highway_id} value={h.highway_id}>{h.name} — {h.state}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {/* Device Assignment */}
            {form.highway_id && (
              <div className="space-y-2">
                <Label className="text-xs flex items-center gap-1.5">
                  <MapPin className="w-3.5 h-3.5 text-primary" />
                  Device Access — {form.highway_name}
                  {form.device_ids.length > 0 && (
                    <span className="ml-auto text-[10px] font-mono text-primary bg-primary/10 px-1.5 py-0.5 rounded">
                      {form.device_ids.length} selected
                    </span>
                  )}
                </Label>

                <Input
                  placeholder="Search devices by name, ID, type, or mile marker..."
                  value={deviceSearch}
                  onChange={e => setDeviceSearch(e.target.value)}
                  className="text-xs"
                />

                <div className="border border-border rounded-xl overflow-hidden max-h-56 overflow-y-auto">
                  {filteredDevices.length === 0 && (
                    <div className="px-4 py-6 text-center text-xs text-muted-foreground">
                      {devices.length === 0 ? 'No devices found for this interstate.' : 'No devices match your search.'}
                    </div>
                  )}
                  {filteredDevices.map(d => {
                    const selected = form.device_ids.includes(d.device_id);
                    return (
                      <button
                        key={d.id}
                        type="button"
                        onClick={() => toggleDevice(d)}
                        className={`w-full flex items-center gap-3 px-3 py-2.5 text-left border-b border-border/50 last:border-0 transition-colors ${selected ? 'bg-primary/8' : 'hover:bg-muted/40'}`}
                      >
                        <div className={`w-4 h-4 rounded border flex items-center justify-center flex-shrink-0 transition-colors ${selected ? 'bg-primary border-primary' : 'border-border'}`}>
                          {selected && <Check className="w-2.5 h-2.5 text-primary-foreground" />}
                        </div>
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2">
                            <span className="text-xs font-medium truncate">{d.device_name}</span>
                            <span className={`text-[10px] font-mono uppercase font-semibold ${DEVICE_TYPE_COLORS[d.device_type] || ''}`}>{d.device_type}</span>
                          </div>
                          <div className="text-[10px] text-muted-foreground mt-0.5 flex items-center gap-2">
                            <span className="font-mono">{d.device_id}</span>
                            {d.mile_marker != null && <span>· MM {d.mile_marker}</span>}
                            {d.location_comment && <span className="truncate">· {d.location_comment}</span>}
                          </div>
                        </div>
                        <div className={`w-1.5 h-1.5 rounded-full flex-shrink-0 ${d.status === 'online' ? 'bg-green-400' : d.status === 'fault' ? 'bg-red-400' : 'bg-slate-500'}`} />
                      </button>
                    );
                  })}
                </div>
              </div>
            )}

            {/* Notes + Status */}
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-1.5">
                <Label className="text-xs">Notes</Label>
                <Input value={form.notes} onChange={e => setForm(f => ({ ...f, notes: e.target.value }))} placeholder="Optional notes..." />
              </div>
              <div className="space-y-1.5">
                <Label className="text-xs">Status</Label>
                <Select value={form.is_active ? 'active' : 'inactive'} onValueChange={v => setForm(f => ({ ...f, is_active: v === 'active' }))}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="active">Active</SelectItem>
                    <SelectItem value="inactive">Inactive</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="flex justify-end gap-2 pt-2">
              <Button variant="outline" onClick={() => setOpen(false)}>Cancel</Button>
              <Button onClick={handleSave} disabled={!form.full_name.trim()}>
                {editingId ? 'Save Changes' : 'Create User'}
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}