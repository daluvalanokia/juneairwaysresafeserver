import { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import PageHeader from '@/components/shared/PageHeader';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Plus, Edit2, Trash2, Layers, Triangle } from 'lucide-react';

const EMPTY = {
  zone_id: '', highway_id: '', geofence_radius: 500,
  switch1_server_id: '', switch1_lat: '', switch1_lon: '', switch1_label: 'Switch A',
  switch2_server_id: '', switch2_lat: '', switch2_lon: '', switch2_label: 'Switch B',
  switch3_server_id: '', switch3_lat: '', switch3_lon: '', switch3_label: 'Switch C',
};

function SwitchPanel({ num, label, form, setForm }) {
  const prefix = `switch${num}_`;
  return (
    <div className="rounded-lg border border-border bg-secondary/50 p-3">
      <p className="text-xs font-semibold text-primary mb-2 flex items-center gap-1">
        <Triangle className="w-3 h-3" /> Switch {num} — {form[`${prefix}label`] || `Switch ${num}`}
      </p>
      <div className="grid grid-cols-2 gap-2">
        {[
          [`${prefix}label`, 'Label', 'text'],
          [`${prefix}server_id`, 'Server ID', 'text'],
          [`${prefix}lat`, 'Latitude', 'number'],
          [`${prefix}lon`, 'Longitude', 'number'],
        ].map(([key, lbl, type]) => (
          <div key={key} className={key.endsWith('label') || key.endsWith('server_id') ? 'col-span-2' : ''}>
            <Label className="text-[10px] text-muted-foreground">{lbl}</Label>
            <Input type={type} value={form[key] || ''} onChange={e => setForm(p => ({ ...p, [key]: e.target.value }))} className="mt-0.5 h-7 text-xs" />
          </div>
        ))}
      </div>
    </div>
  );
}

export default function Triangulation({ selectedHighway }) {
  const [configs, setConfigs] = useState([]);
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState(EMPTY);
  const [editing, setEditing] = useState(null);

  const load = () => {
    const filter = selectedHighway ? { highway_id: selectedHighway } : {};
    base44.entities.TriangulationConfig.filter(filter).then(setConfigs);
  };

  useEffect(() => { load(); }, [selectedHighway]);

  const save = async () => {
    const data = { ...form, highway_id: form.highway_id || selectedHighway };
    if (editing) await base44.entities.TriangulationConfig.update(editing, data);
    else await base44.entities.TriangulationConfig.create(data);
    setOpen(false); setEditing(null); setForm(EMPTY); load();
  };

  const del = async (id) => { await base44.entities.TriangulationConfig.delete(id); load(); };
  const openEdit = (c) => { setForm({ ...c }); setEditing(c.id); setOpen(true); };
  const openNew = () => { setForm({ ...EMPTY, highway_id: selectedHighway || '' }); setEditing(null); setOpen(true); };

  return (
    <div>
      <PageHeader title="Triangulation Config" subtitle="3-switch GPS triangulation per merge zone">
        <Button onClick={openNew} size="sm" className="gap-2">
          <Plus className="w-4 h-4" /> Add Config
        </Button>
      </PageHeader>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {configs.map(c => (
          <div key={c.id} className="rounded-xl border border-border bg-card p-4">
            <div className="flex items-start justify-between mb-3">
              <div>
                <p className="font-semibold text-foreground flex items-center gap-2">
                  <Layers className="w-4 h-4 text-primary" /> Zone: {c.zone_id}
                </p>
                <p className="text-xs text-muted-foreground font-mono">Geofence: {c.geofence_radius}m radius</p>
              </div>
              <div className="flex gap-2">
                <Button variant="outline" size="sm" onClick={() => openEdit(c)}><Edit2 className="w-3 h-3" /></Button>
                <Button variant="outline" size="sm" className="text-destructive" onClick={() => del(c.id)}><Trash2 className="w-3 h-3" /></Button>
              </div>
            </div>
            <div className="grid grid-cols-3 gap-2">
              {[1,2,3].map(n => (
                <div key={n} className="rounded-lg border border-border bg-secondary/50 p-2 text-xs">
                  <p className="font-semibold text-primary mb-1">{c[`switch${n}_label`] || `Switch ${n}`}</p>
                  <p className="text-muted-foreground font-mono truncate">{c[`switch${n}_server_id`] || '—'}</p>
                  <p className="text-muted-foreground font-mono">{c[`switch${n}_lat`]}, {c[`switch${n}_lon`]}</p>
                </div>
              ))}
            </div>
          </div>
        ))}
        {configs.length === 0 && (
          <div className="col-span-2 text-center py-16 text-muted-foreground">
            {selectedHighway ? 'No triangulation configs set up.' : 'Select a highway to view configs.'}
          </div>
        )}
      </div>

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader><DialogTitle>{editing ? 'Edit Triangulation Config' : 'New Triangulation Config'}</DialogTitle></DialogHeader>
          <div className="grid grid-cols-2 gap-3 mb-4">
            <div>
              <Label className="text-xs">Zone ID</Label>
              <Input value={form.zone_id || ''} onChange={e => setForm(p => ({ ...p, zone_id: e.target.value }))} className="mt-1 h-8 text-sm" />
            </div>
            <div>
              <Label className="text-xs">Highway ID</Label>
              <Input value={form.highway_id || selectedHighway || ''} onChange={e => setForm(p => ({ ...p, highway_id: e.target.value }))} className="mt-1 h-8 text-sm" />
            </div>
            <div className="col-span-2">
              <Label className="text-xs">Geofence Radius (m)</Label>
              <Input type="number" value={form.geofence_radius || 500} onChange={e => setForm(p => ({ ...p, geofence_radius: e.target.value }))} className="mt-1 h-8 text-sm w-40" />
            </div>
          </div>
          <div className="space-y-3">
            {[1,2,3].map(n => <SwitchPanel key={n} num={n} form={form} setForm={setForm} />)}
          </div>
          <div className="flex justify-end gap-2 pt-4">
            <Button variant="outline" size="sm" onClick={() => setOpen(false)}>Cancel</Button>
            <Button size="sm" onClick={save}>{editing ? 'Save' : 'Create'}</Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}