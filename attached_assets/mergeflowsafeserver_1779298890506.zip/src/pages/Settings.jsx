import { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import PageHeader from '@/components/shared/PageHeader';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Plus, Edit2, Trash2, Route, KeyRound, Eye, EyeOff, CheckCircle2 } from 'lucide-react';

const EMPTY = { name: '', highway_id: '', description: '', state: '', is_active: true };

export default function Settings() {
  const [highways, setHighways] = useState([]);
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState(EMPTY);
  const [editing, setEditing] = useState(null);
  const [tomtomKey, setTomtomKey] = useState('');
  const [showKey, setShowKey] = useState(false);
  const [keySaved, setKeySaved] = useState(false);

  const saveTomTomKey = async () => {
    await base44.functions.invoke('saveTomTomKey', { apiKey: tomtomKey });
    setKeySaved(true);
    setTimeout(() => setKeySaved(false), 2500);
  };

  const load = () => base44.entities.Highway.list().then(setHighways);
  useEffect(() => { load(); }, []);

  const save = async () => {
    if (editing) await base44.entities.Highway.update(editing, form);
    else await base44.entities.Highway.create(form);
    setOpen(false); setEditing(null); setForm(EMPTY); load();
  };

  const del = async (id) => { await base44.entities.Highway.delete(id); load(); };
  const openEdit = (h) => { setForm({ ...h }); setEditing(h.id); setOpen(true); };
  const openNew = () => { setForm(EMPTY); setEditing(null); setOpen(true); };

  const field = (key, label, type = 'text') => (
    <div key={key}>
      <Label className="text-xs">{label}</Label>
      <Input type={type} value={form[key] || ''} onChange={e => setForm(p => ({ ...p, [key]: e.target.value }))} className="mt-1 h-8 text-sm" />
    </div>
  );

  return (
    <div className="space-y-6">
      <PageHeader title="Settings" subtitle="Manage highway configurations">
        <Button onClick={openNew} size="sm" className="gap-2">
          <Plus className="w-4 h-4" /> Add Highway
        </Button>
      </PageHeader>

      {/* TomTom API Key Section */}
      <div className="rounded-xl border border-border bg-card overflow-hidden">
        <div className="px-4 py-3 border-b border-border bg-secondary/50">
          <h2 className="text-sm font-semibold text-foreground flex items-center gap-2">
            <KeyRound className="w-4 h-4 text-primary" /> External API Keys
          </h2>
        </div>
        <div className="px-4 py-4 space-y-3">
          <div>
            <Label className="text-xs text-muted-foreground">TomTom API Key</Label>
            <p className="text-[11px] text-muted-foreground mb-2">
              Used for real-time traffic flow in the 3D visualization. Get your key at{' '}
              <a href="https://developer.tomtom.com" target="_blank" rel="noreferrer" className="text-primary underline">developer.tomtom.com</a>.
              Leave empty to use simulated demo data.
            </p>
            <div className="flex gap-2">
              <div className="relative flex-1">
                <Input
                  type={showKey ? 'text' : 'password'}
                  placeholder="Enter your TomTom API key..."
                  value={tomtomKey}
                  onChange={e => setTomtomKey(e.target.value)}
                  className="h-8 text-sm pr-8 font-mono"
                />
                <button
                  onClick={() => setShowKey(v => !v)}
                  className="absolute right-2 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
                >
                  {showKey ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                </button>
              </div>
              <Button size="sm" onClick={saveTomTomKey} className="h-8 gap-1.5">
                {keySaved ? <CheckCircle2 className="w-3.5 h-3.5 text-green-400" /> : null}
                {keySaved ? 'Saved!' : 'Save Key'}
              </Button>
            </div>
          </div>
        </div>
      </div>

      <div className="rounded-xl border border-border bg-card overflow-hidden">
        <div className="px-4 py-3 border-b border-border bg-secondary/50">
          <h2 className="text-sm font-semibold text-foreground flex items-center gap-2">
            <Route className="w-4 h-4 text-primary" /> Configured Highways
          </h2>
        </div>
        <div className="divide-y divide-border">
          {highways.map(h => (
            <div key={h.id} className="flex items-center justify-between px-4 py-3 hover:bg-secondary/30 transition-colors">
              <div>
                <p className="text-sm font-medium text-foreground">{h.name}</p>
                <p className="text-xs text-muted-foreground font-mono">{h.highway_id} · {h.state}</p>
              </div>
              <div className="flex gap-2">
                <Button variant="outline" size="sm" onClick={() => openEdit(h)}><Edit2 className="w-3 h-3" /></Button>
                <Button variant="outline" size="sm" className="text-destructive" onClick={() => del(h.id)}><Trash2 className="w-3 h-3" /></Button>
              </div>
            </div>
          ))}
          {highways.length === 0 && (
            <div className="text-center py-12 text-muted-foreground text-sm">No highways configured yet.</div>
          )}
        </div>
      </div>

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader><DialogTitle>{editing ? 'Edit Highway' : 'New Highway'}</DialogTitle></DialogHeader>
          <div className="grid grid-cols-2 gap-3">
            <div className="col-span-2">{field('name', 'Highway Name')}</div>
            {field('highway_id', 'Highway ID')}
            {field('state', 'State / Region')}
            <div className="col-span-2">{field('description', 'Description')}</div>
          </div>
          <div className="flex justify-end gap-2 pt-2">
            <Button variant="outline" size="sm" onClick={() => setOpen(false)}>Cancel</Button>
            <Button size="sm" onClick={save}>{editing ? 'Save' : 'Create'}</Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}