import { useState, useEffect, useCallback } from 'react';
import { base44 } from '@/api/base44Client';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Checkbox } from '@/components/ui/checkbox';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Badge } from '@/components/ui/badge';
import { Plus, Trash2, Edit2, Play, CheckCircle2, AlertCircle, Loader2, Copy, CopyPlus, ChevronDown, X, Save, Database } from 'lucide-react';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from '@/components/ui/dropdown-menu';
import PageHeader from '@/components/shared/PageHeader';

const SOURCE_TYPES = ['physical', 'satellite', 'telecom', 'tracker'];

const COMMON_FIELDS = [
  { key: 'make', label: 'Make' },
  { key: 'model', label: 'Model' },
  { key: 'date', label: 'Date' },
  { key: 'time', label: 'Time' },
  { key: 'timestamp', label: 'Timestamp' },
  { key: 'coordinates', label: 'Coordinates' },
  { key: 'latitude', label: 'Latitude' },
  { key: 'longitude', label: 'Longitude' },
  { key: 'speed', label: 'Speed' },
  { key: 'speed_mph', label: 'Speed (mph)' },
  { key: 'altitude_meters', label: 'Altitude (m)' },
  { key: 'direction_degrees', label: 'Direction (°)' },
  { key: 'firmware_version', label: 'Firmware Version' },
  { key: 'status', label: 'Status' },
  { key: 'vehicle_id', label: 'Vehicle ID' },
  { key: 'tag_id', label: 'Tag ID' },
  { key: 'signal_strength_dbm', label: 'Signal Strength (dBm)' },
  { key: 'vehicle_type', label: 'Vehicle Type' },
  { key: 'traffic_density_percent', label: 'Traffic Density (%)' },
  { key: 'average_speed_mph', label: 'Avg Speed (mph)' },
];

const FIELD_TYPES = ['string', 'number', 'boolean', 'array', 'object'];

const EMPTY_FORM = { format_name: '', source_id: '', input_source: '', description: '', enabled_fields: [], custom_fields: [] };

function FormatTab({ sourceType }) {
  const [configs, setConfigs] = useState([]);
  const [selectedConfig, setSelectedConfig] = useState(null);
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState(EMPTY_FORM);
  const [editing, setEditing] = useState(null);
  const [allConfigs, setAllConfigs] = useState([]);
  const [dupOpen, setDupOpen] = useState(false);
  const [dupSourceType, setDupSourceType] = useState('');
  const [dupConfig, setDupConfig] = useState(null);
  const [payload, setPayload] = useState(null);
  const [validation, setValidation] = useState(null);
  const [generating, setGenerating] = useState(false);
  const [copied, setCopied] = useState(false);
  const [savedPayloads, setSavedPayloads] = useState([]);
  const [saving, setSaving] = useState(false);

  const load = useCallback(() => {
    base44.entities.InputFormatConfig.filter({ source_type: sourceType }).then(setConfigs);
    base44.entities.InputFormatConfig.list().then(setAllConfigs);
    base44.entities.SamplePayload.filter({ source_type: sourceType }).then(setSavedPayloads);
  }, [sourceType]);

  useEffect(() => { load(); }, [load]);

  const toggleField = (key) => {
    setForm(f => ({
      ...f,
      enabled_fields: f.enabled_fields.includes(key)
        ? f.enabled_fields.filter(k => k !== key)
        : [...f.enabled_fields, key]
    }));
  };

  const addCustomField = () => {
    setForm(f => ({ ...f, custom_fields: [...f.custom_fields, { name: '', type: 'string' }] }));
  };

  const updateCustomField = (idx, field, value) => {
    setForm(f => {
      const updated = [...f.custom_fields];
      updated[idx] = { ...updated[idx], [field]: value };
      return { ...f, custom_fields: updated };
    });
  };

  const removeCustomField = (idx) => {
    setForm(f => ({ ...f, custom_fields: f.custom_fields.filter((_, i) => i !== idx) }));
  };

  const save = async () => {
    const data = { ...form, source_type: sourceType, source_id: form.source_id || '', input_source: form.input_source || '' };
    if (editing) await base44.entities.InputFormatConfig.update(editing, data);
    else await base44.entities.InputFormatConfig.create(data);
    setOpen(false); setEditing(null); setForm(EMPTY_FORM); load();
  };

  const del = async (id) => {
    await base44.entities.InputFormatConfig.delete(id);
    if (selectedConfig?.id === id) { setSelectedConfig(null); setPayload(null); setValidation(null); }
    load();
  };

  const duplicate = async (cfg) => {
    await base44.entities.InputFormatConfig.create({
      source_type: cfg.source_type,
      format_name: `${cfg.format_name} (Copy)`,
      source_id: cfg.source_id ? `${cfg.source_id}-copy` : '',
      input_source: cfg.input_source || '',
      description: cfg.description || '',
      enabled_fields: cfg.enabled_fields || [],
      custom_fields: cfg.custom_fields || [],
    });
    load();
  };

  const duplicateTo = async () => {
    if (!dupConfig || !dupSourceType) return;
    await base44.entities.InputFormatConfig.create({
      source_type: dupSourceType,
      format_name: `${dupConfig.format_name} (Copy)`,
      source_id: dupConfig.source_id ? `${dupConfig.source_id}-copy` : '',
      input_source: dupConfig.input_source || '',
      description: dupConfig.description || '',
      enabled_fields: dupConfig.enabled_fields || [],
      custom_fields: dupConfig.custom_fields || [],
    });
    setDupOpen(false); setDupConfig(null); setDupSourceType('');
    load();
  };

  const openEdit = (cfg) => {
    setForm({ format_name: cfg.format_name, source_id: cfg.source_id || '', input_source: cfg.input_source || '', description: cfg.description || '', enabled_fields: cfg.enabled_fields || [], custom_fields: cfg.custom_fields || [] });
    setEditing(cfg.id); setOpen(true);
  };

  const openNew = () => { setForm(EMPTY_FORM); setEditing(null); setOpen(true); };

  const generatePayload = async (cfg) => {
    setSelectedConfig(cfg);
    setGenerating(true);
    setPayload(null); setValidation(null);
    const res = await base44.functions.invoke('generateInputPayload', {
      source_type: sourceType,
      enabled_fields: cfg.enabled_fields || [],
      custom_fields: cfg.custom_fields || [],
    });
    setPayload(res.data.payload);
    setValidation(res.data.validation);
    setGenerating(false);
  };

  const copyPayload = () => {
    navigator.clipboard.writeText(JSON.stringify(payload, null, 2));
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const savePayload = async () => {
    if (!payload || !selectedConfig) return;
    setSaving(true);
    await base44.entities.SamplePayload.create({
      source_type: sourceType,
      format_config_id: selectedConfig.id,
      format_name: selectedConfig.format_name,
      payload: JSON.stringify(payload),
      is_valid: validation?.valid ?? true,
    });
    setSaving(false);
    load();
  };

  const deleteSavedPayload = async (id) => {
    await base44.entities.SamplePayload.delete(id);
    load();
  };

  const duplicateSavedPayload = async (sp) => {
    await base44.entities.SamplePayload.create({
      source_type: sp.source_type,
      format_config_id: sp.format_config_id,
      format_name: sp.format_name,
      payload: sp.payload,
      is_valid: sp.is_valid,
      label: sp.label ? `${sp.label} (Copy)` : `${sp.format_name} (Copy)`,
    });
    load();
  };

  const sourceColor = {
    physical: 'bg-blue-500/10 text-blue-400 border-blue-500/20',
    satellite: 'bg-purple-500/10 text-purple-400 border-purple-500/20',
    telecom: 'bg-green-500/10 text-green-400 border-green-500/20',
    tracker: 'bg-orange-500/10 text-orange-400 border-orange-500/20',
  }[sourceType];

  return (
    <div className="space-y-4">
      {/* Config List */}
      <div className="flex items-center justify-between">
        <p className="text-xs text-muted-foreground">
          {configs.length} format{configs.length !== 1 ? 's' : ''} configured
        </p>
        <div className="flex items-center gap-2">
          {/* Duplicate existing format to a source tab */}
          <DropdownMenu open={dupOpen} onOpenChange={setDupOpen}>
            <DropdownMenuTrigger asChild>
              <Button size="sm" variant="outline" className="gap-1.5">
                <CopyPlus className="w-3.5 h-3.5" /> Duplicate <ChevronDown className="w-3 h-3" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-64">
              {allConfigs.length === 0 ? (
                <div className="px-3 py-2 text-xs text-muted-foreground">No formats to duplicate</div>
              ) : (
                <>
                  <div className="px-3 py-1.5 text-xs text-muted-foreground font-semibold border-b border-border mb-1">Select format to duplicate</div>
                  {allConfigs.map(cfg => (
                    <DropdownMenuItem
                      key={cfg.id}
                      className="flex flex-col items-start gap-0.5 cursor-pointer"
                      onSelect={(e) => { e.preventDefault(); setDupConfig(cfg); setDupSourceType(sourceType); }}
                    >
                      <span className="text-xs font-medium">{cfg.format_name}</span>
                      <span className="text-[10px] text-muted-foreground capitalize">{cfg.source_type}{cfg.source_id ? ` · ${cfg.source_id}` : ''}</span>
                    </DropdownMenuItem>
                  ))}
                </>
              )}
              {dupConfig && (
                <>
                  <div className="border-t border-border mt-1 px-3 py-2 space-y-2">
                    <p className="text-xs font-semibold">Copy "{dupConfig.format_name}" to:</p>
                    <Select value={dupSourceType} onValueChange={setDupSourceType}>
                      <SelectTrigger className="h-7 text-xs"><SelectValue placeholder="Select target source…" /></SelectTrigger>
                      <SelectContent>
                        {SOURCE_TYPES.map(s => <SelectItem key={s} value={s} className="text-xs capitalize">{s}</SelectItem>)}
                      </SelectContent>
                    </Select>
                    <div className="flex gap-1.5 justify-end">
                      <Button size="sm" variant="ghost" className="h-6 text-xs" onClick={() => { setDupConfig(null); setDupSourceType(''); }}>Clear</Button>
                      <Button size="sm" className="h-6 text-xs" onClick={duplicateTo} disabled={!dupSourceType}>Duplicate</Button>
                    </div>
                  </div>
                </>
              )}
            </DropdownMenuContent>
          </DropdownMenu>

          <Button size="sm" onClick={openNew} className="gap-1.5">
            <Plus className="w-3.5 h-3.5" /> New Format
          </Button>
        </div>
      </div>

      {configs.length === 0 ? (
        <div className="text-center py-10 border border-dashed border-border rounded-xl text-muted-foreground text-sm">
          No formats configured for <span className="font-semibold capitalize">{sourceType}</span>. Create one to get started.
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-3">
          {configs.map(cfg => (
            <div
              key={cfg.id}
              className={`rounded-xl border p-4 cursor-pointer transition-all ${selectedConfig?.id === cfg.id ? 'border-primary/50 bg-primary/5' : 'border-border bg-card hover:border-border/80'}`}
            >
              <div className="flex items-start justify-between mb-2">
                <div className="flex-1 min-w-0">
                  <p className="font-semibold text-sm truncate">{cfg.format_name}</p>
                  {cfg.source_id && <p className="text-[10px] font-mono text-muted-foreground truncate mt-0.5">ID: {cfg.source_id}</p>}
                  {cfg.input_source && <p className="text-[10px] font-mono text-blue-400 truncate mt-0.5">⇒ {cfg.input_source}</p>}
                  {cfg.description && <p className="text-xs text-muted-foreground truncate mt-0.5">{cfg.description}</p>}
                </div>
                <div className="flex gap-1 ml-2 flex-shrink-0">
                  <button onClick={() => openEdit(cfg)} className="p-1 text-muted-foreground hover:text-foreground transition-colors" title="Edit">
                    <Edit2 className="w-3.5 h-3.5" />
                  </button>
                  <button onClick={() => duplicate(cfg)} className="p-1 text-muted-foreground hover:text-blue-400 transition-colors" title="Duplicate">
                    <CopyPlus className="w-3.5 h-3.5" />
                  </button>
                  <button onClick={() => del(cfg.id)} className="p-1 text-muted-foreground hover:text-destructive transition-colors" title="Delete">
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
              <div className="flex flex-wrap gap-1 mb-3">
                {(cfg.enabled_fields || []).slice(0, 4).map(f => (
                  <span key={f} className={`text-[10px] px-1.5 py-0.5 rounded border font-mono ${sourceColor}`}>{f}</span>
                ))}
                {(cfg.enabled_fields || []).length > 4 && (
                  <span className="text-[10px] px-1.5 py-0.5 rounded border border-border text-muted-foreground">+{(cfg.enabled_fields || []).length - 4} more</span>
                )}
                {(cfg.custom_fields || []).length > 0 && (
                  <span className="text-[10px] px-1.5 py-0.5 rounded border border-border text-muted-foreground">{cfg.custom_fields.length} custom</span>
                )}
              </div>
              <Button size="sm" variant="outline" className="w-full gap-1.5 h-7 text-xs" onClick={() => generatePayload(cfg)}>
                <Play className="w-3 h-3" /> Generate Sample Payload
              </Button>
            </div>
          ))}
        </div>
      )}

      {/* Payload Preview */}
      {(generating || payload) && (
        <div className="rounded-xl border border-border bg-card overflow-hidden">
          <div className="flex items-center justify-between px-4 py-3 border-b border-border">
            <div className="flex items-center gap-2">
              <span className="text-xs font-semibold font-mono">SAMPLE API PAYLOAD</span>
              {selectedConfig && <span className="text-xs text-muted-foreground">— {selectedConfig.format_name}</span>}
            </div>
            <div className="flex items-center gap-2">
              {validation && (
                validation.valid
                  ? <span className="flex items-center gap-1 text-xs text-green-400"><CheckCircle2 className="w-3.5 h-3.5" /> Valid</span>
                  : <span className="flex items-center gap-1 text-xs text-destructive"><AlertCircle className="w-3.5 h-3.5" /> {validation.issues[0]}</span>
              )}
              {payload && (
                <>
                  <Button size="sm" variant="ghost" className="h-6 px-2 text-xs gap-1" onClick={copyPayload}>
                    <Copy className="w-3 h-3" /> {copied ? 'Copied!' : 'Copy'}
                  </Button>
                  <Button size="sm" variant="ghost" className="h-6 px-2 text-xs gap-1 text-green-400 hover:text-green-300" onClick={savePayload} disabled={saving}>
                    {saving ? <Loader2 className="w-3 h-3 animate-spin" /> : <Save className="w-3 h-3" />} Save
                  </Button>
                </>
              )}
              <Button size="sm" variant="ghost" className="h-6 px-2 text-xs gap-1 text-muted-foreground hover:text-destructive" onClick={() => { setPayload(null); setValidation(null); setSelectedConfig(null); }}>
                <X className="w-3 h-3" />
              </Button>
            </div>
          </div>
          <div className="p-4 font-mono text-xs text-green-400 bg-slate-950/50 min-h-[120px] overflow-x-auto">
            {generating ? (
              <div className="flex items-center gap-2 text-muted-foreground">
                <Loader2 className="w-4 h-4 animate-spin" /> Generating payload...
              </div>
            ) : (
              <pre>{JSON.stringify(payload, null, 2)}</pre>
            )}
          </div>
        </div>
      )}

      {/* Saved Payloads */}
      {savedPayloads.length > 0 && (
        <div className="space-y-2">
          <div className="flex items-center gap-2">
            <Database className="w-3.5 h-3.5 text-muted-foreground" />
            <span className="text-xs font-semibold text-muted-foreground">SAVED PAYLOADS ({savedPayloads.length})</span>
          </div>
          <div className="space-y-2">
            {savedPayloads.map(sp => (
              <div key={sp.id} className="rounded-lg border border-border bg-card overflow-hidden">
                <div className="flex items-center justify-between px-3 py-2 border-b border-border">
                  <div className="flex items-center gap-2 min-w-0">
                    {sp.is_valid
                      ? <CheckCircle2 className="w-3 h-3 text-green-400 flex-shrink-0" />
                      : <AlertCircle className="w-3 h-3 text-destructive flex-shrink-0" />}
                    <span className="text-xs font-medium truncate">{sp.label || sp.format_name}</span>
                    <span className="text-[10px] text-muted-foreground flex-shrink-0">{new Date(sp.created_date).toLocaleString()}</span>
                  </div>
                  <div className="flex items-center gap-1 flex-shrink-0 ml-2">
                    <button
                      onClick={() => { navigator.clipboard.writeText(sp.payload); }}
                      className="p-1 text-muted-foreground hover:text-foreground transition-colors" title="Copy"
                    >
                      <Copy className="w-3 h-3" />
                    </button>
                    <button
                      onClick={() => duplicateSavedPayload(sp)}
                      className="p-1 text-muted-foreground hover:text-blue-400 transition-colors" title="Duplicate"
                    >
                      <CopyPlus className="w-3 h-3" />
                    </button>
                    <button
                      onClick={() => deleteSavedPayload(sp.id)}
                      className="p-1 text-muted-foreground hover:text-destructive transition-colors" title="Delete"
                    >
                      <Trash2 className="w-3 h-3" />
                    </button>
                  </div>
                </div>
                <pre className="px-3 py-2 font-mono text-[10px] text-green-400 bg-slate-950/50 overflow-x-auto max-h-32">
                  {JSON.stringify(JSON.parse(sp.payload), null, 2)}
                </pre>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Create / Edit Dialog */}
      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="max-w-lg max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>{editing ? 'Edit Format' : `New ${sourceType.charAt(0).toUpperCase() + sourceType.slice(1)} Format`}</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label className="text-xs">Format Name *</Label>
              <Input value={form.format_name} onChange={e => setForm(f => ({ ...f, format_name: e.target.value }))} className="mt-1 h-8 text-sm" placeholder="e.g. Standard Satellite Feed v1" />
            </div>
            <div>
              <Label className="text-xs">Source ID</Label>
              <Input value={form.source_id} onChange={e => setForm(f => ({ ...f, source_id: e.target.value }))} className="mt-1 h-8 text-sm font-mono" placeholder="e.g. SRC-SAT-001" />
            </div>
            <div>
              <Label className="text-xs">Description</Label>
              <Input value={form.description} onChange={e => setForm(f => ({ ...f, description: e.target.value }))} className="mt-1 h-8 text-sm" placeholder="Optional description" />
            </div>

            <div>
              <Label className="text-xs">Input Source</Label>
              <Input value={form.input_source} onChange={e => setForm(f => ({ ...f, input_source: e.target.value }))} className="mt-1 h-8 text-sm" placeholder="e.g. tcp://192.168.1.10:9000 or sensor-stream-A" />
              <p className="text-[10px] text-muted-foreground mt-1">Source endpoint, stream name, or device tag this format maps to</p>
            </div>

            {/* Common Fields */}
            <div>
              <Label className="text-xs font-semibold">Common Fields</Label>
              <p className="text-xs text-muted-foreground mb-2">Select the fields expected in the incoming data</p>
              <div className="grid grid-cols-2 gap-2 max-h-48 overflow-y-auto pr-1">
                {COMMON_FIELDS.map(({ key, label }) => (
                  <div key={key} className="flex items-center gap-2">
                    <Checkbox
                      id={`field-${key}`}
                      checked={form.enabled_fields.includes(key)}
                      onCheckedChange={() => toggleField(key)}
                    />
                    <label htmlFor={`field-${key}`} className="text-xs cursor-pointer">{label}</label>
                  </div>
                ))}
              </div>
            </div>

            {/* Custom Fields */}
            <div>
              <div className="flex items-center justify-between mb-2">
                <Label className="text-xs font-semibold">Custom Fields</Label>
                <Button size="sm" variant="outline" className="h-6 text-xs gap-1" onClick={addCustomField}>
                  <Plus className="w-3 h-3" /> Add Field
                </Button>
              </div>
              {form.custom_fields.length === 0 ? (
                <p className="text-xs text-muted-foreground italic">No custom fields. Click "Add Field" to define one.</p>
              ) : (
                <div className="space-y-2">
                  {form.custom_fields.map((cf, idx) => (
                    <div key={idx} className="flex gap-2 items-center">
                      <Input
                        placeholder="field_name"
                        value={cf.name}
                        onChange={e => updateCustomField(idx, 'name', e.target.value)}
                        className="h-7 text-xs font-mono flex-1"
                      />
                      <Select value={cf.type} onValueChange={v => updateCustomField(idx, 'type', v)}>
                        <SelectTrigger className="h-7 text-xs w-24"><SelectValue /></SelectTrigger>
                        <SelectContent>
                          {FIELD_TYPES.map(t => <SelectItem key={t} value={t} className="text-xs">{t}</SelectItem>)}
                        </SelectContent>
                      </Select>
                      <button onClick={() => removeCustomField(idx)} className="text-muted-foreground hover:text-destructive transition-colors flex-shrink-0">
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  ))}
                </div>
              )}
            </div>

            <div className="flex justify-end gap-2 pt-2">
              <Button variant="outline" size="sm" onClick={() => setOpen(false)}>Cancel</Button>
              <Button size="sm" onClick={save} disabled={!form.format_name}>{editing ? 'Save' : 'Create'}</Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}

export default function DataInputFormats() {
  return (
    <div>
      <PageHeader
        title="Data Input Formats"
        subtitle="Configure and preview API payload schemas per data source type"
      />
      <Tabs defaultValue="physical">
        <TabsList className="mb-6">
          {SOURCE_TYPES.map(s => (
            <TabsTrigger key={s} value={s} className="capitalize">{s}</TabsTrigger>
          ))}
        </TabsList>
        {SOURCE_TYPES.map(s => (
          <TabsContent key={s} value={s}>
            <FormatTab sourceType={s} />
          </TabsContent>
        ))}
      </Tabs>
    </div>
  );
}