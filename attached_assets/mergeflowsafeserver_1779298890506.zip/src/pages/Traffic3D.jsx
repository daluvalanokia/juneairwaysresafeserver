import { useState, useEffect, useRef, useCallback } from 'react';
import { base44 } from '@/api/base44Client';
import Scene3D from '@/components/traffic3d/Scene3D';
import TrafficControls from '@/components/traffic3d/TrafficControls';
import TrafficFeed from '@/components/traffic3d/TrafficFeed';
import MapLanding from '@/components/traffic3d/MapLanding';
import { Loader2, Box, Map, RefreshCw, ArrowLeft } from 'lucide-react';

const DEFAULT_CENTER = { lat: 32.7767, lon: -96.7980 };
const REFRESH_MS = 30000;

export default function Traffic3D({ selectedHighway }) {
  const [view, setView] = useState('map'); // 'map' | '3d'
  const [trafficData, setTrafficData] = useState(null);
  const [isLoading, setIsLoading] = useState(false);
  const [lastUpdate, setLastUpdate] = useState(null);
  const [error, setError] = useState(null);
  const [countdown, setCountdown] = useState(REFRESH_MS / 1000);

  // Derive center from selected highway if it has lat/lon, else default
  const center = (selectedHighway?.latitude && selectedHighway?.longitude)
    ? { lat: selectedHighway.latitude, lon: selectedHighway.longitude }
    : DEFAULT_CENTER;

  const fetchTraffic = useCallback(async () => {
    setIsLoading(true);
    setError(null);
    try {
      const res = await base44.functions.invoke('getTomTomTraffic', {
        centerLat: center.lat,
        centerLon: center.lon,
      });
      setTrafficData(res.data);
      setLastUpdate(new Date().toLocaleTimeString());
    } catch {
      setError('Failed to load traffic data.');
    } finally {
      setIsLoading(false);
    }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [center.lat, center.lon]);

  // Re-fetch immediately when selected highway changes
  useEffect(() => {
    setTrafficData(null);
    fetchTraffic();
  }, [fetchTraffic]);

  // Auto-refresh every 30s
  useEffect(() => {
    setCountdown(REFRESH_MS / 1000);
    const id = setInterval(fetchTraffic, REFRESH_MS);
    return () => clearInterval(id);
  }, [fetchTraffic]);

  // Countdown ticker
  useEffect(() => {
    setCountdown(REFRESH_MS / 1000);
  }, [lastUpdate]);

  useEffect(() => {
    const id = setInterval(() => setCountdown(c => c > 0 ? c - 1 : 0), 1000);
    return () => clearInterval(id);
  }, []);

  return (
    <div className="flex flex-col h-full" style={{ height: 'calc(100vh - 64px)' }}>
      {/* Header */}
      <div className="flex items-center justify-between px-4 py-2.5 border-b border-border bg-card/50 flex-shrink-0">
        <div className="flex items-center gap-2">
          {view === '3d' ? (
            <button
              onClick={() => setView('map')}
              className="flex items-center gap-1.5 text-xs text-muted-foreground hover:text-foreground transition-colors mr-1"
            >
              <ArrowLeft className="w-3.5 h-3.5" />
              Map
            </button>
          ) : null}
          {view === 'map' ? <Map className="w-4 h-4 text-primary" /> : <Box className="w-4 h-4 text-primary" />}
          <h1 className="text-sm font-bold tracking-tight">
            {view === 'map' ? 'Traffic Map' : '3D Traffic Visualization'}
          </h1>
          <span className="text-xs text-muted-foreground font-mono">
            {selectedHighway ? `${selectedHighway.name} · ${selectedHighway.state || ''}` : 'I-35E · Exit 42 · Dallas TX'}
          </span>
        </div>
        <div className="flex items-center gap-2">
          {trafficData?.simulated && (
            <span className="px-2 py-0.5 rounded-full bg-yellow-500/10 text-yellow-400 border border-yellow-500/20 font-mono text-[10px]">
              DEMO DATA
            </span>
          )}
          {lastUpdate && (
            <span className="text-[10px] text-muted-foreground font-mono hidden sm:block">
              Updated {lastUpdate}
            </span>
          )}
          <span className="text-[10px] font-mono text-muted-foreground hidden sm:flex items-center gap-1">
            <span className="w-1.5 h-1.5 rounded-full bg-green-400 animate-pulse inline-block" />
            Next in {countdown}s
          </span>
          <button
            onClick={() => { fetchTraffic(); }}
            disabled={isLoading}
            className="flex items-center gap-1.5 text-xs text-muted-foreground hover:text-foreground border border-border rounded-lg px-2.5 py-1.5 transition-colors disabled:opacity-50"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${isLoading ? 'animate-spin' : ''}`} />
            Refresh
          </button>
        </div>
      </div>

      {/* Content */}
      <div className="relative flex-1 overflow-hidden">
        {/* Loading overlay — only on first load */}
        {isLoading && !trafficData && (
          <div className="absolute inset-0 flex flex-col items-center justify-center bg-slate-950/80 z-[2000]">
            <Loader2 className="w-8 h-8 text-primary animate-spin mb-3" />
            <p className="text-xs text-muted-foreground font-mono">LOADING I-35E TRAFFIC DATA...</p>
          </div>
        )}

        {error && !trafficData && (
          <div className="absolute inset-0 flex items-center justify-center z-[2000]">
            <div className="bg-destructive/10 border border-destructive/30 rounded-xl p-6 text-center">
              <p className="text-destructive text-sm">{error}</p>
              <button onClick={fetchTraffic} className="mt-3 text-xs text-muted-foreground underline">Retry</button>
            </div>
          </div>
        )}

        {/* Map landing view */}
        {view === 'map' && (
          <MapLanding
            trafficData={trafficData}
            selectedHighway={selectedHighway}
            onLaunch3D={() => setView('3d')}
          />
        )}

        {/* 3D view */}
        {view === '3d' && (
          <>
            <Scene3D
              trafficData={trafficData}
              onSegmentClick={null}
              onRefresh={fetchTraffic}
              isLoading={isLoading}
              lastUpdate={lastUpdate}
            />
            <TrafficControls
              trafficData={trafficData}
              lastUpdate={lastUpdate}
              onRefresh={fetchTraffic}
              isLoading={isLoading}
            />
            <TrafficFeed trafficData={trafficData} isVisible={true} />
            <div className="absolute bottom-3 left-1/2 -translate-x-1/2 pointer-events-none">
              <span className="text-[10px] text-slate-500 font-mono bg-slate-900/70 px-3 py-1.5 rounded-full border border-slate-800">
                Drag to rotate · Scroll to zoom · Road colors = live congestion
              </span>
            </div>
          </>
        )}
      </div>
    </div>
  );
}