import { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import PageHeader from '@/components/shared/PageHeader';
import StatusBadge from '@/components/shared/StatusBadge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Plus, Edit2, Trash2, Cpu, Wifi, Clock, ScanLine } from 'lucide-react';
import BarcodeScanner from '@/components/shared/BarcodeScanner';

const EMPTY = { zone_id: '', highway_id: '', server_name: '', server_id: '', ip_address: '', port: 8080, status: 'online', firmware_version: '' };

function formatUptime(seconds) {
  if (!seconds) return '—';
  const h = Math.floor(seconds / 3600);
  const m = Math.floor((seconds % 3600) / 60);
  return `${h}h ${m}m`;
}

export default function SwitchServers({ selectedHighway }) {
  const [servers, setServers] = useState([]);
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState(EMPTY);
  const [editing, setEditing] = useState(null);
  const [scanning, setScanning] = useState(false);

  const handleScan = (raw) => {
    setScanning(false);
    try {
      const parsed = JSON.parse(raw);
      setForm(p => ({ ...p, ...parsed }));
    } catch {
      // plain string → try to auto-detect field
      if (raw.includes('.') && raw.split('.').length === 4) {
        setForm(p => ({ ...p, ip_address: raw }));
      } else {
        setForm(p => ({ ...p, server_id: raw }));
      }
    }
  };

  const load = () => {
    const filter = selectedHighway ? { highway_id: selectedHighway } : {};
    base44.entities.SwitchServer.filter(filter).then(setServers);
  };

  useEffect(() => { load(); }, [selectedHighway]);

  const save = async () => {
    const data = { ...form, highway_id: form.highway_id || selectedHighway };
    if (editing) await base44.entities.SwitchServer.update(editing, data);
    else await base44.entities.SwitchServer.create(data);
    setOpen(false); setEditing(null); setForm(EMPTY); load();
  };

  const del = async (id) => { await base44.entities.SwitchServer.delete(id); load(); };
  const openEdit = (s) => { setForm({ ...s }); setEditing(s.id); setOpen(true); };
  const openNew = () => { setForm({ ...EMPTY, highway_id: selectedHighway || '' }); setEditing(null); setOpen(true); };

  return (
    <div>
      <PageHeader title="Switch Servers" subtitle="Monitor and manage autonomous merge control servers">
        <Button onClick={openNew} size="sm" className="gap-2">
          <Plus className="w-4 h-4" /> Add Server
        </Button>
      </PageHeader>

      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
        {servers.map(s => (
          <div key={s.id} className="rounded-xl border border-border bg-card p-4">
            <div className="flex items-start justify-between mb-3">
              <div>
                <p className="font-semibold text-foreground">{s.server_name}</p>
                <p className="text-xs text-muted-foreground font-mono">{s.server_id}</p>
              </div>
              <StatusBadge status={s.status} />
            </div>
            <div className="space-y-2 mb-4">
              <div className="flex items-center justify-between text-xs">
                <span className="text-muted-foreground flex items-center gap-1"><Wifi className="w-3 h-3" /> IP</span>
                <span className="font-mono text-foreground">{s.ip_address}:{s.port}</span>
              </div>
              <div className="flex items-center justify-between text-xs">
                <span className="text-muted-foreground flex items-center gap-1"><Cpu className="w-3 h-3" /> CPU/RAM</span>
                <span className="font-mono text-foreground">{s.cpu_percent ?? 0}% / {s.memory_percent ?? 0}%</span>
              </div>
              <div className="flex items-center justify-between text-xs">
                <span className="text-muted-foreground flex items-center gap-1"><Clock className="w-3 h-3" /> Uptime</span>
                <span className="font-mono text-foreground">{formatUptime(s.uptime_seconds)}</span>
              </div>
              {/* CPU bar */}
              <div className="w-full bg-secondary rounded-full h-1.5">
                <div className="bg-primary h-1.5 rounded-full transition-all" style={{ width: `${Math.min(s.cpu_percent ?? 0, 100)}%` }} />
              </div>
            </div>
            <div className="flex gap-2">
              <Button variant="outline" size="sm" className="flex-1 gap-1" onClick={() => openEdit(s)}>
                <Edit2 className="w-3 h-3" /> Edit
              </Button>
              <Button variant="outline" size="sm" className="text-destructive hover:text-destructive" onClick={() => del(s.id)}>
                <Trash2 className="w-3 h-3" />
              </Button>
            </div>
          </div>
        ))}
        {servers.length === 0 && (
          <div className="col-span-3 text-center py-16 text-muted-foreground">
            {selectedHighway ? 'No switch servers configured.' : 'Select a highway to view servers.'}
          </div>
        )}
      </div>

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="max-w-lg">
          <DialogHeader><DialogTitle>{editing ? 'Edit Switch Server' : 'New Switch Server'}</DialogTitle></DialogHeader>
          {scanning ? (
            <BarcodeScanner onScan={handleScan} onClose={() => setScanning(false)} />
          ) : (
            <>
              <Button variant="outline" size="sm" className="gap-2 w-full border-dashed" onClick={() => setScanning(true)}>
                <ScanLine className="w-4 h-4 text-primary" /> Scan This Device
              </Button>
              <div className="grid grid-cols-2 gap-3">
                {[
                  ['server_name','Server Name','text'],
                  ['server_id','Server ID','text'],
                  ['zone_id','Zone ID','text'],
                  ['highway_id','Highway ID','text'],
                  ['ip_address','IP Address','text'],
                  ['port','Port','number'],
                  ['firmware_version','Firmware Version','text'],
                ].map(([key, label, type]) => (
                  <div key={key} className={['server_name','ip_address'].includes(key) ? 'col-span-2' : ''}>
                    <Label className="text-xs">{label}</Label>
                    <Input type={type} value={form[key] || ''} onChange={e => setForm(p => ({ ...p, [key]: e.target.value }))} className="mt-1 h-8 text-sm" />
                  </div>
                ))}
                <div>
                  <Label className="text-xs">Status</Label>
                  <Select value={form.status} onValueChange={v => setForm(p => ({ ...p, status: v }))}>
                    <SelectTrigger className="mt-1 h-8 text-sm"><SelectValue /></SelectTrigger>
                    <SelectContent>
                      {['online','offline','degraded','fault'].map(s => <SelectItem key={s} value={s}>{s}</SelectItem>)}
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <div className="flex justify-end gap-2 pt-2">
                <Button variant="outline" size="sm" onClick={() => setOpen(false)}>Cancel</Button>
                <Button size="sm" onClick={save}>{editing ? 'Save' : 'Create'}</Button>
              </div>
            </>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}