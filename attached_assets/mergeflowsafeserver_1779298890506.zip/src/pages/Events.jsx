import { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import PageHeader from '@/components/shared/PageHeader';
import StatusBadge from '@/components/shared/StatusBadge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Button } from '@/components/ui/button';
import { Activity, AlertTriangle, Car, Zap, RefreshCw } from 'lucide-react';
import { format } from 'date-fns';

const EVENT_ICONS = {
  detection: Car,
  merge: Zap,
  conflict: AlertTriangle,
  speeding: AlertTriangle,
  fault: AlertTriangle,
};

const EVENT_COLORS = {
  detection: 'text-primary',
  merge: 'text-accent',
  conflict: 'text-destructive',
  speeding: 'text-yellow-400',
  fault: 'text-destructive',
};

export default function Events({ selectedHighway }) {
  const [events, setEvents] = useState([]);
  const [filterType, setFilterType] = useState('all');
  const [loading, setLoading] = useState(false);

  const load = () => {
    setLoading(true);
    const filter = selectedHighway ? { highway_id: selectedHighway } : {};
    base44.entities.VehicleEvent.filter(filter, '-created_date', 100)
      .then(setEvents)
      .finally(() => setLoading(false));
  };

  useEffect(() => { load(); }, [selectedHighway]);

  const displayed = filterType === 'all' ? events : events.filter(e => e.event_type === filterType);

  return (
    <div>
      <PageHeader title="Vehicle Events" subtitle="Real-time sensor event feed">
        <div className="flex gap-2">
          <Select value={filterType} onValueChange={setFilterType}>
            <SelectTrigger className="h-8 w-36 text-xs bg-secondary border-border"><SelectValue /></SelectTrigger>
            <SelectContent>
              {['all','detection','merge','conflict','speeding','fault'].map(t => (
                <SelectItem key={t} value={t} className="text-xs">{t === 'all' ? 'All Events' : t}</SelectItem>
              ))}
            </SelectContent>
          </Select>
          <Button variant="outline" size="sm" onClick={load} className="gap-1">
            <RefreshCw className={`w-3 h-3 ${loading ? 'animate-spin' : ''}`} />
          </Button>
        </div>
      </PageHeader>

      <div className="rounded-xl border border-border bg-card overflow-hidden">
        <div className="grid grid-cols-8 px-4 py-2 border-b border-border bg-secondary/50 text-xs text-muted-foreground font-mono uppercase tracking-wider">
          <span className="col-span-1">Type</span>
          <span className="col-span-1">Zone</span>
          <span className="col-span-1">Device</span>
          <span className="col-span-1">Vehicle</span>
          <span className="col-span-1">Speed</span>
          <span className="col-span-2">Coordinates</span>
          <span className="col-span-1">Time</span>
        </div>
        <div className="divide-y divide-border max-h-[600px] overflow-y-auto">
          {displayed.map(e => {
            const Icon = EVENT_ICONS[e.event_type] || Activity;
            const color = EVENT_COLORS[e.event_type] || 'text-muted-foreground';
            return (
              <div key={e.id} className="grid grid-cols-8 px-4 py-3 text-xs hover:bg-secondary/30 transition-colors">
                <div className={`col-span-1 flex items-center gap-1.5 font-semibold ${color}`}>
                  <Icon className="w-3.5 h-3.5" />
                  {e.event_type?.toUpperCase()}
                </div>
                <span className="col-span-1 font-mono text-muted-foreground self-center">{e.zone_id || '—'}</span>
                <span className="col-span-1 font-mono text-muted-foreground self-center">{e.device_id || '—'}</span>
                <span className="col-span-1 font-mono text-foreground self-center">{e.vehicle_id || '—'}</span>
                <span className="col-span-1 font-mono text-foreground self-center">{e.speed_mph ? `${e.speed_mph} mph` : '—'}</span>
                <div className="col-span-2 font-mono self-center">
                  {e.latitude != null && e.longitude != null ? (
                    <span className="text-accent">
                      {e.latitude.toFixed(5)}, {e.longitude.toFixed(5)}
                    </span>
                  ) : <span className="text-muted-foreground">—</span>}
                </div>
                <span className="col-span-1 font-mono text-muted-foreground self-center">
                  {e.created_date ? format(new Date(e.created_date), 'HH:mm:ss') : '—'}
                </span>
              </div>
            );
          })}
          {displayed.length === 0 && (
            <div className="text-center py-16 text-muted-foreground text-sm">
              {selectedHighway ? 'No events found.' : 'Select a highway to view events.'}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}