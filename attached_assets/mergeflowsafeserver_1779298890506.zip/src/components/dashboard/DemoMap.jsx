import { useEffect, useRef, useState } from 'react';
import { MapContainer, TileLayer, CircleMarker, Circle, Polyline, Marker, Popup, useMap } from 'react-leaflet';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';

// ── Geometry ─────────────────────────────────────────────────────────────────
// Highway runs W→E along latitude 32.7767
// Exit ramp curves from highway at exit point and merges back ~400m east
// Geofence sits at the merge nose (where ramp rejoins highway)

const HWY_LAT  = 32.7767;
const EXIT_LON = -96.8020;   // where exit begins
const MERGE_LON = -96.7940;  // where ramp rejoins — merge nose

// Merge nose (geofence center)
const MERGE = { lat: HWY_LAT, lon: MERGE_LON };

// Highway road: straight line well west → well east
const HIGHWAY_PATH = [
  [HWY_LAT, -96.8150],
  [HWY_LAT, -96.7800],
];

// Exit ramp: branches south from EXIT_LON, curves and re-joins at MERGE_LON
const RAMP_PATH = [
  [HWY_LAT,         EXIT_LON],       // exit nose on highway
  [HWY_LAT - 0.0015, EXIT_LON + 0.0020], // curve south-east
  [HWY_LAT - 0.0018, EXIT_LON + 0.0040],
  [HWY_LAT - 0.0010, EXIT_LON + 0.0060],
  [HWY_LAT,          MERGE_LON],     // re-join at merge nose
];

// 3 triangulation switch servers
const DEMO_SWITCHES = [
  { id: 'sw1', label: 'SW-1', server_id: 'SS-DEMO-01', lat: HWY_LAT + 0.0018, lon: MERGE_LON - 0.0015, color: '#f97316' },
  { id: 'sw2', label: 'SW-2', server_id: 'SS-DEMO-02', lat: HWY_LAT + 0.0018, lon: MERGE_LON + 0.0015, color: '#a78bfa' },
  { id: 'sw3', label: 'SW-3', server_id: 'SS-DEMO-03', lat: HWY_LAT - 0.0022, lon: MERGE_LON,           color: '#fb7185' },
];

const GEOFENCE_RADIUS = 120; // metres

// Event type → colour
const EV_COLOR = {
  detection: '#3b82f6',
  merge:     '#22c55e',
  conflict:  '#ef4444',
  speeding:  '#eab308',
};

// ── Helpers ───────────────────────────────────────────────────────────────────
function lerp(a, b, t) { return a + (b - a) * t; }

// Interpolate along a polyline given progress 0-1
function pointOnPath(path, t) {
  const n = path.length - 1;
  const seg = Math.min(Math.floor(t * n), n - 1);
  const local = (t * n) - seg;
  return [
    lerp(path[seg][0], path[seg + 1][0], local),
    lerp(path[seg][1], path[seg + 1][1], local),
  ];
}

function makeIcon(label, color) {
  return L.divIcon({
    html: `<div style="
      background:${color};color:#fff;font-family:monospace;font-size:10px;
      font-weight:700;padding:3px 7px;border-radius:4px;
      border:1.5px solid rgba(255,255,255,0.3);white-space:nowrap;
      box-shadow:0 2px 8px rgba(0,0,0,0.5);">${label}</div>`,
    className: '',
    iconAnchor: [20, 10],
  });
}

function pickEventType() {
  const r = Math.random();
  if (r < 0.10) return 'conflict';
  if (r < 0.22) return 'speeding';
  if (r < 0.55) return 'merge';
  return 'detection';
}

function makeVehicle(id, stream) {
  // stream: 'highway' or 'ramp'
  return {
    id,
    stream,
    progress: Math.random() * 0.6,
    event_type: pickEventType(),
    speed: (40 + Math.random() * 40).toFixed(1),
  };
}

function ZoomToMerge() {
  const map = useMap();
  useEffect(() => {
    map.setView([MERGE.lat - 0.0005, MERGE.lon - 0.0020], 16, { animate: true });
  }, [map]);
  return null;
}

const POPUP_OPTS = { className: 'mergesafe-popup', maxWidth: 220 };

// OSM Option A — segment data overlaid on the map (simulating what's fetched from Overpass API)
const OSM_SEGMENT_META = {
  'hwy-west':  { wayId: 'way/123456001', label: 'I-35E Approach',   speed: 62, freeFlow: 70, congestion: 'free',     color: '#22c55e' },
  'hwy-merge': { wayId: 'way/123456002', label: 'Merge Zone',        speed: 38, freeFlow: 70, congestion: 'heavy',    color: '#ef4444' },
  'hwy-east':  { wayId: 'way/123456003', label: 'Post-Merge',        speed: 55, freeFlow: 70, congestion: 'moderate', color: '#eab308' },
  ramp:        { wayId: 'way/123456004', label: 'Exit 42 On-Ramp',   speed: 25, freeFlow: 45, congestion: 'heavy',    color: '#ef4444' },
};

// ── Component ─────────────────────────────────────────────────────────────────
export default function DemoMap({ onEventGenerated }) {
  // 6 highway vehicles + 6 ramp vehicles
  const [vehicles, setVehicles] = useState(() => [
    ...Array.from({ length: 6 }, (_, i) => makeVehicle(`HWY-${i + 1}`, 'highway')),
    ...Array.from({ length: 6 }, (_, i) => makeVehicle(`RMP-${i + 1}`, 'ramp')),
  ]);

  const tickRef = useRef(null);

  useEffect(() => {
    tickRef.current = setInterval(() => {
      setVehicles(prev => prev.map(v => {
        const speed = v.stream === 'highway' ? 0.008 : 0.006;
        const newProg = v.progress + speed + Math.random() * 0.002;
        if (newProg >= 1) {
          if (onEventGenerated) onEventGenerated(v);
          return makeVehicle(v.id, v.stream);
        }
        return { ...v, progress: newProg };
      }));
    }, 100);
    return () => clearInterval(tickRef.current);
  }, [onEventGenerated]);

  return (
    <>
      <style>{`
        .mergesafe-popup .leaflet-popup-content-wrapper {
          background:#1e293b;border:1px solid #334155;border-radius:8px;
          box-shadow:0 4px 20px rgba(0,0,0,0.5);color:#f1f5f9;
        }
        .mergesafe-popup .leaflet-popup-tip { background:#1e293b; }
        .mergesafe-popup .leaflet-popup-close-button { color:#94a3b8 !important; }
      `}</style>

      <MapContainer
        center={[MERGE.lat - 0.0005, MERGE.lon - 0.0020]}
        zoom={16}
        style={{ height: '100%', width: '100%', borderRadius: '0.5rem', background: '#0f172a' }}
        zoomControl={true}
      >
        <TileLayer
          url="https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png"
          attribution='&copy; <a href="https://carto.com/">CARTO</a>'
        />
        <ZoomToMerge />

        {/* Highway West segment — OSM way/123456001 — color = TomTom congestion */}
        <Polyline
          positions={[[HWY_LAT, -96.8150], [HWY_LAT, EXIT_LON]]}
          pathOptions={{ color: OSM_SEGMENT_META['hwy-west'].color, weight: 7, opacity: 0.9 }}
        >
          <Popup {...POPUP_OPTS}>
            <div style={{ fontFamily: 'monospace', color: '#f1f5f9', minWidth: 170 }}>
              <div style={{ fontWeight: 700, marginBottom: 4, color: OSM_SEGMENT_META['hwy-west'].color }}>OSM Segment — Approach</div>
              <div style={{ fontSize: 11, color: '#94a3b8' }}>{OSM_SEGMENT_META['hwy-west'].wayId}</div>
              <div style={{ fontSize: 11, marginTop: 4 }}>TomTom Flow: <b style={{ color: OSM_SEGMENT_META['hwy-west'].color }}>{OSM_SEGMENT_META['hwy-west'].speed} mph</b> / {OSM_SEGMENT_META['hwy-west'].freeFlow} mph FF</div>
              <div style={{ fontSize: 10, color: '#94a3b8', marginTop: 2 }}>Congestion: {OSM_SEGMENT_META['hwy-west'].congestion.toUpperCase()}</div>
            </div>
          </Popup>
        </Polyline>

        {/* Highway Merge segment — OSM way/123456002 — heavy congestion */}
        <Polyline
          positions={[[HWY_LAT, EXIT_LON], [HWY_LAT, MERGE_LON]]}
          pathOptions={{ color: OSM_SEGMENT_META['hwy-merge'].color, weight: 7, opacity: 0.9 }}
        >
          <Popup {...POPUP_OPTS}>
            <div style={{ fontFamily: 'monospace', color: '#f1f5f9', minWidth: 170 }}>
              <div style={{ fontWeight: 700, marginBottom: 4, color: OSM_SEGMENT_META['hwy-merge'].color }}>OSM Segment — Merge Zone</div>
              <div style={{ fontSize: 11, color: '#94a3b8' }}>{OSM_SEGMENT_META['hwy-merge'].wayId}</div>
              <div style={{ fontSize: 11, marginTop: 4 }}>TomTom Flow: <b style={{ color: OSM_SEGMENT_META['hwy-merge'].color }}>{OSM_SEGMENT_META['hwy-merge'].speed} mph</b> / {OSM_SEGMENT_META['hwy-merge'].freeFlow} mph FF</div>
              <div style={{ fontSize: 10, color: '#94a3b8', marginTop: 2 }}>Congestion: {OSM_SEGMENT_META['hwy-merge'].congestion.toUpperCase()}</div>
            </div>
          </Popup>
        </Polyline>

        {/* Highway East segment — OSM way/123456003 — moderate */}
        <Polyline
          positions={[[HWY_LAT, MERGE_LON], [HWY_LAT, -96.7800]]}
          pathOptions={{ color: OSM_SEGMENT_META['hwy-east'].color, weight: 7, opacity: 0.9 }}
        >
          <Popup {...POPUP_OPTS}>
            <div style={{ fontFamily: 'monospace', color: '#f1f5f9', minWidth: 170 }}>
              <div style={{ fontWeight: 700, marginBottom: 4, color: OSM_SEGMENT_META['hwy-east'].color }}>OSM Segment — Post-Merge</div>
              <div style={{ fontSize: 11, color: '#94a3b8' }}>{OSM_SEGMENT_META['hwy-east'].wayId}</div>
              <div style={{ fontSize: 11, marginTop: 4 }}>TomTom Flow: <b style={{ color: OSM_SEGMENT_META['hwy-east'].color }}>{OSM_SEGMENT_META['hwy-east'].speed} mph</b> / {OSM_SEGMENT_META['hwy-east'].freeFlow} mph FF</div>
              <div style={{ fontSize: 10, color: '#94a3b8', marginTop: 2 }}>Congestion: {OSM_SEGMENT_META['hwy-east'].congestion.toUpperCase()}</div>
            </div>
          </Popup>
        </Polyline>

        {/* Exit ramp — OSM way/123456004 — heavy */}
        <Polyline
          positions={RAMP_PATH}
          pathOptions={{ color: OSM_SEGMENT_META.ramp.color, weight: 5, opacity: 0.85, dashArray: '8 4' }}
        >
          <Popup {...POPUP_OPTS}>
            <div style={{ fontFamily: 'monospace', color: '#f1f5f9', minWidth: 170 }}>
              <div style={{ fontWeight: 700, marginBottom: 4, color: OSM_SEGMENT_META.ramp.color }}>OSM Segment — Exit 42 Ramp</div>
              <div style={{ fontSize: 11, color: '#94a3b8' }}>{OSM_SEGMENT_META.ramp.wayId}</div>
              <div style={{ fontSize: 11, marginTop: 4 }}>TomTom Flow: <b style={{ color: OSM_SEGMENT_META.ramp.color }}>{OSM_SEGMENT_META.ramp.speed} mph</b> / {OSM_SEGMENT_META.ramp.freeFlow} mph FF</div>
              <div style={{ fontSize: 10, color: '#94a3b8', marginTop: 2 }}>Congestion: {OSM_SEGMENT_META.ramp.congestion.toUpperCase()}</div>
            </div>
          </Popup>
        </Polyline>

        {/* Geofence circle at merge nose */}
        <Circle
          center={[MERGE.lat, MERGE.lon]}
          radius={GEOFENCE_RADIUS}
          pathOptions={{ color: '#22c55e', fillColor: '#22c55e', fillOpacity: 0.10, weight: 2, dashArray: '6 4' }}
        />

        {/* Merge nose marker */}
        <CircleMarker
          center={[MERGE.lat, MERGE.lon]}
          radius={9}
          pathOptions={{ color: '#22c55e', fillColor: '#22c55e', fillOpacity: 0.95, weight: 2 }}
        >
          <Popup {...POPUP_OPTS}>
            <div style={{ fontFamily: 'monospace', color: '#f1f5f9', minWidth: 160 }}>
              <div style={{ fontWeight: 700, marginBottom: 4 }}>Merge Zone Alpha</div>
              <div style={{ fontSize: 11, color: '#94a3b8' }}>DEMO-MZ-001 · Exit 42</div>
              <div style={{ fontSize: 11, color: '#22c55e', marginTop: 4 }}>● ACTIVE — geofence {GEOFENCE_RADIUS}m</div>
            </div>
          </Popup>
        </CircleMarker>

        {/* Triangulation dashed lines */}
        {DEMO_SWITCHES.map(sw => (
          <Polyline
            key={`tline-${sw.id}`}
            positions={[[MERGE.lat, MERGE.lon], [sw.lat, sw.lon]]}
            pathOptions={{ color: sw.color, weight: 1.5, opacity: 0.45, dashArray: '5 5' }}
          />
        ))}

        {/* Switch server labels */}
        {DEMO_SWITCHES.map(sw => (
          <Marker key={sw.id} position={[sw.lat, sw.lon]} icon={makeIcon(sw.label, sw.color)}>
            <Popup {...POPUP_OPTS}>
              <div style={{ fontFamily: 'monospace', color: '#f1f5f9', minWidth: 160 }}>
                <div style={{ fontWeight: 700, marginBottom: 4, color: sw.color }}>{sw.label} — Switch Server</div>
                <div style={{ fontSize: 11, color: '#94a3b8' }}>{sw.server_id}</div>
                <div style={{ fontSize: 11, color: '#94a3b8', marginTop: 4 }}>Triangulation Node</div>
                <div style={{ fontSize: 11, color: '#f1f5f9', marginTop: 2 }}>
                  {sw.lat.toFixed(5)}, {sw.lon.toFixed(5)}
                </div>
              </div>
            </Popup>
          </Marker>
        ))}

        {/* Animated vehicles */}
        {vehicles.map(v => {
          const path = v.stream === 'highway' ? HIGHWAY_PATH : RAMP_PATH;
          const [lat, lon] = pointOnPath(path, v.progress);
          return (
            <CircleMarker
              key={v.id}
              center={[lat, lon]}
              radius={5}
              pathOptions={{
                color: EV_COLOR[v.event_type],
                fillColor: EV_COLOR[v.event_type],
                fillOpacity: 0.95,
                weight: 1.5,
              }}
            >
              <Popup {...POPUP_OPTS}>
                <div style={{ fontFamily: 'monospace', color: '#f1f5f9', minWidth: 150 }}>
                  <div style={{ fontWeight: 700, marginBottom: 4 }}>{v.id}</div>
                  <div style={{ fontSize: 11, display: 'flex', justifyContent: 'space-between' }}>
                    <span style={{ color: '#94a3b8' }}>Stream</span>
                    <span style={{ color: '#f1f5f9' }}>{v.stream === 'highway' ? 'Highway' : 'On-Ramp'}</span>
                  </div>
                  <div style={{ fontSize: 11, display: 'flex', justifyContent: 'space-between', marginTop: 2 }}>
                    <span style={{ color: '#94a3b8' }}>Event</span>
                    <span style={{ color: EV_COLOR[v.event_type], fontWeight: 600, textTransform: 'uppercase' }}>{v.event_type}</span>
                  </div>
                  <div style={{ fontSize: 11, display: 'flex', justifyContent: 'space-between', marginTop: 2 }}>
                    <span style={{ color: '#94a3b8' }}>Speed</span>
                    <span style={{ color: '#f1f5f9' }}>{v.speed} mph</span>
                  </div>
                </div>
              </Popup>
            </CircleMarker>
          );
        })}
      </MapContainer>
    </>
  );
}