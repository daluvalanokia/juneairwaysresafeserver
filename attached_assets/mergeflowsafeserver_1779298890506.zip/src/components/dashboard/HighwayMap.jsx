import { useEffect, useState } from 'react';
import { MapContainer, TileLayer, CircleMarker, Circle, Popup, useMap } from 'react-leaflet';
import 'leaflet/dist/leaflet.css';

const DEVICE_COLORS = {
  camera: '#3b82f6',
  lidar: '#22c55e',
  radar: '#eab308',
};

const ZONE_STATUS_COLORS = {
  active:      '#22c55e',
  inactive:    '#6b7280',
  fault:       '#ef4444',
  maintenance: '#eab308',
};

const STATUS_LABEL_COLORS = {
  online:      'color:#22c55e',
  active:      'color:#22c55e',
  offline:     'color:#6b7280',
  inactive:    'color:#6b7280',
  fault:       'color:#ef4444',
  degraded:    'color:#eab308',
  maintenance: 'color:#eab308',
  calibrating: 'color:#3b82f6',
};

function FitBounds({ zones, sensors }) {
  const map = useMap();
  useEffect(() => {
    const coords = [
      ...zones.filter(z => z.latitude && z.longitude).map(z => [z.latitude, z.longitude]),
      ...sensors.filter(s => s.latitude && s.longitude).map(s => [s.latitude, s.longitude]),
    ];
    if (coords.length > 0) {
      map.fitBounds(coords, { padding: [40, 40], maxZoom: 15 });
    }
  }, [zones, sensors, map]);
  return null;
}

// Popup content rendered as plain HTML string for Leaflet compatibility
function zonePopupHTML(z) {
  const color = ZONE_STATUS_COLORS[z.status] || '#6b7280';
  return `
    <div style="font-family:monospace;min-width:180px;padding:2px 0">
      <div style="font-size:13px;font-weight:700;margin-bottom:6px;color:#f1f5f9">${z.zone_name}</div>
      <div style="font-size:11px;color:#94a3b8;margin-bottom:4px">${z.zone_id}</div>
      <div style="display:flex;justify-content:space-between;font-size:11px;margin-bottom:2px">
        <span style="color:#94a3b8">Status</span>
        <span style="${STATUS_LABEL_COLORS[z.status] || 'color:#94a3b8'};font-weight:600;text-transform:uppercase">${z.status}</span>
      </div>
      <div style="display:flex;justify-content:space-between;font-size:11px;margin-bottom:2px">
        <span style="color:#94a3b8">Mile Marker</span>
        <span style="color:#f1f5f9">${z.mile_marker ?? '—'}</span>
      </div>
      <div style="display:flex;justify-content:space-between;font-size:11px;margin-bottom:2px">
        <span style="color:#94a3b8">Geofence</span>
        <span style="color:#f1f5f9">${z.geofence_radius ?? 500}m</span>
      </div>
      <div style="display:flex;justify-content:space-between;font-size:11px;margin-bottom:2px">
        <span style="color:#94a3b8">Coords</span>
        <span style="color:#f1f5f9">${z.latitude?.toFixed(5)}, ${z.longitude?.toFixed(5)}</span>
      </div>
      <div style="margin-top:6px;height:3px;border-radius:2px;background:${color};opacity:0.7"></div>
    </div>`;
}

function sensorPopupHTML(s) {
  const color = DEVICE_COLORS[s.device_type] || '#8b5cf6';
  return `
    <div style="font-family:monospace;min-width:180px;padding:2px 0">
      <div style="font-size:13px;font-weight:700;margin-bottom:6px;color:#f1f5f9">${s.device_name}</div>
      <div style="font-size:11px;color:#94a3b8;margin-bottom:4px">${s.device_id}</div>
      <div style="display:flex;justify-content:space-between;font-size:11px;margin-bottom:2px">
        <span style="color:#94a3b8">Type</span>
        <span style="color:${color};font-weight:600;text-transform:uppercase">${s.device_type}</span>
      </div>
      <div style="display:flex;justify-content:space-between;font-size:11px;margin-bottom:2px">
        <span style="color:#94a3b8">Status</span>
        <span style="${STATUS_LABEL_COLORS[s.status] || 'color:#94a3b8'};font-weight:600;text-transform:uppercase">${s.status}</span>
      </div>
      <div style="display:flex;justify-content:space-between;font-size:11px;margin-bottom:2px">
        <span style="color:#94a3b8">Height</span>
        <span style="color:#f1f5f9">${s.device_height ?? '—'}m</span>
      </div>
      <div style="display:flex;justify-content:space-between;font-size:11px;margin-bottom:2px">
        <span style="color:#94a3b8">Server</span>
        <span style="color:#f1f5f9">${s.server_id || '—'}</span>
      </div>
      <div style="display:flex;justify-content:space-between;font-size:11px;margin-bottom:2px">
        <span style="color:#94a3b8">Zone</span>
        <span style="color:#f1f5f9">${s.zone_id || '—'}</span>
      </div>
      <div style="display:flex;justify-content:space-between;font-size:11px;margin-bottom:2px">
        <span style="color:#94a3b8">Coords</span>
        <span style="color:#f1f5f9">${s.latitude?.toFixed(5)}, ${s.longitude?.toFixed(5)}</span>
      </div>
      ${s.firmware_version ? `<div style="display:flex;justify-content:space-between;font-size:11px;margin-bottom:2px">
        <span style="color:#94a3b8">Firmware</span>
        <span style="color:#f1f5f9">${s.firmware_version}</span>
      </div>` : ''}
      <div style="margin-top:6px;height:3px;border-radius:2px;background:${color};opacity:0.7"></div>
    </div>`;
}

const popupOptions = {
  className: 'mergesafe-popup',
  maxWidth: 240,
};

export default function HighwayMap({ zones, sensors }) {
  const hasData = zones.some(z => z.latitude && z.longitude) || sensors.some(s => s.latitude && s.longitude);

  const defaultCenter = zones[0]?.latitude
    ? [zones[0].latitude, zones[0].longitude]
    : [32.7767, -96.797];

  if (!hasData) {
    return (
      <div className="flex items-center justify-center h-full text-muted-foreground text-sm">
        No coordinate data available
      </div>
    );
  }

  return (
    <>
      <style>{`
        .mergesafe-popup .leaflet-popup-content-wrapper {
          background: #1e293b;
          border: 1px solid #334155;
          border-radius: 8px;
          box-shadow: 0 4px 20px rgba(0,0,0,0.5);
          color: #f1f5f9;
        }
        .mergesafe-popup .leaflet-popup-tip {
          background: #1e293b;
        }
        .mergesafe-popup .leaflet-popup-close-button {
          color: #94a3b8 !important;
        }
      `}</style>
      <MapContainer
        center={defaultCenter}
        zoom={13}
        style={{ height: '100%', width: '100%', borderRadius: '0.5rem', background: '#0f172a' }}
        zoomControl={true}
      >
        <TileLayer
          url="https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png"
          attribution='&copy; <a href="https://carto.com/">CARTO</a>'
        />
        <FitBounds zones={zones} sensors={sensors} />

        {/* Merge Zone geofence circles */}
        {zones.filter(z => z.latitude && z.longitude).map(z => (
          <Circle
            key={`zone-circle-${z.id}`}
            center={[z.latitude, z.longitude]}
            radius={z.geofence_radius || 500}
            pathOptions={{
              color: ZONE_STATUS_COLORS[z.status] || '#6b7280',
              fillColor: ZONE_STATUS_COLORS[z.status] || '#6b7280',
              fillOpacity: 0.08,
              weight: 1.5,
              dashArray: '6 4',
            }}
          />
        ))}

        {/* Merge Zone center markers — clickable */}
        {zones.filter(z => z.latitude && z.longitude).map(z => (
          <CircleMarker
            key={`zone-${z.id}`}
            center={[z.latitude, z.longitude]}
            radius={10}
            pathOptions={{
              color: ZONE_STATUS_COLORS[z.status] || '#6b7280',
              fillColor: ZONE_STATUS_COLORS[z.status] || '#6b7280',
              fillOpacity: 0.9,
              weight: 2,
            }}
          >
            <Popup {...popupOptions}>
              <div dangerouslySetInnerHTML={{ __html: zonePopupHTML(z) }} />
            </Popup>
          </CircleMarker>
        ))}

        {/* Sensor device markers — clickable */}
        {sensors.filter(s => s.latitude && s.longitude).map(s => (
          <CircleMarker
            key={`sensor-${s.id}`}
            center={[s.latitude, s.longitude]}
            radius={6}
            pathOptions={{
              color: DEVICE_COLORS[s.device_type] || '#8b5cf6',
              fillColor: DEVICE_COLORS[s.device_type] || '#8b5cf6',
              fillOpacity: s.status === 'online' ? 1 : 0.35,
              weight: 1.5,
            }}
          >
            <Popup {...popupOptions}>
              <div dangerouslySetInnerHTML={{ __html: sensorPopupHTML(s) }} />
            </Popup>
          </CircleMarker>
        ))}
      </MapContainer>
    </>
  );
}