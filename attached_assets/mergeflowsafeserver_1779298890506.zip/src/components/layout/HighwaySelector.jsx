import { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Route } from 'lucide-react';

export default function HighwaySelector({ selectedHighway, onHighwayChange }) {
  const [highways, setHighways] = useState([]);

  useEffect(() => {
    base44.entities.Highway.list().then(setHighways);
  }, []);

  const handleChange = (hwId) => {
    const hw = highways.find(h => h.highway_id === hwId);
    onHighwayChange(hw || null);
  };

  return (
    <div className="flex items-center gap-2">
      <Route className="w-4 h-4 text-primary" />
      <span className="text-xs text-muted-foreground font-mono">HIGHWAY</span>
      <Select value={selectedHighway?.highway_id || ''} onValueChange={handleChange}>
        <SelectTrigger className="w-48 h-8 text-xs bg-secondary border-border">
          <SelectValue placeholder="Select highway..." />
        </SelectTrigger>
        <SelectContent>
          {highways.map(h => (
            <SelectItem key={h.highway_id} value={h.highway_id} className="text-xs">
              {h.name}
            </SelectItem>
          ))}
        </SelectContent>
      </Select>
    </div>
  );
}