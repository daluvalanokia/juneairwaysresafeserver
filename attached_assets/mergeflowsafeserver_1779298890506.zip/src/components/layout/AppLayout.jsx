import { useState } from 'react';
import { Link, useLocation, Outlet } from 'react-router-dom';
import { 
  LayoutDashboard, Radio, Cpu, Settings, 
  ChevronLeft, ChevronRight, Activity, Map, Layers, Box, Users, LogIn, FileJson, BookOpen
} from 'lucide-react';
import HighwaySelector from '@/components/layout/HighwaySelector';

const NAV_ITEMS = [
  { path: '/', icon: LayoutDashboard, label: 'Overview' },
  { path: '/zones', icon: Map, label: 'Merge Zones' },
  { path: '/servers', icon: Cpu, label: 'Switch Servers' },
  { path: '/sensors', icon: Radio, label: 'Devices' },
  { path: '/triangulation', icon: Layers, label: 'Triangulation' },
  { path: '/events', icon: Activity, label: 'Events' },
  { path: '/traffic3d', icon: Box, label: '3D Traffic' },
  { path: '/users', icon: Users, label: 'Users' },
  { path: '/input-formats', icon: FileJson, label: 'Data Formats' },
  { path: '/requirements', icon: BookOpen, label: 'Requirements' },
  { path: '/settings', icon: Settings, label: 'Settings' },
  { path: '/portal', icon: LogIn, label: 'Portal' },
];

export default function AppLayout({ selectedHighway, onHighwayChange }) {
  const [collapsed, setCollapsed] = useState(false);
  const location = useLocation();

  return (
    <div className="flex h-screen bg-background overflow-hidden">
      {/* Sidebar */}
      <aside className={`flex flex-col bg-card border-r border-border transition-all duration-300 ${collapsed ? 'w-16' : 'w-56'}`}>
        {/* Logo */}
        <div className="flex items-center gap-3 px-4 py-4 border-b border-border">
          <div className="w-8 h-8 rounded-lg bg-primary/20 border border-primary/40 flex items-center justify-center flex-shrink-0">
            <div className="w-3 h-3 rounded-full bg-primary glow-primary" />
          </div>
          {!collapsed && (
            <div>
              <p className="text-xs font-bold text-primary tracking-widest uppercase">MergeSafeServer</p>
              <p className="text-[10px] text-muted-foreground">Control Platform</p>
            </div>
          )}
        </div>

        {/* Nav */}
        <nav className="flex-1 py-4 px-2 space-y-1 overflow-y-auto">
          {NAV_ITEMS.map(({ path, icon: Icon, label }) => {
            const active = location.pathname === path;
            return (
              <Link
                key={path}
                to={path}
                className={`flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm transition-all ${
                  active
                    ? 'bg-primary/15 text-primary border border-primary/25 glow-primary'
                    : 'text-muted-foreground hover:text-foreground hover:bg-secondary'
                }`}
              >
                <Icon className="w-4 h-4 flex-shrink-0" />
                {!collapsed && <span className="truncate">{label}</span>}
              </Link>
            );
          })}
        </nav>

        {/* Collapse toggle */}
        <button
          onClick={() => setCollapsed(!collapsed)}
          className="flex items-center justify-center py-3 border-t border-border text-muted-foreground hover:text-foreground transition-colors"
        >
          {collapsed ? <ChevronRight className="w-4 h-4" /> : <ChevronLeft className="w-4 h-4" />}
        </button>
      </aside>

      {/* Main */}
      <div className="flex-1 flex flex-col overflow-hidden">
        {/* Top bar */}
        <header className="flex items-center gap-4 px-6 py-3 border-b border-border bg-card/50 backdrop-blur-sm">
          <div className="flex items-center gap-2">
            <div className="w-2 h-2 rounded-full bg-accent animate-pulse" />
            <span className="text-xs text-muted-foreground font-mono">SYSTEM LIVE</span>
          </div>
          <div className="flex-1" />
          <HighwaySelector selectedHighway={selectedHighway} onHighwayChange={onHighwayChange} />
        </header>

        {/* Page content */}
        <main className="flex-1 overflow-y-auto p-6">
          <Outlet />
        </main>
      </div>
    </div>
  );
}