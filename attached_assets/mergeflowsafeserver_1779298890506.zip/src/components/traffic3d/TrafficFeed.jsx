import { useEffect, useRef, useState } from 'react';
import { Car, AlertTriangle, Gauge, ArrowRight, ChevronDown, ChevronUp } from 'lucide-react';

const CONGESTION_COLORS = {
  free:       { text: 'text-green-400',  dot: 'bg-green-400',  label: 'Free Flow' },
  moderate:   { text: 'text-yellow-400', dot: 'bg-yellow-400', label: 'Moderate' },
  heavy:      { text: 'text-red-400',    dot: 'bg-red-400',    label: 'Heavy' },
  standstill: { text: 'text-red-300',    dot: 'bg-red-600',    label: 'Standstill' },
  unknown:    { text: 'text-slate-400',  dot: 'bg-slate-500',  label: 'Unknown' },
};

function seedEvents(segments) {
  if (!segments?.length) return [];
  const now = Date.now();
  const events = [];
  segments.forEach((seg, i) => {
    const meta = CONGESTION_COLORS[seg.congestionLevel] ?? CONGESTION_COLORS.unknown;
    const ratio = seg.freeFlowSpeed > 0 ? seg.currentSpeed / seg.freeFlowSpeed : 1;
    events.push({
      id: `seed-${seg.id}-${now + i}`,
      type: 'flow',
      segment: seg.label || seg.id,
      speed: seg.currentSpeed,
      congestion: seg.congestionLevel,
      meta,
      vehicleCount: Math.round(4 + (1 - ratio) * 20),
      ts: now - i * 3000,
    });
    if (seg.congestionLevel === 'heavy' || seg.congestionLevel === 'standstill') {
      events.push({
        id: `seed-alert-${seg.id}-${now + i}`,
        type: 'alert',
        segment: seg.label || seg.id,
        speed: seg.currentSpeed,
        congestion: seg.congestionLevel,
        meta,
        ts: now - i * 3000 - 1500,
      });
    }
  });
  return events.sort((a, b) => b.ts - a.ts);
}

export default function TrafficFeed({ trafficData, isVisible }) {
  const [events, setEvents] = useState([]);
  const [collapsed, setCollapsed] = useState(false);
  const [autoScroll, setAutoScroll] = useState(true);
  const listRef = useRef(null);
  const dataRef = useRef(null);
  dataRef.current = trafficData;

  // Seed events whenever real data arrives
  useEffect(() => {
    if (!trafficData?.segments) return;
    setEvents(seedEvents(trafficData.segments));
  }, [trafficData]);

  // Live vehicle simulation — uses ref so never stale
  useEffect(() => {
    const interval = setInterval(() => {
      const segs = dataRef.current?.segments;
      if (!segs?.length) return;
      const seg = segs[Math.floor(Math.random() * segs.length)];
      const meta = CONGESTION_COLORS[seg.congestionLevel] ?? CONGESTION_COLORS.unknown;
      const jitter = Math.round((Math.random() - 0.5) * 8);
      const speed = Math.max(5, seg.currentSpeed + jitter);
      setEvents(prev => [{
        id: `live-${Date.now()}`,
        type: 'vehicle',
        segment: seg.label || seg.id,
        speed,
        congestion: seg.congestionLevel,
        meta,
        ts: Date.now(),
      }, ...prev.slice(0, 49)]);
    }, 1800);
    return () => clearInterval(interval);
  }, []); // ← runs once, never stale thanks to dataRef

  // Auto-scroll to top when new events come in
  useEffect(() => {
    if (autoScroll && listRef.current && !collapsed) {
      listRef.current.scrollTop = 0;
    }
  }, [events, autoScroll, collapsed]);

  if (!isVisible) return null;

  const fmt = (ts) => new Date(ts).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' });

  return (
    <div
      className="absolute bottom-10 right-3 w-72 bg-slate-900/97 backdrop-blur border border-slate-700 rounded-xl overflow-hidden flex flex-col shadow-2xl"
      style={{ maxHeight: collapsed ? 'auto' : '380px' }}
    >
      {/* Header */}
      <div className="flex items-center gap-2 px-3 py-2 border-b border-slate-800 flex-shrink-0 cursor-pointer select-none"
        onClick={() => setCollapsed(c => !c)}
      >
        <div className="w-1.5 h-1.5 rounded-full bg-green-400 animate-pulse" />
        <span className="text-[11px] font-semibold text-slate-100 font-mono">LIVE TRAFFIC FEED</span>
        <span className="ml-auto text-[10px] text-slate-500 font-mono mr-1">{events.length} events</span>
        {collapsed ? <ChevronUp className="w-3.5 h-3.5 text-slate-500" /> : <ChevronDown className="w-3.5 h-3.5 text-slate-500" />}
      </div>

      {!collapsed && (
        <>
          {/* Auto-scroll toggle */}
          <div className="flex items-center gap-2 px-3 py-1.5 border-b border-slate-800/50 bg-slate-900/60 flex-shrink-0">
            <span className="text-[10px] text-slate-500 font-mono">Auto-scroll</span>
            <button
              onClick={() => setAutoScroll(a => !a)}
              className={`w-7 h-4 rounded-full transition-colors relative ${autoScroll ? 'bg-green-500/70' : 'bg-slate-700'}`}
            >
              <span className={`absolute top-0.5 w-3 h-3 rounded-full bg-white shadow transition-all ${autoScroll ? 'left-3.5' : 'left-0.5'}`} />
            </button>
            <span className="ml-auto text-[10px] text-slate-600 font-mono">I-35E · Exit 42</span>
          </div>

          {/* Scrolling feed */}
          <div
            ref={listRef}
            className="overflow-y-auto flex-1 divide-y divide-slate-800/50"
            style={{ maxHeight: '300px' }}
            onWheel={() => setAutoScroll(false)}
          >
            {events.length === 0 && (
              <div className="px-3 py-6 text-center text-[11px] text-slate-500 font-mono">Awaiting data...</div>
            )}
            {events.map(ev => (
              <div key={ev.id} className="px-3 py-1.5 flex items-start gap-2 hover:bg-slate-800/40 transition-colors">
                <div className="flex-shrink-0 mt-0.5">
                  {ev.type === 'alert' ? (
                    <AlertTriangle className="w-3 h-3 text-red-400" />
                  ) : ev.type === 'vehicle' ? (
                    <Car className="w-3 h-3 text-blue-400" />
                  ) : (
                    <Gauge className="w-3 h-3 text-slate-400" />
                  )}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-1.5 justify-between">
                    <div className="flex items-center gap-1">
                      <div className={`w-1.5 h-1.5 rounded-full flex-shrink-0 ${ev.meta.dot}`} />
                      <span className="text-[10px] text-slate-300 truncate font-mono max-w-[110px]">{ev.segment}</span>
                    </div>
                    <span className="text-[9px] text-slate-600 font-mono flex-shrink-0">{fmt(ev.ts)}</span>
                  </div>
                  <div className="flex items-center gap-1 mt-0.5">
                    <span className={`text-[10px] font-bold ${ev.meta.text}`}>{ev.speed} mph</span>
                    <ArrowRight className="w-2.5 h-2.5 text-slate-600" />
                    <span className={`text-[10px] ${ev.meta.text}`}>{ev.meta.label}</span>
                    {ev.vehicleCount != null && (
                      <span className="text-[9px] text-slate-600 ml-auto">{ev.vehicleCount}v</span>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </>
      )}
    </div>
  );
}