import { useEffect, useState, useRef } from 'react';
import { MapContainer, TileLayer, Marker, Popup, Circle, Polyline, useMap } from 'react-leaflet';
import { Box, Radio, Camera, Radar, ScanLine, X } from 'lucide-react';
import 'leaflet/dist/leaflet.css';
import L from 'leaflet';
import { base44 } from '@/api/base44Client';

// Fix default marker icons for Leaflet in Vite
delete L.Icon.Default.prototype._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon-2x.png',
  iconUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon.png',
  shadowUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-shadow.png',
});

const DEFAULT_CENTER = [32.7767, -96.7980];

// Road geometry for I-35E Exit 42 area (default)
const HWY_LINE = [
  [32.7767, -96.8140],
  [32.7767, -96.8020],
  [32.7767, -96.7940],
  [32.7767, -96.7820],
];
const RAMP_LINE = [
  [32.7767, -96.8020],
  [32.7752, -96.8000],
  [32.7748, -96.7980],
  [32.7757, -96.7960],
  [32.7767, -96.7940],
];

const CONGESTION_COLORS = {
  free: '#22c55e',
  moderate: '#eab308',
  heavy: '#ef4444',
  standstill: '#7f1d1d',
  unknown: '#64748b',
};

const DEVICE_TYPE_COLORS = {
  camera: '#3b82f6',
  lidar:  '#a855f7',
  radar:  '#f59e0b',
};

const DEVICE_TYPE_ICONS = {
  camera: Camera,
  lidar:  Radar,
  radar:  ScanLine,
};

function makeDeviceIcon(type) {
  const color = DEVICE_TYPE_COLORS[type] || '#64748b';
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="24" height="28" viewBox="0 0 24 28">
    <circle cx="12" cy="12" r="10" fill="${color}" fill-opacity="0.9" stroke="white" stroke-width="2"/>
    <circle cx="12" cy="12" r="5" fill="white" fill-opacity="0.4"/>
    <polygon points="12,24 7,20 17,20" fill="${color}"/>
  </svg>`;
  return L.divIcon({
    html: svg,
    className: '',
    iconSize: [24, 28],
    iconAnchor: [12, 28],
    popupAnchor: [0, -28],
  });
}

// Sub-component to fly to a new center when highway changes
function MapController({ center }) {
  const map = useMap();
  useEffect(() => {
    if (center) {
      map.flyTo(center, 13, { duration: 1.2 });
    }
  }, [center[0], center[1]]);
  return null;
}

export default function MapLanding({ trafficData, selectedHighway, onLaunch3D }) {
  const segments = trafficData?.segments || [];
  const [devices, setDevices] = useState([]);
  const [selectedDevice, setSelectedDevice] = useState(null);

  const center = (selectedHighway?.latitude && selectedHighway?.longitude)
    ? [selectedHighway.latitude, selectedHighway.longitude]
    : DEFAULT_CENTER;

  // Load devices when highway changes
  useEffect(() => {
    setSelectedDevice(null);
    if (!selectedHighway?.highway_id && !selectedHighway?.id) {
      setDevices([]);
      return;
    }
    const hwId = selectedHighway.highway_id || selectedHighway.id;
    base44.entities.SensorDevice.filter({ highway_id: hwId }).then(setDevices).catch(() => setDevices([]));
  }, [selectedHighway?.highway_id, selectedHighway?.id]);

  const getSegColor = (idHint) => {
    const seg = segments.find(s => s.id === idHint || s.id?.includes(idHint) || s.label?.toLowerCase().includes(idHint));
    return CONGESTION_COLORS[seg?.congestionLevel] ?? '#64748b';
  };

  const mergeColor = getSegColor('merge');

  // Group devices by location (lat/lon) for display
  const deviceLocations = devices.reduce((acc, d) => {
    if (!d.latitude || !d.longitude) return acc;
    const key = `${d.latitude.toFixed(5)},${d.longitude.toFixed(5)}`;
    if (!acc[key]) acc[key] = { lat: d.latitude, lon: d.longitude, devices: [] };
    acc[key].devices.push(d);
    return acc;
  }, {});

  return (
    <div className="w-full h-full relative">
      <MapContainer
        center={center}
        zoom={selectedHighway?.latitude ? 13 : 15}
        style={{ width: '100%', height: '100%' }}
        zoomControl={false}
      >
        <TileLayer
          url="https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png"
          attribution='&copy; <a href="https://carto.com">CARTO</a>'
        />

        <MapController center={center} />

        {/* Default I-35E road geometry (shown when no highway selected) */}
        {!selectedHighway && (
          <>
            <Polyline positions={HWY_LINE.slice(0, 2)} pathOptions={{ color: getSegColor('approach'), weight: 8, opacity: 0.9 }} />
            <Polyline positions={HWY_LINE.slice(1, 3)} pathOptions={{ color: getSegColor('merge'), weight: 10, opacity: 0.95 }} />
            <Polyline positions={HWY_LINE.slice(2)} pathOptions={{ color: getSegColor('post'), weight: 8, opacity: 0.9 }} />
            <Polyline positions={RAMP_LINE} pathOptions={{ color: getSegColor('ramp'), weight: 5, opacity: 0.85, dashArray: '8 4' }} />
            <Circle center={DEFAULT_CENTER} radius={200} pathOptions={{ color: mergeColor, fillColor: mergeColor, fillOpacity: 0.1, weight: 2, opacity: 0.6 }} />
            <Marker position={[32.7767, -96.7940]}>
              <Popup>
                <div className="text-xs font-mono"><strong>Merge Point — Exit 42</strong><br />I-35E · Dallas, TX</div>
              </Popup>
            </Marker>
          </>
        )}

        {/* Highway center marker */}
        {selectedHighway?.latitude && selectedHighway?.longitude && (
          <Circle
            center={[selectedHighway.latitude, selectedHighway.longitude]}
            radius={300}
            pathOptions={{ color: '#3b82f6', fillColor: '#3b82f6', fillOpacity: 0.08, weight: 2, opacity: 0.5 }}
          />
        )}

        {/* Device location markers */}
        {Object.values(deviceLocations).map((loc) => {
          const primaryType = loc.devices[0]?.device_type || 'camera';
          const icon = makeDeviceIcon(primaryType);
          const mm = loc.devices[0]?.mile_marker;
          return (
            <Marker
              key={`${loc.lat},${loc.lon}`}
              position={[loc.lat, loc.lon]}
              icon={icon}
              eventHandlers={{
                click: () => setSelectedDevice(loc),
              }}
            >
              <Popup>
                <div className="text-xs font-mono min-w-[160px]">
                  <strong className="block mb-1">MM {mm ?? '—'} · {loc.devices.length} device{loc.devices.length > 1 ? 's' : ''}</strong>
                  {loc.devices.map(d => (
                    <div key={d.id} className="flex items-center gap-1 mt-0.5">
                      <span className="uppercase font-bold" style={{ color: DEVICE_TYPE_COLORS[d.device_type] }}>{d.device_type}</span>
                      <span className="text-gray-500">·</span>
                      <span>{d.device_name}</span>
                    </div>
                  ))}
                  {loc.devices[0]?.location_comment && (
                    <div className="mt-1 text-gray-400 italic">{loc.devices[0].location_comment}</div>
                  )}
                </div>
              </Popup>
            </Marker>
          );
        })}
      </MapContainer>

      {/* Top overlay — title */}
      <div className="absolute top-3 left-3 z-[1000] bg-slate-900/95 backdrop-blur border border-slate-700 rounded-xl px-3 py-2.5 flex items-center gap-2">
        <Radio className="w-3.5 h-3.5 text-green-400 animate-pulse" />
        <div>
          <div className="text-xs font-bold text-slate-100 font-mono">
            {selectedHighway?.name ? selectedHighway.name.toUpperCase() : 'I-35E · EXIT 42'}
          </div>
          <div className="text-[10px] text-slate-400">
            {selectedHighway ? `${selectedHighway.state || ''} · Merge Zone Monitor` : 'Dallas, TX · Merge Zone Monitor'}
          </div>
        </div>
        {trafficData?.simulated && (
          <span className="ml-2 text-[10px] text-yellow-400 font-mono bg-yellow-500/10 border border-yellow-500/20 px-1.5 py-0.5 rounded">DEMO</span>
        )}
      </div>

      {/* Device legend */}
      {devices.length > 0 && (
        <div className="absolute top-3 left-1/2 -translate-x-1/2 z-[1000] bg-slate-900/90 backdrop-blur border border-slate-700 rounded-xl px-3 py-2 flex items-center gap-3">
          <span className="text-[10px] text-slate-500 font-mono">{devices.length} DEVICES</span>
          {['camera','lidar','radar'].map(t => {
            const count = devices.filter(d => d.device_type === t).length;
            if (!count) return null;
            return (
              <div key={t} className="flex items-center gap-1">
                <div className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: DEVICE_TYPE_COLORS[t] }} />
                <span className="text-[10px] text-slate-300 font-mono uppercase">{t} ({count})</span>
              </div>
            );
          })}
        </div>
      )}

      {/* Segment stats overlay */}
      {segments.length > 0 && (
        <div className="absolute top-3 right-3 z-[1000] bg-slate-900/95 backdrop-blur border border-slate-700 rounded-xl p-3 min-w-[180px]">
          <div className="text-[10px] text-slate-500 font-mono mb-2">LIVE SEGMENTS</div>
          {segments.map(seg => (
            <div key={seg.id} className="flex items-center justify-between gap-2 mb-1">
              <div className="flex items-center gap-1.5">
                <div className="w-2 h-2 rounded-sm" style={{ backgroundColor: CONGESTION_COLORS[seg.congestionLevel] ?? '#64748b' }} />
                <span className="text-[10px] text-slate-300 font-mono truncate max-w-[90px]">{seg.label || seg.id}</span>
              </div>
              <span className="text-[10px] font-bold font-mono" style={{ color: CONGESTION_COLORS[seg.congestionLevel] ?? '#64748b' }}>
                {seg.currentSpeed} mph
              </span>
            </div>
          ))}
        </div>
      )}

      {/* Selected device panel */}
      {selectedDevice && (
        <div className="absolute bottom-20 left-3 z-[1000] bg-slate-900/97 backdrop-blur border border-slate-600 rounded-xl p-4 min-w-[240px] max-w-[300px] shadow-2xl">
          <div className="flex items-center justify-between mb-3">
            <div>
              <div className="text-xs font-bold text-slate-100 font-mono">
                MM {selectedDevice.devices[0]?.mile_marker ?? '—'}
              </div>
              {selectedDevice.devices[0]?.location_comment && (
                <div className="text-[10px] text-slate-400 mt-0.5">{selectedDevice.devices[0].location_comment}</div>
              )}
            </div>
            <button onClick={() => setSelectedDevice(null)} className="text-slate-500 hover:text-slate-200 transition-colors">
              <X className="w-3.5 h-3.5" />
            </button>
          </div>
          <div className="text-[10px] text-slate-500 font-mono mb-2">DEVICES AT THIS LOCATION</div>
          <div className="space-y-2">
            {selectedDevice.devices.map(d => {
              const Icon = DEVICE_TYPE_ICONS[d.device_type] || Camera;
              return (
                <div key={d.id} className="flex items-center gap-2 bg-slate-800/60 rounded-lg px-2.5 py-2">
                  <div className="w-6 h-6 rounded-md flex items-center justify-center flex-shrink-0" style={{ backgroundColor: DEVICE_TYPE_COLORS[d.device_type] + '33', border: `1px solid ${DEVICE_TYPE_COLORS[d.device_type]}55` }}>
                    <Icon className="w-3.5 h-3.5" style={{ color: DEVICE_TYPE_COLORS[d.device_type] }} />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="text-[11px] font-semibold text-slate-200 truncate">{d.device_name}</div>
                    <div className="flex items-center gap-2 mt-0.5">
                      <span className="text-[10px] uppercase font-mono" style={{ color: DEVICE_TYPE_COLORS[d.device_type] }}>{d.device_type}</span>
                      <span className="text-[10px] text-slate-500">·</span>
                      <span className={`text-[10px] font-mono ${d.status === 'online' ? 'text-green-400' : d.status === 'fault' ? 'text-red-400' : 'text-slate-400'}`}>{d.status}</span>
                    </div>
                  </div>
                  <div className={`w-1.5 h-1.5 rounded-full flex-shrink-0 ${d.status === 'online' ? 'bg-green-400 animate-pulse' : d.status === 'fault' ? 'bg-red-400' : 'bg-slate-500'}`} />
                </div>
              );
            })}
          </div>
          <div className="mt-2 pt-2 border-t border-slate-800 flex justify-between text-[10px] text-slate-500 font-mono">
            <span>{selectedDevice.lat.toFixed(5)}, {selectedDevice.lon.toFixed(5)}</span>
            <span>{selectedDevice.devices.length} unit{selectedDevice.devices.length > 1 ? 's' : ''}</span>
          </div>
        </div>
      )}

      {/* Launch 3D button */}
      <div className="absolute bottom-6 left-1/2 -translate-x-1/2 z-[1000]">
        <button
          onClick={onLaunch3D}
          className="flex items-center gap-2.5 bg-primary text-primary-foreground px-5 py-2.5 rounded-xl font-semibold text-sm shadow-xl hover:opacity-90 transition-opacity"
        >
          <Box className="w-4 h-4" />
          Launch 3D View
        </button>
      </div>
    </div>
  );
}