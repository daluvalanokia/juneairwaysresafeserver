import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { RefreshCw, Layers, Radio, AlertTriangle, CheckCircle2, Minus } from 'lucide-react';

const CONGESTION_META = {
  free:       { label: 'Free Flow',  color: 'bg-green-500/20 text-green-400 border-green-500/30' },
  moderate:   { label: 'Moderate',   color: 'bg-yellow-500/20 text-yellow-400 border-yellow-500/30' },
  heavy:      { label: 'Heavy',      color: 'bg-red-500/20 text-red-400 border-red-500/30' },
  standstill: { label: 'Standstill', color: 'bg-red-900/30 text-red-300 border-red-800/40' },
  unknown:    { label: 'No Data',    color: 'bg-slate-700/30 text-slate-400 border-slate-600/30' },
};

export default function TrafficControls({ trafficData, lastUpdate, onRefresh, isLoading, mergeZone }) {
  const segments = trafficData?.segments || [];
  const isSimulated = trafficData?.simulated;

  return (
    <div className="absolute top-3 left-3 right-3 flex items-start justify-between gap-3 pointer-events-none">
      {/* Left panel — zone info */}
      <div className="pointer-events-auto bg-slate-900/90 backdrop-blur border border-slate-700 rounded-xl p-3 min-w-[200px] max-w-[240px]">
        <div className="flex items-center gap-2 mb-2">
          <Radio className="w-3.5 h-3.5 text-green-400 animate-pulse" />
          <span className="text-xs font-semibold text-slate-100 font-mono">LIVE 3D VIEW</span>
          {isSimulated && (
            <span className="text-[10px] text-yellow-400 font-mono ml-auto">SIM</span>
          )}
        </div>
        <div className="text-xs text-slate-400 mb-1">OSM + TomTom — Exit 42</div>
        <div className="text-[11px] text-slate-500 font-mono">I-35E · Dallas, TX</div>
        {lastUpdate && (
          <div className="text-[10px] text-slate-600 mt-2">Updated {lastUpdate}</div>
        )}
      </div>

      {/* Center — segment traffic legend */}
      <div className="pointer-events-auto flex flex-col gap-1.5 bg-slate-900/90 backdrop-blur border border-slate-700 rounded-xl p-3 min-w-[190px]">
        <div className="flex items-center gap-1.5 mb-1">
          <Layers className="w-3.5 h-3.5 text-blue-400" />
          <span className="text-xs font-semibold text-slate-100">OSM Segments</span>
        </div>
        {segments.map(seg => {
          const meta = CONGESTION_META[seg.congestionLevel] ?? CONGESTION_META.unknown;
          return (
            <div key={seg.id} className="flex items-center justify-between gap-2">
              <span className="text-[11px] text-slate-300 truncate">{seg.label || seg.id}</span>
              <span className={`text-[10px] px-1.5 py-0.5 rounded border font-mono ${meta.color}`}>
                {seg.currentSpeed ? `${seg.currentSpeed}mph` : meta.label}
              </span>
            </div>
          );
        })}
        {segments.length === 0 && (
          <div className="text-[11px] text-slate-500">Loading segments...</div>
        )}
      </div>

      {/* Right — refresh + legend */}
      <div className="pointer-events-auto flex flex-col gap-2 items-end">
        <Button
          size="sm"
          variant="outline"
          onClick={onRefresh}
          disabled={isLoading}
          className="bg-slate-900/90 backdrop-blur border-slate-700 text-slate-300 h-8 text-xs gap-1.5"
        >
          <RefreshCw className={`w-3.5 h-3.5 ${isLoading ? 'animate-spin' : ''}`} />
          Refresh
        </Button>

        <div className="bg-slate-900/90 backdrop-blur border border-slate-700 rounded-xl p-2.5 text-[10px] font-mono">
          <div className="text-slate-500 mb-1.5">CONGESTION LEGEND</div>
          {Object.entries(CONGESTION_META).filter(([k]) => k !== 'unknown').map(([key, m]) => (
            <div key={key} className="flex items-center gap-1.5 mb-0.5">
              <div className={`w-2.5 h-2.5 rounded-sm border ${m.color}`} />
              <span className="text-slate-400">{m.label}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}