import { useEffect, useRef } from 'react';

// Road layout for the 2D canvas (normalized coordinates 0..1 → canvas pixels)
// We draw: highway (left→right), merge zone, ramp (diagonal bottom→highway)

const CONGESTION_COLORS = {
  free:       '#22c55e',
  moderate:   '#eab308',
  heavy:      '#ef4444',
  standstill: '#7f1d1d',
  unknown:    '#475569',
};

const HWY_COLORS = ['#ffffff','#ccccff','#ffddbb','#aaddff','#ffcccc','#ddffdd','#ffe0a0'];
const RAMP_COLORS = ['#ffaa44','#ff9933','#ffbb55','#ffcc66'];

function rand(a, b) { return a + Math.random() * (b - a); }
function pick(arr) { return arr[Math.floor(Math.random() * arr.length)]; }

// Build road path points in canvas space (called after we know W/H)
function buildRoads(W, H) {
  const midY = H * 0.42;
  const rampStartX = W * 0.18;
  const mergeX     = W * 0.55;
  const laneH      = 28; // pixels per lane

  return {
    // hwy-west: 3 lanes, left edge → merge start
    hwyWest:  { x1: 0,          x2: rampStartX, y: midY, lanes: 3, laneH, id: 'hwy-west' },
    // hwy-merge: 4 lanes, ramp-start → merge point
    hwyMerge: { x1: rampStartX, x2: mergeX,     y: midY, lanes: 4, laneH, id: 'hwy-merge' },
    // hwy-east: 3 lanes, merge point → right edge
    hwyEast:  { x1: mergeX,     x2: W,          y: midY, lanes: 3, laneH, id: 'hwy-east' },
    // ramp: curves from bottom-left up to hwy at rampStartX
    ramp: {
      // Cubic bezier control points
      p0: { x: W * 0.08, y: H * 0.80 },
      p1: { x: W * 0.12, y: H * 0.60 },
      p2: { x: W * 0.16, y: H * 0.48 },
      p3: { x: rampStartX, y: midY },
      id: 'ramp',
    },
    mergeX,
    midY,
    laneH,
  };
}

// Evaluate cubic bezier at t
function bezier(p0, p1, p2, p3, t) {
  const mt = 1 - t;
  return {
    x: mt*mt*mt*p0.x + 3*mt*mt*t*p1.x + 3*mt*t*t*p2.x + t*t*t*p3.x,
    y: mt*mt*mt*p0.y + 3*mt*mt*t*p1.y + 3*mt*t*t*p2.y + t*t*t*p3.y,
  };
}
function bezierTangent(p0, p1, p2, p3, t) {
  const mt = 1 - t;
  return {
    x: 3*(mt*mt*(p1.x-p0.x) + 2*mt*t*(p2.x-p1.x) + t*t*(p3.x-p2.x)),
    y: 3*(mt*mt*(p1.y-p0.y) + 2*mt*t*(p2.y-p1.y) + t*t*(p3.y-p2.y)),
  };
}

function initVehicles(roads) {
  const vehicles = [];

  // Highway chain: west → merge → east as globalT 0..3
  const HWY_CHAIN = [roads.hwyWest, roads.hwyMerge, roads.hwyEast];
  for (let i = 0; i < 20; i++) {
    const seg = HWY_CHAIN[Math.floor(Math.random() * 3)];
    const laneIdx = Math.floor(Math.random() * seg.lanes);
    vehicles.push({
      type: 'hwy',
      globalT: rand(0, 3),
      speed: rand(0.0012, 0.0018),
      baseSpeed: rand(0.0012, 0.0018),
      laneIdx,
      color: pick(HWY_COLORS),
      w: rand(14, 18), h: rand(8, 11),
    });
  }

  // Ramp vehicles
  for (let i = 0; i < 7; i++) {
    vehicles.push({
      type: 'ramp',
      globalT: rand(0, 2),
      speed: rand(0.0008, 0.0014),
      baseSpeed: rand(0.0008, 0.0014),
      color: pick(RAMP_COLORS),
      w: rand(13, 16), h: rand(7, 10),
    });
  }

  return vehicles;
}

function getVehiclePos(v, roads) {
  const HWY_CHAIN = [roads.hwyWest, roads.hwyMerge, roads.hwyEast];
  if (v.type === 'hwy') {
    let gt = v.globalT % 3;
    if (gt < 0) gt += 3;
    const segIdx = Math.min(2, Math.floor(gt));
    const t = gt - segIdx;
    const seg = HWY_CHAIN[segIdx];
    const x = seg.x1 + t * (seg.x2 - seg.x1);
    // Lane offset: stack lanes above/below centre
    const laneOff = (v.laneIdx - (seg.lanes - 1) / 2) * seg.laneH;
    const y = seg.y + laneOff;
    return { x, y, angle: 0 };
  } else {
    // ramp: 0-1 on bezier, 1-2 merges onto hwy-merge
    let gt = v.globalT % 2;
    if (gt < 0) gt += 2;
    if (gt < 1) {
      const r = roads.ramp;
      const pos = bezier(r.p0, r.p1, r.p2, r.p3, gt);
      const tan = bezierTangent(r.p0, r.p1, r.p2, r.p3, Math.min(gt, 0.999));
      return { x: pos.x, y: pos.y, angle: Math.atan2(tan.y, tan.x) };
    } else {
      const t = gt - 1;
      const seg = roads.hwyMerge;
      const x = seg.x1 + t * (seg.x2 - seg.x1);
      return { x, y: seg.y, angle: 0 };
    }
  }
}

function drawRoads(ctx, roads, segments) {
  const getColor = (id) => {
    if (!segments) return CONGESTION_COLORS.unknown;
    const s = segments.find(s => s.id === id);
    return CONGESTION_COLORS[s?.congestionLevel] ?? CONGESTION_COLORS.unknown;
  };

  // Draw highway sections
  [roads.hwyWest, roads.hwyMerge, roads.hwyEast].forEach(seg => {
    const totalH = seg.lanes * seg.laneH;
    const topY = seg.y - totalH / 2;
    ctx.fillStyle = '#1e293b';
    ctx.fillRect(seg.x1, topY, seg.x2 - seg.x1, totalH);
    // Congestion color stripe
    ctx.fillStyle = getColor(seg.id);
    ctx.globalAlpha = 0.25;
    ctx.fillRect(seg.x1, topY, seg.x2 - seg.x1, totalH);
    ctx.globalAlpha = 1;
    // Lane dividers
    ctx.strokeStyle = '#ffffff22';
    ctx.lineWidth = 1;
    ctx.setLineDash([14, 10]);
    for (let l = 1; l < seg.lanes; l++) {
      const ly = topY + l * seg.laneH;
      ctx.beginPath();
      ctx.moveTo(seg.x1, ly);
      ctx.lineTo(seg.x2, ly);
      ctx.stroke();
    }
    ctx.setLineDash([]);
    // Road border
    ctx.strokeStyle = '#334155';
    ctx.lineWidth = 1.5;
    ctx.strokeRect(seg.x1, topY, seg.x2 - seg.x1, totalH);
  });

  // Ramp
  const r = roads.ramp;
  ctx.strokeStyle = '#1e293b';
  ctx.lineWidth = 18;
  ctx.beginPath();
  ctx.moveTo(r.p0.x, r.p0.y);
  ctx.bezierCurveTo(r.p1.x, r.p1.y, r.p2.x, r.p2.y, r.p3.x, r.p3.y);
  ctx.stroke();
  ctx.strokeStyle = getColor('ramp');
  ctx.globalAlpha = 0.3;
  ctx.lineWidth = 14;
  ctx.beginPath();
  ctx.moveTo(r.p0.x, r.p0.y);
  ctx.bezierCurveTo(r.p1.x, r.p1.y, r.p2.x, r.p2.y, r.p3.x, r.p3.y);
  ctx.stroke();
  ctx.globalAlpha = 1;

  // Merge point glow
  ctx.save();
  const grad = ctx.createRadialGradient(roads.mergeX, roads.midY, 2, roads.mergeX, roads.midY, 22);
  grad.addColorStop(0, '#22c55e88');
  grad.addColorStop(1, '#22c55e00');
  ctx.fillStyle = grad;
  ctx.beginPath();
  ctx.arc(roads.mergeX, roads.midY, 22, 0, Math.PI * 2);
  ctx.fill();
  ctx.restore();
}

function drawVehicle(ctx, v, pos) {
  ctx.save();
  ctx.translate(pos.x, pos.y);
  ctx.rotate(pos.angle);

  const hw = v.w / 2, hh = v.h / 2;

  // Car body
  ctx.fillStyle = v.color;
  ctx.shadowColor = v.color;
  ctx.shadowBlur = 6;
  ctx.beginPath();
  ctx.roundRect(-hw, -hh, v.w, v.h, 2);
  ctx.fill();
  ctx.shadowBlur = 0;

  // Windshield
  ctx.fillStyle = '#1a3a5a';
  ctx.globalAlpha = 0.8;
  ctx.beginPath();
  ctx.roundRect(-hw * 0.55, -hh * 0.55, v.w * 0.55, v.h * 0.55, 1);
  ctx.fill();
  ctx.globalAlpha = 1;

  // Headlights (front = +x)
  ctx.fillStyle = '#ffffcc';
  ctx.shadowColor = '#ffffff';
  ctx.shadowBlur = 8;
  [-hh * 0.5, hh * 0.5].forEach(yo => {
    ctx.beginPath();
    ctx.ellipse(hw - 1, yo, 2, 1.5, 0, 0, Math.PI * 2);
    ctx.fill();
  });

  // Taillights
  ctx.fillStyle = '#ff2200';
  ctx.shadowColor = '#ff2200';
  ctx.shadowBlur = 7;
  [-hh * 0.5, hh * 0.5].forEach(yo => {
    ctx.beginPath();
    ctx.ellipse(-hw + 1, yo, 2, 1.5, 0, 0, Math.PI * 2);
    ctx.fill();
  });

  ctx.shadowBlur = 0;
  ctx.restore();
}

export default function TrafficCanvas2D({ trafficData }) {
  const canvasRef = useRef(null);
  const stateRef = useRef(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');

    const resize = () => {
      canvas.width  = canvas.offsetWidth;
      canvas.height = canvas.offsetHeight;
      const roads = buildRoads(canvas.width, canvas.height);
      if (stateRef.current) {
        stateRef.current.roads = roads;
      } else {
        stateRef.current = { roads, vehicles: initVehicles(roads) };
      }
    };
    resize();
    window.addEventListener('resize', resize);

    let animId;
    function frame() {
      animId = requestAnimationFrame(frame);
      const { roads, vehicles } = stateRef.current;
      const segs = trafficData?.segments;

      ctx.clearRect(0, 0, canvas.width, canvas.height);
      // Background
      ctx.fillStyle = '#0f172a';
      ctx.fillRect(0, 0, canvas.width, canvas.height);

      drawRoads(ctx, roads, segs);

      // Update + draw vehicles
      vehicles.forEach(v => {
        v.globalT += v.speed;
        const pos = getVehiclePos(v, roads);
        drawVehicle(ctx, v, pos);
      });

      // Labels
      ctx.fillStyle = '#94a3b8';
      ctx.font = '10px monospace';
      ctx.fillText('I-35E WESTBOUND', 10, roads.midY - roads.laneH * 2 - 8);
      ctx.fillText('MERGE ZONE', roads.hwyMerge.x1 + 8, roads.midY - roads.laneH * 2.5 - 8);
      ctx.fillText('EXIT 42 ON-RAMP', roads.ramp.p0.x - 10, roads.ramp.p0.y + 16);

      // Speed labels per segment
      if (segs) {
        segs.forEach(s => {
          const seg = [roads.hwyWest, roads.hwyMerge, roads.hwyEast].find(r => r.id === s.id);
          if (!seg) return;
          const midX = (seg.x1 + seg.x2) / 2;
          const topY = seg.y - seg.lanes * seg.laneH / 2 - 14;
          ctx.fillStyle = CONGESTION_COLORS[s.congestionLevel] ?? '#94a3b8';
          ctx.font = 'bold 11px monospace';
          ctx.fillText(`${s.currentSpeed} mph`, midX - 22, topY);
        });
      }
    }
    frame();

    return () => {
      cancelAnimationFrame(animId);
      window.removeEventListener('resize', resize);
    };
  }, []);

  // Keep traffic data accessible in the animation loop via ref
  const trafficRef = useRef(trafficData);
  useEffect(() => { trafficRef.current = trafficData; }, [trafficData]);

  // Update vehicle speeds when traffic data changes
  useEffect(() => {
    if (!stateRef.current || !trafficData?.segments) return;
    const segSpeedMap = {};
    trafficData.segments.forEach(s => { segSpeedMap[s.id] = s.currentSpeed; });

    stateRef.current.vehicles.forEach(v => {
      let mph = 45;
      if (v.type === 'hwy') {
        const gt = ((v.globalT % 3) + 3) % 3;
        const segIdx = Math.min(2, Math.floor(gt));
        const ids = ['hwy-west', 'hwy-merge', 'hwy-east'];
        mph = segSpeedMap[ids[segIdx]] ?? 45;
      } else {
        mph = segSpeedMap['ramp'] ?? segSpeedMap['hwy-merge'] ?? 35;
      }
      // Normalize: 65 mph → ~0.002, 10 mph → ~0.0003
      v.speed = Math.max(0.0003, (mph / 65) * 0.002) + rand(-0.0001, 0.0001);
    });
  }, [trafficData]);

  return (
    <canvas
      ref={canvasRef}
      className="w-full h-full"
      style={{ display: 'block' }}
    />
  );
}