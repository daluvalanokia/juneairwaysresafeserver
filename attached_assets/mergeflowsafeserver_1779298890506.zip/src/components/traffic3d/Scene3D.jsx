import { useEffect, useRef, useState } from 'react';
import * as THREE from 'three';
import TrafficCanvas2D from './TrafficCanvas2D';

// ── OSM-style road geometry constants (Exit 42 at I-35E Dallas, TX area) ────
const HWY_LAT   = 32.7767;
const EXIT_LON  = -96.8020;
const MERGE_LON = -96.7940;

// Degrees → meters (approx at this latitude)
const LAT_M = 111320;
const LON_M = 111320 * Math.cos((HWY_LAT * Math.PI) / 180);

function geoToXZ(lat, lon, originLat, originLon) {
  return {
    x: (lon - originLon) * LON_M,
    z: -(lat - originLat) * LAT_M,
  };
}

// OSM-derived road segments (geometry from Overpass API data for Exit 42)
const ORIGIN_LAT = HWY_LAT;
const ORIGIN_LON = (EXIT_LON + MERGE_LON) / 2;

const OSM_SEGMENTS = [
  {
    id: 'hwy-west',
    wayId: 'way/123456001',
    label: 'I-35E Westbound',
    laneCount: 3,
    points: [
      [HWY_LAT, EXIT_LON - 0.012],
      [HWY_LAT, EXIT_LON - 0.004],
      [HWY_LAT, EXIT_LON],
    ],
  },
  {
    id: 'hwy-merge',
    wayId: 'way/123456002',
    label: 'I-35E Merge Zone',
    laneCount: 4,
    points: [
      [HWY_LAT, EXIT_LON],
      [HWY_LAT, MERGE_LON],
    ],
  },
  {
    id: 'hwy-east',
    wayId: 'way/123456003',
    label: 'I-35E Post-Merge',
    laneCount: 3,
    points: [
      [HWY_LAT, MERGE_LON],
      [HWY_LAT, MERGE_LON + 0.012],
    ],
  },
  {
    id: 'ramp',
    wayId: 'way/123456004',
    label: 'Exit 42 On-Ramp',
    laneCount: 1,
    points: [
      [HWY_LAT, EXIT_LON],
      [HWY_LAT - 0.0015, EXIT_LON + 0.002],
      [HWY_LAT - 0.0018, EXIT_LON + 0.004],
      [HWY_LAT - 0.0010, EXIT_LON + 0.006],
      [HWY_LAT, MERGE_LON],
    ],
  },
];

// Highway segment chain order for vehicle flow
const HWY_CHAIN = ['hwy-west', 'hwy-merge', 'hwy-east'];

// Congestion → color mapping
const CONGESTION_COLORS = {
  free:       0x22c55e,
  moderate:   0xeab308,
  heavy:      0xef4444,
  standstill: 0x7f1d1d,
  unknown:    0x64748b,
};

// ── Car icon builder ──────────────────────────────────────────────────────────
// Returns a THREE.Group shaped like a top-down car icon with body, cab, wheels,
// headlight cones, and taillight glow.
function buildCarMesh(bodyColor, isRamp) {
  const group = new THREE.Group();

  const bodyW = 4.6, bodyH = 1.1, bodyD = 9.0;

  // Main body
  const body = new THREE.Mesh(
    new THREE.BoxGeometry(bodyW, bodyH, bodyD),
    new THREE.MeshStandardMaterial({ color: bodyColor, roughness: 0.35, metalness: 0.55 })
  );
  body.position.y = 0.55;
  body.castShadow = true;
  group.add(body);

  // Cab (passenger compartment — slightly narrower, sits on top)
  const cab = new THREE.Mesh(
    new THREE.BoxGeometry(bodyW * 0.78, bodyH * 0.85, bodyD * 0.42),
    new THREE.MeshStandardMaterial({ color: bodyColor, roughness: 0.3, metalness: 0.4 })
  );
  cab.position.set(0, bodyH + 0.42, bodyD * 0.04);
  cab.castShadow = true;
  group.add(cab);

  // Windows (dark glass)
  const glassMat = new THREE.MeshStandardMaterial({ color: 0x1a2a3a, roughness: 0.1, metalness: 0.7, transparent: true, opacity: 0.85 });
  const windshield = new THREE.Mesh(new THREE.BoxGeometry(bodyW * 0.72, bodyH * 0.7, 0.18), glassMat);
  windshield.position.set(0, bodyH + 0.42, bodyD * 0.04 + bodyD * 0.21 + 0.08);
  group.add(windshield);
  const rearWin = new THREE.Mesh(new THREE.BoxGeometry(bodyW * 0.72, bodyH * 0.7, 0.18), glassMat);
  rearWin.position.set(0, bodyH + 0.42, bodyD * 0.04 - bodyD * 0.21 - 0.08);
  group.add(rearWin);

  // Wheels (4x)
  const wheelMat = new THREE.MeshStandardMaterial({ color: 0x111111, roughness: 0.9 });
  const wheelRimMat = new THREE.MeshStandardMaterial({ color: 0x888888, roughness: 0.4, metalness: 0.8 });
  const WHEEL_OFFSETS = [
    { x:  bodyW * 0.58, z:  bodyD * 0.30 },
    { x: -bodyW * 0.58, z:  bodyD * 0.30 },
    { x:  bodyW * 0.58, z: -bodyD * 0.30 },
    { x: -bodyW * 0.58, z: -bodyD * 0.30 },
  ];
  WHEEL_OFFSETS.forEach(off => {
    const tire = new THREE.Mesh(new THREE.CylinderGeometry(1.05, 1.05, 1.0, 12), wheelMat);
    tire.rotation.z = Math.PI / 2;
    tire.position.set(off.x, 0.55, off.z);
    group.add(tire);
    const rim = new THREE.Mesh(new THREE.CylinderGeometry(0.55, 0.55, 1.05, 8), wheelRimMat);
    rim.rotation.z = Math.PI / 2;
    rim.position.set(off.x, 0.55, off.z);
    group.add(rim);
  });

  // Headlight cones (white, front = +Z direction)
  const headMat = new THREE.MeshBasicMaterial({ color: 0xffffee, transparent: true, opacity: 0.6 });
  [-1.2, 1.2].forEach(xOff => {
    const cone = new THREE.Mesh(new THREE.ConeGeometry(0.6, 4.5, 8), headMat);
    cone.rotation.x = -Math.PI / 2;
    cone.position.set(xOff, 0.6, bodyD / 2 + 2.2);
    group.add(cone);
  });

  // Taillight glow (red, rear = -Z)
  const tailMat = new THREE.MeshBasicMaterial({ color: 0xff2200, transparent: true, opacity: 0.75 });
  [-1.3, 1.3].forEach(xOff => {
    const tl = new THREE.Mesh(new THREE.BoxGeometry(0.8, 0.35, 0.25), tailMat);
    tl.position.set(xOff, 0.65, -bodyD / 2 - 0.1);
    group.add(tl);
  });

  // Point lights
  const hl = new THREE.PointLight(0xffffff, isRamp ? 0.6 : 0.45, 28);
  hl.position.set(0, 0.8, bodyD / 2 + 1);
  group.add(hl);
  const tl = new THREE.PointLight(0xff2200, 0.4, 16);
  tl.position.set(0, 0.6, -bodyD / 2 - 1);
  group.add(tl);

  // Ramp vehicles: orange underglow to stand out
  if (isRamp) {
    const glow = new THREE.PointLight(0xff8800, 0.5, 18);
    glow.position.set(0, -0.2, 0);
    group.add(glow);
  }

  return group;
}

function buildRoadMesh(segment) {
  const pts = segment.points.map(([lat, lon]) => {
    const p = geoToXZ(lat, lon, ORIGIN_LAT, ORIGIN_LON);
    return new THREE.Vector3(p.x, 0, p.z);
  });

  const curve = new THREE.CatmullRomCurve3(pts);
  const numPts = pts.length * 12;
  const curvePts = curve.getPoints(numPts);

  const width = segment.laneCount * 3.7; // ~12ft per lane in meters
  const shape = new THREE.Shape();
  shape.moveTo(-width / 2, 0);
  shape.lineTo(width / 2, 0);

  // Build road ribbon via TubeGeometry-style approach using ExtrudeGeometry along curve
  const roadGeom = new THREE.BufferGeometry();
  const verts = [];
  const indices = [];

  for (let i = 0; i < curvePts.length; i++) {
    const tangent = i < curvePts.length - 1
      ? curvePts[i + 1].clone().sub(curvePts[i]).normalize()
      : curvePts[i].clone().sub(curvePts[i - 1]).normalize();
    const normal = new THREE.Vector3(-tangent.z, 0, tangent.x);
    const left  = curvePts[i].clone().addScaledVector(normal, -width / 2);
    const right = curvePts[i].clone().addScaledVector(normal,  width / 2);
    verts.push(left.x, 0.05, left.z, right.x, 0.05, right.z);
    if (i < curvePts.length - 1) {
      const b = i * 2;
      indices.push(b, b + 1, b + 2, b + 1, b + 3, b + 2);
    }
  }

  roadGeom.setAttribute('position', new THREE.Float32BufferAttribute(verts, 3));
  roadGeom.setIndex(indices);
  roadGeom.computeVertexNormals();

  return { curve, geometry: roadGeom };
}

export default function Scene3D({ trafficData, selectedSegment, onSegmentClick, onRefresh, isLoading, lastUpdate }) {
  const mountRef = useRef(null);
  const sceneRef = useRef({});
  const [webglFailed, setWebglFailed] = useState(false);
  const [selectedVehicle, setSelectedVehicle] = useState(null); // { id, type, speedMph, segment, screenX, screenY }
  const selectedVehicleRef = useRef(null);

  useEffect(() => {
    const el = mountRef.current;
    if (!el) return;

    // ── Renderer ──────────────────────────────────────────────────────────────
    let renderer;
    try {
      renderer = new THREE.WebGLRenderer({ antialias: true, powerPreference: 'default' });
    } catch (e) {
      setWebglFailed(true);
      return;
    }
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.setSize(el.clientWidth, el.clientHeight);
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    renderer.setClearColor(0x0f172a);
    el.appendChild(renderer.domElement);

    // ── Scene ─────────────────────────────────────────────────────────────────
    const scene = new THREE.Scene();
    scene.fog = new THREE.Fog(0x0f172a, 300, 900);

    // ── Camera ────────────────────────────────────────────────────────────────
    const camera = new THREE.PerspectiveCamera(55, el.clientWidth / el.clientHeight, 0.5, 1500);
    camera.position.set(0, 180, 220);
    camera.lookAt(0, 0, 0);

    // ── Lights ────────────────────────────────────────────────────────────────
    scene.add(new THREE.AmbientLight(0x1e3a5f, 1.4));
    const dirLight = new THREE.DirectionalLight(0xffffff, 1.2);
    dirLight.position.set(150, 300, 150);
    dirLight.castShadow = true;
    scene.add(dirLight);
    // Accent blue rim light
    const rimLight = new THREE.PointLight(0x3b82f6, 1.5, 600);
    rimLight.position.set(-200, 80, -100);
    scene.add(rimLight);

    // ── Ground plane ──────────────────────────────────────────────────────────
    const ground = new THREE.Mesh(
      new THREE.PlaneGeometry(1200, 1200),
      new THREE.MeshStandardMaterial({ color: 0x0d1117, roughness: 0.95 })
    );
    ground.rotation.x = -Math.PI / 2;
    ground.receiveShadow = true;
    scene.add(ground);

    // Grid helper
    const grid = new THREE.GridHelper(1200, 80, 0x1e293b, 0x1e293b);
    grid.position.y = 0.02;
    scene.add(grid);

    // ── OSM Road Segments ─────────────────────────────────────────────────────
    const roadMeshes = {};
    const roadCurves = {};

    OSM_SEGMENTS.forEach(seg => {
      const { curve, geometry } = buildRoadMesh(seg);
      roadCurves[seg.id] = curve;

      const color = CONGESTION_COLORS.unknown;
      const mat = new THREE.MeshStandardMaterial({
        color,
        roughness: 0.6,
        metalness: 0.1,
        side: THREE.DoubleSide,
      });
      const mesh = new THREE.Mesh(geometry, mat);
      mesh.receiveShadow = true;
      mesh.userData = { segId: seg.id, label: seg.label, wayId: seg.wayId };
      scene.add(mesh);
      roadMeshes[seg.id] = mesh;

      // Lane markings
      const linePts = seg.points.map(([lat, lon]) => {
        const p = geoToXZ(lat, lon, ORIGIN_LAT, ORIGIN_LON);
        return new THREE.Vector3(p.x, 0.15, p.z);
      });
      const lineCurve = new THREE.CatmullRomCurve3(linePts);
      const lineGeom = new THREE.TubeGeometry(lineCurve, 40, 0.12, 4, false);
      const lineMat = new THREE.MeshBasicMaterial({ color: 0xffffff, opacity: 0.25, transparent: true });
      scene.add(new THREE.Mesh(lineGeom, lineMat));

      // Merge nose marker (glowing sphere at MERGE_LON)
      if (seg.id === 'hwy-merge') {
        const noseP = geoToXZ(HWY_LAT, MERGE_LON, ORIGIN_LAT, ORIGIN_LON);
        const sphere = new THREE.Mesh(
          new THREE.SphereGeometry(5, 16, 16),
          new THREE.MeshStandardMaterial({ color: 0x22c55e, emissive: 0x22c55e, emissiveIntensity: 1.5 })
        );
        sphere.position.set(noseP.x, 5, noseP.z);
        scene.add(sphere);
        // Glow ring
        const ring = new THREE.Mesh(
          new THREE.RingGeometry(18, 20, 48),
          new THREE.MeshBasicMaterial({ color: 0x22c55e, opacity: 0.3, transparent: true, side: THREE.DoubleSide })
        );
        ring.rotation.x = -Math.PI / 2;
        ring.position.set(noseP.x, 0.3, noseP.z);
        scene.add(ring);
      }
    });

    // ── Vehicles ──────────────────────────────────────────────────────────────
    // Flow model: hwy vehicles travel west→east through hwy-west → hwy-merge → hwy-east
    // Ramp vehicles travel ramp → hand off to hwy-merge at t=1
    const HWY_COLORS = [0xffffff, 0xccccff, 0xffddbb, 0xaaddff, 0xffcccc, 0xddffdd, 0xffe0a0, 0xe0e0ff];
    const RAMP_COLORS = [0xffaa44, 0xff9933, 0xffbb55, 0xffcc66];
    const vehicles = [];

    // Highway chain: hwy-west → hwy-merge → hwy-east (3 segments treated as one continuous flow)
    const HWY_VEH = 18;
    for (let i = 0; i < HWY_VEH; i++) {
      const color = HWY_COLORS[Math.floor(Math.random() * HWY_COLORS.length)];
      const car = buildCarMesh(color, false);
      const vehicleId = `HWY-${String(i + 1).padStart(3, '0')}`;
      car.userData.vehicleId = vehicleId;
      scene.add(car);
      const globalT = (i / HWY_VEH) * 3;
      const laneOffset = (Math.random() - 0.5) * 5;
      const speedMph = Math.round(45 + Math.random() * 25);
      vehicles.push({ mesh: car, type: 'hwy', globalT, speed: 0.001, laneOffset, id: vehicleId, speedMph, segment: 'hwy-west' });
    }

    // Ramp vehicles: travel ramp curve 0→1, then transition onto hwy-merge
    const RAMP_VEH = 8;
    for (let i = 0; i < RAMP_VEH; i++) {
      const color = RAMP_COLORS[Math.floor(Math.random() * RAMP_COLORS.length)];
      const car = buildCarMesh(color, true);
      const vehicleId = `RAMP-${String(i + 1).padStart(3, '0')}`;
      car.userData.vehicleId = vehicleId;
      scene.add(car);
      const globalT = (i / RAMP_VEH) * 2;
      const speedMph = Math.round(25 + Math.random() * 20);
      vehicles.push({ mesh: car, type: 'ramp', globalT, speed: 0.0009, id: vehicleId, speedMph, segment: 'ramp' });
    }

    // ── Switch server towers ───────────────────────────────────────────────────
    const SWITCHES = [
      { lat: HWY_LAT + 0.0018, lon: MERGE_LON - 0.0015, color: 0xf97316, label: 'SW-1' },
      { lat: HWY_LAT + 0.0018, lon: MERGE_LON + 0.0015, color: 0xa78bfa, label: 'SW-2' },
      { lat: HWY_LAT - 0.0022, lon: MERGE_LON,          color: 0xfb7185, label: 'SW-3' },
    ];

    const mergeP = geoToXZ(HWY_LAT, MERGE_LON, ORIGIN_LAT, ORIGIN_LON);

    SWITCHES.forEach(sw => {
      const p = geoToXZ(sw.lat, sw.lon, ORIGIN_LAT, ORIGIN_LON);
      const pole = new THREE.Mesh(
        new THREE.CylinderGeometry(0.8, 0.8, 20, 8),
        new THREE.MeshStandardMaterial({ color: sw.color, emissive: sw.color, emissiveIntensity: 0.4 })
      );
      pole.position.set(p.x, 10, p.z);
      scene.add(pole);
      const beacon = new THREE.PointLight(sw.color, 1.2, 120);
      beacon.position.set(p.x, 22, p.z);
      scene.add(beacon);

      // Triangulation line to merge nose
      const lineGeo = new THREE.BufferGeometry().setFromPoints([
        new THREE.Vector3(p.x, 10, p.z),
        new THREE.Vector3(mergeP.x, 5, mergeP.z),
      ]);
      scene.add(new THREE.Line(lineGeo, new THREE.LineBasicMaterial({ color: sw.color, opacity: 0.35, transparent: true })));
    });

    sceneRef.current = { scene, camera, renderer, roadMeshes, roadCurves, vehicles };

    // ── OrbitControls (manual, no npm) ────────────────────────────────────────
    let isDragging = false, prevX = 0, prevY = 0;
    let spherical = { theta: 0, phi: Math.PI / 4.5, radius: 280 };
    const target = new THREE.Vector3(0, 0, 0);

    function updateCamera() {
      camera.position.x = target.x + spherical.radius * Math.sin(spherical.phi) * Math.sin(spherical.theta);
      camera.position.y = target.y + spherical.radius * Math.cos(spherical.phi);
      camera.position.z = target.z + spherical.radius * Math.sin(spherical.phi) * Math.cos(spherical.theta);
      camera.lookAt(target);
    }
    updateCamera();

    const onMouseDown = e => { isDragging = true; prevX = e.clientX; prevY = e.clientY; };
    const onMouseUp   = () => { isDragging = false; };
    const onMouseMove = e => {
      if (!isDragging) return;
      spherical.theta -= (e.clientX - prevX) * 0.005;
      spherical.phi = Math.max(0.15, Math.min(Math.PI / 2.2, spherical.phi - (e.clientY - prevY) * 0.005));
      prevX = e.clientX; prevY = e.clientY;
      updateCamera();
    };
    const onWheel = e => {
      spherical.radius = Math.max(40, Math.min(600, spherical.radius + e.deltaY * 0.3));
      updateCamera();
    };
    // Touch support
    let lastTouchDist = 0;
    const onTouchStart = e => {
      if (e.touches.length === 1) { isDragging = true; prevX = e.touches[0].clientX; prevY = e.touches[0].clientY; }
      if (e.touches.length === 2) {
        const dx = e.touches[0].clientX - e.touches[1].clientX;
        const dy = e.touches[0].clientY - e.touches[1].clientY;
        lastTouchDist = Math.sqrt(dx * dx + dy * dy);
      }
    };
    const onTouchMove = e => {
      if (e.touches.length === 1 && isDragging) {
        spherical.theta -= (e.touches[0].clientX - prevX) * 0.006;
        spherical.phi = Math.max(0.15, Math.min(Math.PI / 2.2, spherical.phi - (e.touches[0].clientY - prevY) * 0.006));
        prevX = e.touches[0].clientX; prevY = e.touches[0].clientY;
        updateCamera();
      }
      if (e.touches.length === 2) {
        const dx = e.touches[0].clientX - e.touches[1].clientX;
        const dy = e.touches[0].clientY - e.touches[1].clientY;
        const dist = Math.sqrt(dx * dx + dy * dy);
        spherical.radius = Math.max(40, Math.min(600, spherical.radius - (dist - lastTouchDist) * 0.5));
        lastTouchDist = dist;
        updateCamera();
      }
    };
    const onTouchEnd = () => { isDragging = false; };

    // ── Raycaster click → vehicle popup ──────────────────────────────────────
    const raycaster = new THREE.Raycaster();
    const mouse = new THREE.Vector2();
    let mouseDownPos = { x: 0, y: 0 };

    const onClickDown = e => { mouseDownPos = { x: e.clientX, y: e.clientY }; };
    const onClick = e => {
      // Only fire on short clicks (not drags)
      const dx = e.clientX - mouseDownPos.x;
      const dy = e.clientY - mouseDownPos.y;
      if (Math.sqrt(dx * dx + dy * dy) > 5) return;

      const rect = el.getBoundingClientRect();
      mouse.x =  ((e.clientX - rect.left) / rect.width)  * 2 - 1;
      mouse.y = -((e.clientY - rect.top)  / rect.height) * 2 + 1;
      raycaster.setFromCamera(mouse, camera);

      // Collect all child meshes of all vehicle groups
      const vehicleMeshes = [];
      sceneRef.current.vehicles?.forEach(v => {
        v.mesh.traverse(child => {
          if (child.isMesh) vehicleMeshes.push({ mesh: child, vehicle: v });
        });
      });

      const meshes = vehicleMeshes.map(vm => vm.mesh);
      const intersects = raycaster.intersectObjects(meshes, false);
      if (intersects.length > 0) {
        const hit = intersects[0].object;
        const found = vehicleMeshes.find(vm => vm.mesh === hit);
        if (found) {
          const v = found.vehicle;
          // Compute 2D screen position of vehicle world position
          const pos3d = v.mesh.position.clone().project(camera);
          const sx = ((pos3d.x + 1) / 2) * rect.width  + rect.left;
          const sy = ((-pos3d.y + 1) / 2) * rect.height + rect.top;
          const segLabels = { 'hwy-west': 'I-35E Westbound', 'hwy-merge': 'I-35E Merge Zone', 'hwy-east': 'I-35E Post-Merge', 'ramp': 'Exit 42 On-Ramp' };
          const info = {
            id: v.id,
            type: v.type === 'ramp' ? 'On-Ramp' : 'Highway',
            speedMph: v.speedMph,
            segment: segLabels[v.segment] ?? v.segment,
            screenX: sx,
            screenY: sy,
          };
          selectedVehicleRef.current = info;
          setSelectedVehicle({ ...info });
        }
      } else {
        selectedVehicleRef.current = null;
        setSelectedVehicle(null);
      }
    };

    el.addEventListener('mousedown', onMouseDown);
    el.addEventListener('mousedown', onClickDown);
    el.addEventListener('click', onClick);
    window.addEventListener('mouseup', onMouseUp);
    window.addEventListener('mousemove', onMouseMove);
    el.addEventListener('wheel', onWheel, { passive: true });
    el.addEventListener('touchstart', onTouchStart, { passive: true });
    el.addEventListener('touchmove', onTouchMove, { passive: true });
    el.addEventListener('touchend', onTouchEnd);

    // ── Animation loop ────────────────────────────────────────────────────────
    let animId;
    let tick = 0;
    function animate() {
      animId = requestAnimationFrame(animate);
      tick++;

      // Animate vehicles along chained curves
      vehicles.forEach(v => {
        v.globalT += v.speed;

        let pt, tangent;

        if (v.type === 'hwy') {
          if (v.globalT >= 3) v.globalT -= 3;
          const segIdx = Math.min(2, Math.floor(v.globalT));
          const localT = Math.min(v.globalT - segIdx, 0.999);
          const segId = HWY_CHAIN[segIdx];
          v.segment = segId;
          const curve = roadCurves[segId];
          if (!curve) return;
          pt = curve.getPoint(localT);
          tangent = curve.getTangent(localT);
          const perp = new THREE.Vector3(-tangent.z, 0, tangent.x).normalize();
          v.mesh.position.set(
            pt.x + perp.x * v.laneOffset,
            0,
            pt.z + perp.z * v.laneOffset
          );
        } else if (v.type === 'ramp') {
          if (v.globalT >= 2) v.globalT -= 2;
          v.segment = v.globalT < 1 ? 'ramp' : 'hwy-merge';
          const curve = v.globalT < 1 ? roadCurves['ramp'] : roadCurves['hwy-merge'];
          const localT = Math.min(v.globalT < 1 ? v.globalT : v.globalT - 1, 0.999);
          if (!curve) return;
          pt = curve.getPoint(localT);
          tangent = curve.getTangent(localT);
          v.mesh.position.set(pt.x, 0, pt.z);
        }

        if (tangent) {
          v.mesh.rotation.y = Math.atan2(tangent.x, tangent.z);
        }
      });

      // Keep popup position in sync with selected vehicle
      if (selectedVehicleRef.current) {
        const selV = sceneRef.current.vehicles?.find(v => v.id === selectedVehicleRef.current.id);
        if (selV) {
          const rect = el.getBoundingClientRect();
          const pos3d = selV.mesh.position.clone().project(camera);
          const sx = ((pos3d.x + 1) / 2) * rect.width  + rect.left;
          const sy = ((-pos3d.y + 1) / 2) * rect.height + rect.top;
          const segLabels = { 'hwy-west': 'I-35E Westbound', 'hwy-merge': 'I-35E Merge Zone', 'hwy-east': 'I-35E Post-Merge', 'ramp': 'Exit 42 On-Ramp' };
          selectedVehicleRef.current = { ...selectedVehicleRef.current, segment: segLabels[selV.segment] ?? selV.segment, speedMph: selV.speedMph, screenX: sx, screenY: sy };
          setSelectedVehicle(prev => prev ? { ...prev, segment: segLabels[selV.segment] ?? selV.segment, speedMph: selV.speedMph, screenX: sx, screenY: sy } : null);
        }
      }

      // Pulse merge nose ring
      if (tick % 2 === 0) {
        scene.children.forEach(c => {
          if (c.geometry?.type === 'RingGeometry') {
            c.material.opacity = 0.15 + 0.2 * Math.abs(Math.sin(tick * 0.04));
          }
        });
      }

      renderer.render(scene, camera);
    }
    animate();

    // ── Resize ────────────────────────────────────────────────────────────────
    const onResize = () => {
      camera.aspect = el.clientWidth / el.clientHeight;
      camera.updateProjectionMatrix();
      renderer.setSize(el.clientWidth, el.clientHeight);
    };
    window.addEventListener('resize', onResize);

    return () => {
      cancelAnimationFrame(animId);
      el.removeEventListener('mousedown', onMouseDown);
      el.removeEventListener('mousedown', onClickDown);
      el.removeEventListener('click', onClick);
      window.removeEventListener('mouseup', onMouseUp);
      window.removeEventListener('mousemove', onMouseMove);
      el.removeEventListener('wheel', onWheel);
      el.removeEventListener('touchstart', onTouchStart);
      el.removeEventListener('touchmove', onTouchMove);
      el.removeEventListener('touchend', onTouchEnd);
      window.removeEventListener('resize', onResize);
      renderer.dispose();
      if (el.contains(renderer.domElement)) el.removeChild(renderer.domElement);
    };
  }, []);

  // ── Update road colors when traffic data changes ───────────────────────────
  useEffect(() => {
    const { roadMeshes } = sceneRef.current;
    if (!roadMeshes || !trafficData?.segments) return;

    trafficData.segments.forEach(seg => {
      const mesh = roadMeshes[seg.id];
      if (!mesh) return;
      const hex = CONGESTION_COLORS[seg.congestionLevel] ?? CONGESTION_COLORS.unknown;
      mesh.material.color.setHex(hex);
      mesh.material.emissive.setHex(hex);
      mesh.material.emissiveIntensity = 0.22;
      // Scale visual speed proportionally to real mph: 65 mph → fast, 11 mph → crawl
      const normalizedSpeed = Math.max(0.00025, (seg.currentSpeed / 65) * 0.0022);
      if (sceneRef.current.vehicles) {
        sceneRef.current.vehicles.forEach(v => {
          if (v.type === 'hwy') {
            const segIdx = ['hwy-west', 'hwy-merge', 'hwy-east'].indexOf(seg.id);
            const vSegIdx = Math.min(2, Math.floor(v.globalT));
            if (segIdx === vSegIdx) {
              v.speed = normalizedSpeed + (Math.random() - 0.5) * 0.00008;
              v.speedMph = Math.round(seg.currentSpeed + (Math.random() - 0.5) * 8);
            }
          }
          if (v.type === 'ramp' && (seg.id === 'ramp' || seg.id === 'hwy-merge')) {
            v.speed = Math.max(0.00020, normalizedSpeed * 0.85) + (Math.random() - 0.5) * 0.00008;
            v.speedMph = Math.round(seg.currentSpeed * 0.85 + (Math.random() - 0.5) * 6);
          }
        });
      }
    });
  }, [trafficData]);

  if (webglFailed) {
    return <TrafficCanvas2D trafficData={trafficData} />;
  }

  return (
    <div className="w-full h-full relative">
      <div ref={mountRef} className="w-full h-full" style={{ cursor: 'grab' }} />

      {/* Vehicle popup */}
      {selectedVehicle && (
        <div
          className="fixed z-[9999] pointer-events-none"
          style={{ left: selectedVehicle.screenX, top: selectedVehicle.screenY, transform: 'translate(-50%, -120%)' }}
        >
          <div className="bg-slate-900/95 backdrop-blur border border-slate-600 rounded-xl shadow-2xl px-4 py-3 min-w-[180px]">
            {/* Close button — needs pointer-events */}
            <button
              className="pointer-events-auto absolute top-2 right-2 text-slate-500 hover:text-slate-200 transition-colors"
              onClick={() => { setSelectedVehicle(null); selectedVehicleRef.current = null; }}
            >
              <svg width="12" height="12" viewBox="0 0 12 12" fill="currentColor">
                <path d="M1 1l10 10M11 1L1 11" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round"/>
              </svg>
            </button>

            <div className="flex items-center gap-2 mb-2">
              <div className="w-2 h-2 rounded-full bg-blue-400 animate-pulse" />
              <span className="text-[11px] font-bold text-slate-100 font-mono">{selectedVehicle.id}</span>
            </div>

            <div className="space-y-1">
              <div className="flex justify-between gap-4">
                <span className="text-[10px] text-slate-500 font-mono">SPEED</span>
                <span className="text-[10px] font-bold text-green-400 font-mono">{selectedVehicle.speedMph} mph</span>
              </div>
              <div className="flex justify-between gap-4">
                <span className="text-[10px] text-slate-500 font-mono">TYPE</span>
                <span className="text-[10px] text-slate-300 font-mono">{selectedVehicle.type}</span>
              </div>
              <div className="flex justify-between gap-4">
                <span className="text-[10px] text-slate-500 font-mono">SEGMENT</span>
                <span className="text-[10px] text-slate-300 font-mono text-right max-w-[100px] leading-tight">{selectedVehicle.segment}</span>
              </div>
            </div>

            {/* Arrow pointing down */}
            <div className="absolute left-1/2 -translate-x-1/2 bottom-[-6px] w-3 h-3 bg-slate-900 border-r border-b border-slate-600 rotate-45" />
          </div>
        </div>
      )}
    </div>
  );
}