import { cn } from '@/lib/utils';

const STATUS_CONFIG = {
  online:      { color: 'bg-accent/20 text-accent border-accent/30',       dot: 'bg-accent' },
  active:      { color: 'bg-accent/20 text-accent border-accent/30',       dot: 'bg-accent' },
  offline:     { color: 'bg-muted text-muted-foreground border-border',     dot: 'bg-muted-foreground' },
  inactive:    { color: 'bg-muted text-muted-foreground border-border',     dot: 'bg-muted-foreground' },
  fault:       { color: 'bg-destructive/20 text-destructive border-destructive/30', dot: 'bg-destructive' },
  degraded:    { color: 'bg-warning/20 text-yellow-400 border-yellow-500/30', dot: 'bg-yellow-400' },
  maintenance: { color: 'bg-warning/20 text-yellow-400 border-yellow-500/30', dot: 'bg-yellow-400' },
  calibrating: { color: 'bg-primary/20 text-primary border-primary/30',    dot: 'bg-primary' },
  conflict:    { color: 'bg-destructive/20 text-destructive border-destructive/30', dot: 'bg-destructive' },
};

export default function StatusBadge({ status, className }) {
  const cfg = STATUS_CONFIG[status] || STATUS_CONFIG.offline;
  return (
    <span className={cn('inline-flex items-center gap-1.5 px-2 py-0.5 rounded-full text-xs border font-medium', cfg.color, className)}>
      <span className={cn('w-1.5 h-1.5 rounded-full', cfg.dot, ['online','active'].includes(status) && 'animate-pulse')} />
      {status?.toUpperCase()}
    </span>
  );
}