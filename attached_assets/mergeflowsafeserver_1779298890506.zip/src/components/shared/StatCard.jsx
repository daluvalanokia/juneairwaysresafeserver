import { cn } from '@/lib/utils';

export default function StatCard({ label, value, unit, icon: Icon, color = 'primary', trend, className }) {
  const colors = {
    primary: 'border-primary/20 bg-primary/5 text-primary',
    accent:  'border-accent/20 bg-accent/5 text-accent',
    destructive: 'border-destructive/20 bg-destructive/5 text-destructive',
    warning: 'border-yellow-500/20 bg-yellow-500/5 text-yellow-400',
    muted:   'border-border bg-secondary text-muted-foreground',
  };

  return (
    <div className={cn('rounded-xl border bg-card p-4 flex flex-col gap-2', className)}>
      <div className="flex items-center justify-between">
        <span className="text-xs text-muted-foreground font-mono uppercase tracking-wider">{label}</span>
        {Icon && (
          <div className={cn('w-8 h-8 rounded-lg flex items-center justify-center border', colors[color])}>
            <Icon className="w-4 h-4" />
          </div>
        )}
      </div>
      <div className="flex items-end gap-1">
        <span className="text-2xl font-bold text-foreground">{value ?? '—'}</span>
        {unit && <span className="text-xs text-muted-foreground mb-1">{unit}</span>}
      </div>
      {trend && <span className="text-xs text-muted-foreground">{trend}</span>}
    </div>
  );
}