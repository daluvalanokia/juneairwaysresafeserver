import { useEffect, useRef, useState } from 'react';
import { Html5Qrcode } from 'html5-qrcode';
import { Button } from '@/components/ui/button';
import { ScanLine, X } from 'lucide-react';

// onScan(data) — called with the raw decoded string
// Fields to auto-fill can be JSON in the QR, or a plain string mapped to a single field
export default function BarcodeScanner({ onScan, onClose }) {
  const [error, setError] = useState(null);
  const [scanning, setScanning] = useState(false);
  const scannerRef = useRef(null);
  const divId = 'barcode-scanner-preview';

  useEffect(() => {
    const scanner = new Html5Qrcode(divId);
    scannerRef.current = scanner;
    setScanning(true);

    scanner.start(
      { facingMode: 'environment' },
      { fps: 10, qrbox: { width: 220, height: 220 } },
      (decodedText) => {
        scanner.stop().then(() => {
          setScanning(false);
          onScan(decodedText);
        });
      },
      () => {} // ignore per-frame errors
    ).catch(err => {
      setError('Camera access denied or unavailable.');
      setScanning(false);
    });

    return () => {
      scanner.stop().catch(() => {});
    };
  }, []);

  return (
    <div className="flex flex-col items-center gap-3">
      <div className="relative w-full rounded-lg overflow-hidden bg-black" style={{ minHeight: 260 }}>
        <div id={divId} style={{ width: '100%' }} />
        {scanning && (
          <div className="absolute inset-0 pointer-events-none flex items-center justify-center">
            <div className="w-48 h-48 border-2 border-primary rounded-lg opacity-60" />
            <ScanLine className="absolute w-8 h-8 text-primary animate-pulse" />
          </div>
        )}
      </div>
      {error && <p className="text-xs text-destructive">{error}</p>}
      {scanning && <p className="text-xs text-muted-foreground font-mono animate-pulse">Point camera at barcode or QR code…</p>}
      <Button variant="outline" size="sm" onClick={onClose} className="gap-1">
        <X className="w-3.5 h-3.5" /> Cancel Scan
      </Button>
    </div>
  );
}