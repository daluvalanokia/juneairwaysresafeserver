import { useState } from 'react';
import { Toaster } from "@/components/ui/toaster";
import { QueryClientProvider } from '@tanstack/react-query';
import { queryClientInstance } from '@/lib/query-client';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import PageNotFound from './lib/PageNotFound';
import { AuthProvider, useAuth } from '@/lib/AuthContext';
import UserNotRegisteredError from '@/components/UserNotRegisteredError';
import AppLayout from '@/components/layout/AppLayout';

// Pages
import Dashboard from '@/pages/Dashboard';
import MergeZones from '@/pages/MergeZones';
import SwitchServers from '@/pages/SwitchServers';
import Sensors from '@/pages/Sensors';
import Triangulation from '@/pages/Triangulation';
import Events from '@/pages/Events';
import Settings from '@/pages/Settings';
import Traffic3D from '@/pages/Traffic3D';
import Users from '@/pages/Users';
import Portal from '@/pages/Portal';
import DataInputFormats from '@/pages/DataInputFormats';
import RequirementsDoc from '@/pages/RequirementsDoc';

const AuthenticatedApp = () => {
  const { isLoadingAuth, isLoadingPublicSettings, authError, navigateToLogin } = useAuth();
  const [selectedHighway, setSelectedHighway] = useState(null);

  if (isLoadingPublicSettings || isLoadingAuth) {
    return (
      <div className="fixed inset-0 flex items-center justify-center bg-background">
        <div className="flex flex-col items-center gap-3">
          <div className="w-8 h-8 border-4 border-primary/20 border-t-primary rounded-full animate-spin" />
          <p className="text-xs text-muted-foreground font-mono">INITIALIZING MERGESAFESERVER...</p>
        </div>
      </div>
    );
  }

  if (authError) {
    if (authError.type === 'user_not_registered') return <UserNotRegisteredError />;
    if (authError.type === 'auth_required') { navigateToLogin(); return null; }
  }

  return (
    <Routes>
      <Route path="/portal" element={<Portal />} />
      <Route element={<AppLayout selectedHighway={selectedHighway} onHighwayChange={setSelectedHighway} />}>
        <Route path="/" element={<Dashboard selectedHighway={selectedHighway} />} />
        <Route path="/zones" element={<MergeZones selectedHighway={selectedHighway} />} />
        <Route path="/servers" element={<SwitchServers selectedHighway={selectedHighway} />} />
        <Route path="/sensors" element={<Sensors selectedHighway={selectedHighway} />} />
        <Route path="/triangulation" element={<Triangulation selectedHighway={selectedHighway} />} />
        <Route path="/events" element={<Events selectedHighway={selectedHighway} />} />
        <Route path="/settings" element={<Settings />} />
        <Route path="/traffic3d" element={<Traffic3D selectedHighway={selectedHighway} />} />
        <Route path="/users" element={<Users />} />
        <Route path="/input-formats" element={<DataInputFormats />} />
        <Route path="/requirements" element={<RequirementsDoc />} />
      </Route>
      <Route path="*" element={<PageNotFound />} />
    </Routes>
  );
};

function App() {
  return (
    <AuthProvider>
      <QueryClientProvider client={queryClientInstance}>
        <Router>
          <AuthenticatedApp />
        </Router>
        <Toaster />
      </QueryClientProvider>
    </AuthProvider>
  );
}

export default App;